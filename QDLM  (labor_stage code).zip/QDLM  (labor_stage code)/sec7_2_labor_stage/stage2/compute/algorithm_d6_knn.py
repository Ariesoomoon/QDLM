# Paper: Section 7.2 labor stage2 - compute script (writes/updates Result_data/hospital_stage2_*.npy).
# Formerly: Algorithm/algorithm_d6_knn.py. Run from this compute/ folder (project root = one level up).
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Function_same_block_warfarin import generate_data, GE_Knn, LE_Knn_test, AE_Knn_test, AE_adapt_Knn_test, AE_active_Knn_test
# from Function_diff_block import generate_data, GE_Knn, LE_Knn_test, AE_Knn_test, AE_adapt_Knn_test, AE_active_Knn_test
import numpy as np
from sklearn.model_selection import train_test_split
time_start = time.time()


'''1. Initialization'''
d = 7
f = 5
s = 2
trails = 40
fen_num, gap = 25, 2 # m = 2,4,...,50, 一共2200数据， 200测试
fen_num_knn = 25     # k_opt在全局的取值都大于等于36??? 我们这里是10

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/LHS_based_hospital_stage2.npy', allow_pickle=True)
hospital_data = loadData.tolist()
X = hospital_data['X_ah_combine_2000']
y = hospital_data['generated_y_2000']
print(hospital_data.keys())


# 50 type of divisions, 40trails, average by axis=1(by trail axis)
GEs = []
LEs = np.empty(shape=(25, 40))
AE_log_actives = np.empty(shape=(25, 40))
# LE_adapts = np.empty(shape=(25, 40))


# load the localization parameters
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage2_knn.npy', allow_pickle=True)
hospital_stage2_knn = loadData.tolist()
global_ks = hospital_stage2_knn['global_k']
local_ks = hospital_stage2_knn['local_k']
print(hospital_stage2_knn.keys())


'''2. 20 trails: calculating the MSE of GE, LE, AE(with h given global), AE_adapt, AE_log, AE_log_active with gaussian kernel'''
for th in range(trails):
    # (1) create data and load parameter
    print('                                                                                  trail:', th + 1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)  # shuffle:bool, default=True
    global_k = global_ks[th]    # for th trail, select the corresponding global_h[th]
    local_k = local_ks[th]

    # (2) calculating
    GE = GE_Knn(X_train, y_train, X_test, y_test, global_k, d)
    GEs.append(GE)
    print('GEs:', GEs)

    LE = LE_Knn_test(X_train, y_train, X_test, y_test, fen_num_knn, gap, global_k, d)
    LE = np.array(LE)
    LEs[:, th] = np.squeeze(LE)

    AE_log_active = AE_active_Knn_test(X_train, y_train, X_test, y_test, d, fen_num, gap, local_k)[0]
    AE_log_active = np.array(AE_log_active)
    AE_log_actives[:, th] = np.squeeze(AE_log_active)


'''3. save MSE'''
hospital_stage2_knn['GEs'] = GEs
hospital_stage2_knn['LEs'] = LEs
hospital_stage2_knn['AE_log_actives'] = AE_log_actives


np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage2_knn.npy', hospital_stage2_knn)
print('--------------------------------------------------------------save hospital_stage2_knn.npy done')
time_total = time.time() - time_start
print('runing time:', time_total)
