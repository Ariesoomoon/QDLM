# Paper: Section 7.2 labor stage2 - parameter tuning (initializes Result_data/hospital_stage2_*.npy).
# Formerly: Parameter training/parameter_d6_knn.py. Run from this compute/ folder (project root = one level up).
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Function_same_block_warfarin import generate_data, global_parameter_k_d5, local_parameter_k_d_test
# from Function_diff_block import generate_data, global_parameter_k_d5, local_parameter_k_d_test
import numpy as np
from sklearn.model_selection import train_test_split
time_start = time.time()


'''选参范围：全局的参数都在80以内，因此设置20， 60作为选参数的起点；全局的参数（除了m=2）都在60以内，因此设置15， 45作为选参数的起点。
trail:0
全局：74
局部：
[56, 49]
[38, 45, 41, 54]
'''

'''1. Initialization'''
d = 7
f = 5
s = 2
trails = 40
fen_num, gap = 25, 2 # m = 2,4,...,50, 一共2200数据， 200测试
global_k = []
local_k = {}
# p1, p2 = 20, 60
p1, p2 = 10, 30


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/LHS_based_hospital_stage2.npy', allow_pickle=True)
hospital_data = loadData.tolist()
X = hospital_data['X_ah_combine_2000']
y = hospital_data['generated_y_2000']
print(hospital_data.keys())

# X = np.asarray(X)
# y = np.asarray(y).ravel()  # .ravel() 将 (n,1) 变为 (n,)

hospital_stage2_knn = {}
print('save hospital_stage2_knn.npy done')


# 保证全局和局部的k的选参精度都是1
'''2. training parameter for global and local(m = 2,4,...,60): 20 random seed for 20 trails, with different splitting'''
for th in range(trails):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)  # shuffle:bool, default=True
    print('\n训练集和测试集的划分（input X和output y） --------------------------------trail:', th)

    gk_trail1 = global_parameter_k_d5(X_train, y_train, p1, p2, d)
    gk_trail1 = int(gk_trail1)
    global_k.append(gk_trail1)
    print('global_k', global_k)

    lk_trail1 = local_parameter_k_d_test(X_train, y_train, p1, p2, d, fen_num, gap)
    local_k[th] = lk_trail1
    print(local_k)


'''3. save parameters'''
hospital_stage2_knn['global_k'] = global_k
hospital_stage2_knn['local_k'] = local_k
# hospital_stage2_knn['local_k_diff'] = local_k
np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage2_knn.npy', hospital_stage2_knn)
print('--------------------------------------------------------------save hospital_stage2_knn.npy done')
#pdb.set_trace()





