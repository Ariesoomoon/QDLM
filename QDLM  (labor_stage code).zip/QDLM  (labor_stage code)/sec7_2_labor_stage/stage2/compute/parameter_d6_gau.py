# Paper: Section 7.2 labor stage2 - parameter tuning (initializes Result_data/hospital_stage2_*.npy).
# Formerly: Parameter training/parameter_d6_gau.py. Run from this compute/ folder (project root = one level up).
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Function_same_block_warfarin import generate_data, global_parameter_h, local_parameter_h_test
# from Function_diff_block import generate_data, global_parameter_h, local_parameter_h_test
import numpy as np
from sklearn.model_selection import train_test_split
time_start = time.time()


'''0. replace to Epan kernel of all cv-5 function in Function_same_block_gau.py !!!!'''


'''1. Initialization'''

d = 7
f = 5
s = 2
trails = 40
fen_num, gap = 25, 2 # m = 2,4,...,50, 一共2200数据， 200测试
global_h = []
local_h = {}


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/LHS_based_hospital_stage2.npy', allow_pickle=True)
hospital_data = loadData.tolist()
X = hospital_data['X_ah_combine_2000']
y = hospital_data['generated_y_2000']
print(hospital_data.keys())

# X = np.asarray(X)
# y = np.asarray(y).ravel()  # .ravel() 将 (n,1) 变为 (n,)


# hospital_stage2_gau = {}
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage2_gau.npy', hospital_stage2_gau)
# print('save hospital_stage2_gau.npy done')


'''2. training parameter for global and local: 20 random seed for 20 trails, with different splixtting'''
for th in range(trails):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)  # shuffle:bool, default=True
    print('\n--------------------------------------------------------------trail:', th)
    print(X_train.shape)
    print(y_train.shape)

    gh_trail1 = global_parameter_h(X_train, y_train, f, d)
    global_h.append(gh_trail1)
    print(global_h)

    lh_trail1 = local_parameter_h_test(X_train, y_train, f, d, fen_num, gap)
    local_h[th] = lh_trail1


# '''3. save parameters'''
# hospital_stage2_gau['global_h'] = global_h
# hospital_stage2_gau['local_h'] = local_h
# # hospital_stage2_gau['local_h_diff'] = local_h
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage2_gau.npy', hospital_stage2_gau)
# print('--------------------------------------------------------------save hospital_stage2_gau.npy done')
# # pdb.set_trace()




