# Prediction_2200_stage2.py
# Paper: Section 7.2 labor-stage case study - synthetic data generation (LHS expansion).
# Formerly: synthetic data generation/Prediction_产前_孕妇_生成数据_2200_stage2.py
# Reads ceqie_and_weichuang_all_attributes.xlsx (same folder). Run from this folder
# (project root = one level up). NOTE: the intermediate cache
# LHS_based_hospital_stage2_for_MIA.npy lives in the project Result_data_for_MIIA/.
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error
from sklearn.impute import SimpleImputer
import os, time
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings("ignore")
import pandas as pd
from matplotlib import rcParams
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}

rcParams.update(config)
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.gridspec as gridspec
from sklearn.preprocessing import MinMaxScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_excel('ceqie_and_weichuang_all_attributes.xlsx')


'''
=== stage1_time (Linear Regression) ===
R2: -0.217, MAE: 0.130
=== stage2_time (Linear Regression) ===
R2: 0.020, MAE: 0.038
=== Apgar1 (Linear Regression) ===
R2: -0.109, MAE: 0.847
=== baby_weight (Linear Regression) ===
R2: 0.146, MAE: 337.342
'''


import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score, mean_absolute_error, mean_squared_error
from sklearn.impute import SimpleImputer
import os
import warnings
import matplotlib.pyplot as plt
import seaborn as sns
warnings.filterwarnings("ignore")


# 图形配置
from matplotlib import rcParams
config = {"font.family": 'Times New Roman', "font.size": 15, "mathtext.fontset": 'stix'}
rcParams.update(config)


from function_ideal_insurance import syn_mean_covari, RL_measure_alld, pairing_X_Xs, \
    Microhybrid_mn, Microhybrid_lhs, RL_interval, Diff_mean, Diff_variance, Diff_covariance, \
    Diff_skew_kurt, Histogram_plot, LHS_synthesizer, LHS_synthesizer_adapt, Microhybrid_lhs_adapt,\
    Scatter_histogram_kde, KDE_forplot, X_3d_plot, Xs_mn_3d_plot, Xs_lhs_3d_plot, correlation_heatmap,\
    kernel_d3, Condition_num, parameter_lambda_krr_forplot, Predictedkrr, generate_y_krr, RL_interval_y, \
    Predictedboost, global_parameter_t_boost, parameter_t_boost_forplot, global_parameter_h, GE_gaussiank, \
    Predictedrf, global_parameter_t_rf, parameter_t_rf_forplot, global_parameter_kt_boost, Predictedboost_kt, \
    RL_interval_new, Interval_disclosure, Interval_disclosure_y


# 读取数据
df = pd.read_excel('ceqie_and_weichuang_all_attributes.xlsx')

# 合并 gest_week 和 gest_day
df['total_days'] = df['gest_week'] * 7 + df['gest_day']
continuous_inputs = ['age', 'height', 'weight', 'BMI', 'total_days']
categorical_inputs = ['gravidity', 'parity']
input_cols = continuous_inputs + categorical_inputs

# 输出变量
continuous_targets = ['stage1_time', 'stage2_time', 'Apgar1', 'baby_weight', 'pph', 'hospital_days']

# 归一化 + 缺失值填补
scaler = MinMaxScaler()
X_scaled = pd.DataFrame(scaler.fit_transform(df[input_cols]), columns=input_cols)
imputer = SimpleImputer(strategy='median')
X_imputed = pd.DataFrame(imputer.fit_transform(X_scaled), columns=input_cols)

# 保存目录
save_dir = './model_plots_predict_2'
os.makedirs(save_dir, exist_ok=True)

y = df['stage2_time']
data = pd.concat([X_imputed, y], axis=1).dropna(subset=['stage2_time'])
X_clean = data[X_imputed.columns]
y_clean = data['stage2_time']


# # 线性回归在原始数据上
# X_train, X_test, y_train, y_test = train_test_split(X_clean, y_clean, test_size=0.2, random_state=42)
# print(X_clean.shape)
# model = LinearRegression()
# model.fit(X_train, y_train)
# y_pred = model.predict(X_test)
# mae = mean_absolute_error(y_test, y_pred)
# mse = mean_squared_error(y_test, y_pred)
# print(mse)
# # (93, 7)
# # 0.025649956064984575

d = 7
f = 5
trails = 1
'''
5.1: training the optimal penalty parameter lambda and calculate the test error on X

    for i in range(20):  # for Xs
        lambda_i = 0 + 0.0001 * i   # lambda_i = 0.00001 + 0.0005 * i if for X
        
'''



loadData1 = np.load(os.path.dirname(os.getcwd()) + '/Result_data_for_MIIA/LHS_based_hospital_stage2_for_MIA.npy', allow_pickle=True)
LHS_based_hospital_pph = loadData1.tolist()
print(LHS_based_hospital_pph.keys())



# (2) for a fixed alpha, record penalty parameter lambda and corresponding MSE
#     remember to change 1,2,3,4 point with ⚠️
mse_krrs, lambda_krrs, condi_krrs = np.empty(shape=(15, 20)), np.empty(shape=(15, 20)), np.empty(shape=(15, 20))
mse_x = LHS_based_hospital_pph['krr_mse_X']
lambda_x = LHS_based_hospital_pph['krr_lambda_X']
index_x = np.argmin(mse_x, axis=0)
alpha1 = 0.0  # ---------------------- change 1 ⚠️
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    X_train, X_test, y_train, y_test = train_test_split(X_clean, y_clean, test_size=0.2, random_state=th)  # shuffle:bool, default=True
    X_train_numeric = X_train.drop(X_train.columns[[5, 6]], axis=1) # DataFrame
    X_train_nonumeric = X_train.iloc[:, [5, 6]]  # DataFrame
    X_train_combine = np.hstack((X_train_numeric, X_train_nonumeric))

    X_test_numeric = X_test.drop(X_test.columns[[5, 6]], axis=1) # DataFrame
    X_test_nonumeric = X_test.iloc[:, [5, 6]]  # DataFrame
    X_test_combine = np.hstack((X_test_numeric, X_test_nonumeric))

    # # (1) hybrid X_train_numeric
    # X_train_s_lhs = LHS_synthesizer(X_train_numeric)
    # X_train_numeric = np.asarray(X_train_numeric)  # <class 'pandas.core.frame.DataFrame'> 改为 <class 'numpy.ndarray'>
    # Xs_pair = pairing_X_Xs(X_train_numeric, X_train_s_lhs)
    # X_ah_lhs = alpha1 * X_train_numeric + (1 - alpha1) * Xs_pair
    #
    #
    # # combine age, bmi, and the other four attributes
    # X_ah_combine = np.hstack((X_ah_lhs, X_train_nonumeric))


    # (2)只采用纯生成数据
    X_train_s_lhs = LHS_synthesizer(X_train_numeric)  # (2000, 5)
    # X_train_nonumeric复制20份
    X_train_nonumeric = np.tile(X_train_nonumeric, (30, 1)) # (2000, 2)
    X_ah_combine = np.hstack((X_train_s_lhs, X_train_nonumeric)) # (2000, 7)


    axis0 = index_x[th]
    lambda_x_opt = lambda_x[axis0, th]
    generated_y = generate_y_krr(X_train_combine, y_train, X_ah_combine, d, lambda_x_opt)

    krr = parameter_lambda_krr_forplot(X_ah_combine, generated_y, f, d)
    mse_krr, lambda_krr, condi_krr = krr[0], krr[1], krr[2]

    mse_krr = np.array(mse_krr)
    mse_krrs[:, th] = np.squeeze(mse_krr)
    lambda_krr = np.array(lambda_krr)
    lambda_krrs[:, th] = np.squeeze(lambda_krr)

LHS_based_hospital_pph['krr_mse_Xs_2000_new'] = mse_krrs        # ---------------------- change 2 ⚠️
LHS_based_hospital_pph['krr_lambda_Xs_2000_new'] = lambda_krrs  # ---------------------- change 3 ⚠️



np.save(os.path.dirname(os.getcwd()) + '/Result_data_for_MIIA/LHS_based_hospital_stage2_for_MIA.npy', LHS_based_hospital_pph)
print('save LHS_based_hospital_stage2_for_MIA.npy done')
print(LHS_based_hospital_pph.keys())







# (3) calculate the test error using the optimal lambda for each trail
#     remember to change 1,2,3,4 point with ⚠️
test_mses = []
mse_x = LHS_based_hospital_pph['krr_mse_X']
lambda_x = LHS_based_hospital_pph['krr_lambda_X']
index_x = np.argmin(mse_x, axis=0)
mse_xs = LHS_based_hospital_pph['krr_mse_Xs_2000_new']        # ---------------- change 1 ⚠️
lambda_xs = LHS_based_hospital_pph['krr_lambda_Xs_2000_new']  # ---------------- change 2 ⚠️
index_xs = np.argmin(mse_xs, axis=0)
alpha1 =0.0  # ---------------------- change 3 ⚠️
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    X_train, X_test, y_train, y_test = train_test_split(X_clean, y_clean, test_size=0.2, random_state=th)  # shuffle:bool, default=True
    X_train_numeric = X_train.drop(X_train.columns[[5, 6]], axis=1) # DataFrame
    X_train_nonumeric = X_train.iloc[:, [5, 6]]  # DataFrame
    X_train_combine = np.hstack((X_train_numeric, X_train_nonumeric))

    X_test_numeric = X_test.drop(X_test.columns[[5, 6]], axis=1) # DataFrame
    X_test_nonumeric = X_test.iloc[:, [5, 6]]  # DataFrame
    X_test_combine = np.hstack((X_test_numeric, X_test_nonumeric))

    # # (1) hybrid X_train_numeric
    # X_train_s_lhs = LHS_synthesizer(X_train_numeric)
    # X_train_numeric = np.asarray(X_train_numeric)  # <class 'pandas.core.frame.DataFrame'> 改为 <class 'numpy.ndarray'>
    #
    # Xs_pair = pairing_X_Xs(X_train_numeric, X_train_s_lhs)
    # X_ah_lhs = alpha1 * X_train_numeric + (1 - alpha1) * Xs_pair
    #
    # # combine age, bmi, and the other four attributes
    # X_ah_combine = np.hstack((X_ah_lhs, X_train_nonumeric))
    # print(X_ah_combine.shape)


    # (2)只采用纯生成数据
    X_train_s_lhs = LHS_synthesizer(X_train_numeric)  # (2000, 5)
    # X_train_nonumeric复制20份
    X_train_nonumeric = np.tile(X_train_nonumeric, (30, 1)) # (2000, 2)
    X_ah_combine = np.hstack((X_train_s_lhs, X_train_nonumeric)) # (2000, 7)


    axis0 = index_x[th]
    lambda_x_opt = lambda_x[axis0, th]
    generated_y = generate_y_krr(X_train_combine, y_train, X_ah_combine, d, lambda_x_opt)

    axis0_xs = index_xs[th]
    lambda_xs_opt = lambda_xs[axis0_xs, th]
    Pred = Predictedkrr(X_ah_combine, generated_y, X_test_combine, y_test, d, lambda_xs_opt)
    test_mse = Pred[1]
    test_mses.append(test_mse)
    print('test_mses:', test_mses)


LHS_based_hospital_pph['mse_krr_Xs_2000_new'] = test_mses   # ------------------- change 4 ⚠️

# 我们要保存的是生成的Xs, generated_y
LHS_based_hospital_pph['generated_y_2000'] = generated_y
LHS_based_hospital_pph['X_ah_combine_2000'] = X_ah_combine


np.save(os.path.dirname(os.getcwd()) + '/Result_data_for_MIIA/LHS_based_hospital_stage2_for_MIA.npy', LHS_based_hospital_pph)
print('save LHS_based_hospital_stage2_for_MIA.npy done')
print(LHS_based_hospital_pph.keys())





# 0.5
# test_mses: [0.021802089217566423]
# test_mses: [0.01706853313797956]

# 0.7
# test_mses: [0.014182608805960293]

# 0.8 💎
# test_mses [0.01351266606406909]

# 1.0
# test_mses: [0.013687508791089995]


# test_mses: [0.09408539369932423]


# 纯生成======= stage1
# n 74
# n 2000
# test_mses: [0.014577767684180717]

# n 74
# n 2220
# test_mses: [0.014412421377953172]

# n 74 钻石
# n 3700
# test_mses: [0.014274555242676918]



# 纯生成======= stage2
# n 74
# n 1480
# test_mses: [0.0022886347758732445]

# n 74
# n 2220
# test_mses: [0.002862030911517976]

# n 74
# n 3700
# test_mses: [0.003153185181230516]





# X_train, X_test, y_train, y_test = train_test_split(X_clean, y_clean, test_size=0.2, random_state=42)
#
#
# # 线性回归
# model = LinearRegression()
# coeff_path = os.path.join(save_dir, f"{target}_linear_coefficients.pdf")
#
# # plot_feature_importance(model, X_train, X_test, y_train, y_test, target, coeff_path)

# 我现在的数据不够，需要根据现有的数据生成数据，请你严格使用我下面的方法指示去生成数据：











