# Fig12_C2_violin_5way.py
# Paper: Main Figure 12 (Section 7.2) -> Result_figure/C2_violin_5way.pdf
# Formerly: Simulation/fig_C2_violin_5way-use2.py. Run from this project folder.
# NOTE: this script's output values (83.5/91.8/26.0/17.6/5.1) differ slightly from the
# PDF shipped in the original zip (82.8/91.0/24.8/17.3/6.9) -- the final run apparently
# used a slightly different version. Kept as-is per the repo spec.
"""
实验 C 图（版式 2）：五组临床一致归因率小提琴图。
用法：把本文件放到  z_Real data_hospital_stage2/Simulation/  下，
      在 Simulation/ 中运行  python fig_C2_violin_5way.py
输出：{BASE}/Result_figure/clinical_figures/C2_violin_5way.pdf 和 .png
五组对比：
  QDLM top-5         QDLM 归因权重最大的 5 个训练样本
  GE_KNN top-5       GE_KNN 距离最近的 5 个训练样本（与其预测同一欧式距离度量）
  GE_LR top-5        GE_LR 影响函数绝对值最大的 5 个训练样本
                     （influence_i(q) = |残差_i * x_q'(X'X)^{-1} x_i|，
                       线性模型没有天然归因样本，这是文献标准做法）
  Random-5           随机抽 5 个训练样本（基线）
  Lowest-weight-5    QDLM 归因权重最小（且 >0）的 5 个训练样本（阴性对照）
一致性定义：与查询者同产次组 且 |年龄差|<=5 岁 且 |孕周差|<=7 天 的比例。
"""

import os, math, random
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ---------------- 画图全局样式（与正文图一致：Times New Roman + 橙/灰/蓝）----------------
from matplotlib import rcParams
rcParams.update({
    "font.family": "Times New Roman",   # 本机无该字体时 matplotlib 自动回退
    "font.size": 10.5, "mathtext.fontset": "stix",
    "axes.titlesize": 12, "axes.labelsize": 12,
    "xtick.labelsize": 12, "ytick.labelsize": 12, "legend.fontsize": 12,
    "axes.linewidth": 0.8, "axes.edgecolor": "#444444",
    "xtick.color": "black", "ytick.color": "black",
    "grid.color": "#DDDDDD", "grid.linewidth": 0.6,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})
C_QDLM = '#C55A11'   # QDLM 橙
C_KNN  = '#7F7F7F'   # GE_KNN 灰
C_LR = '#2C49B8'   # GE_LR 蓝
C_IDEAL, C_UNDER, C_OVER = '#729B79', '#B0483C', '#DFA45B'   # A2 堆叠语义色
C_TN, C_TP, C_FN, C_FP = '#729B79', '#3E6B4F', '#B0483C', '#DFA45B'  # B5 决策构成色

SCHEMES = ['AE_active,Hybrid', 'GE_KNN', 'GE_LR']
SLAB = {'AE_active,Hybrid': r'$AE_\mathrm{active, hybrid}$',
        'GE_KNN': r'$GE_\mathrm{KNN}$', 'GE_LR': r'$GE_\mathrm{LR}$'}
SC   = {'AE_active,Hybrid': C_QDLM, 'GE_KNN': C_KNN, 'GE_LR': C_LR}
MK   = {'AE_active,Hybrid': 'o', 'GE_KNN': 's', 'GE_LR': '^'}

# ---------------- 路径与数据 ----------------
BASE = os.path.dirname(os.path.abspath(__file__))   # script sits in the stage2 project folder
FIGDIR = os.path.join(BASE, 'Result_figure')
os.makedirs(FIGDIR, exist_ok=True)

data = np.load(os.path.join(BASE, 'Result_data/LHS_based_hospital_stage2.npy'),
               allow_pickle=True).tolist()
X = np.asarray(data['X_ah_combine_2000'])      # (2220, 7)，min-max 归一化
y = np.asarray(data['generated_y_2000'])       # (2220,)，第二产程时长（天）
hyb = np.load(os.path.join(BASE, 'Result_data/hospital_stage2_hybrid.npy'),
              allow_pickle=True).tolist()
knn_res = np.load(os.path.join(BASE, 'Result_data/hospital_stage2_knn.npy'),
                  allow_pickle=True).tolist()

# 列顺序 ['age','height','weight','BMI','total_days','gravidity','parity']
AGE_MIN, AGE_MAX = 19.0, 39.0
GEST_MIN, GEST_MAX = 231.0, 293.0
AGE_TOL  = 5.0 / (AGE_MAX - AGE_MIN)           # 5 岁 -> 归一化单位
GEST_TOL = 7.0 / (GEST_MAX - GEST_MIN)         # 7 天 -> 归一化单位
COL_AGE, COL_GEST, COL_PARITY = 0, 4, 6
TRIALS = 2
M_FIG, FEN = 6, 2                              # 正文用 m=6；m=(fen+1)*2

# 分产次 90 分位数阈值（“延长”的可操作化定义，用全数据集固定）
par_all = X[:, COL_PARITY]
P90 = {'nulliparous': np.quantile(y[par_all == 0], 0.9),
       'multiparous': np.quantile(y[par_all > 0], 0.9)}

# ---------------- 三个预测方案 ----------------
def mblocks_idx(n, m):
    a = n / m
    return [(int(a * i), int(a * (i + 1))) for i in range(m)]

def hybrid_predict(X_train, y_train, X_test, m, fen_now,
                   adapt_gau, adapt_epan, adapt_nai, adapt_knn, d=7, return_W=False):
    """AE_active,Hybrid（QDLM）逐样本复现；return_W=True 时返回归因权重矩阵。"""
    bounds = mblocks_idx(len(X_train), m)
    t = X_test.shape[0]
    fit_blocks = np.zeros((t, m)); active_m = np.zeros(t)
    W_blocks = np.zeros((t, len(X_train))) if return_W else None
    random.seed(0)
    assigns = [random.randint(1, 4) for _ in range(m)]
    for i, (s_, e_) in enumerate(bounds):
        b_x = X_train[s_:e_]; b_y = y_train[s_:e_]; n = e_ - s_
        xt = X_test.reshape(t, d, 1).repeat(n, axis=2)
        bx = np.repeat(b_x.T.reshape(1, d, n), t, axis=0)
        LOG = math.log(len(X_train), n)
        if assigns[i] == 1:
            h = min(1.0, adapt_gau[fen_now][i] ** LOG)
            dn = (np.linalg.norm((xt - bx) / h, axis=1)) ** 2
            w = np.exp(-dn)
        elif assigns[i] == 2:
            h = min(1.0, adapt_epan[fen_now][i] ** LOG)
            dn = (np.linalg.norm((xt - bx) / h, axis=1)) ** 2
            w = np.where((1 - dn) > 0, 1 - dn, 0)
        elif assigns[i] == 3:
            h = min(1.0, adapt_nai[fen_now][i] ** LOG)
            dn = np.linalg.norm((xt - bx) / h, axis=1)
            w = np.where(dn <= 1, 1.0, 0.0)
        else:
            k = math.ceil((adapt_knn[fen_now][i] ** LOG) / m)
            dn = np.linalg.norm(xt - bx, axis=1)
            idx = np.argsort(dn, axis=1)
            w = np.zeros((t, n)); w[np.arange(t)[:, None], idx[:, :k]] = 1.0
        a0 = w @ b_y; b0 = w.sum(1)
        fit = np.divide(a0, b0, out=np.zeros_like(a0), where=b0 != 0)
        active = (np.abs(fit) >= 1.0 / len(X_train)).astype(float)
        active_m += active; fit_blocks[:, i] = fit * active
        if return_W:
            wn = np.divide(w, b0[:, None], out=np.zeros_like(w), where=b0[:, None] != 0)
            W_blocks[:, s_:e_] = wn * active[:, None]
    pred = np.divide(fit_blocks.sum(1), active_m, out=np.zeros(t), where=active_m != 0)
    if return_W:
        W = np.divide(W_blocks, active_m[:, None],
                      out=np.zeros_like(W_blocks), where=active_m[:, None] != 0)
        return pred, W
    return pred

def ge_knn_predict(X_train, y_train, X_test, k):
    dn = np.linalg.norm(X_test[:, None, :] - X_train[None, :, :], axis=2)
    idx = np.argsort(dn, axis=1)
    return y_train[idx][:, :k].sum(1) / k

def lr_predict(X_train, y_train, X_test):
    return LinearRegression().fit(X_train, y_train).predict(X_test)

# ---------------- 指标函数 ----------------
def ideal_under_over(pred, actual, tol=0.20):
    band = tol * np.abs(actual); err = pred - actual
    return (np.mean(np.abs(err) <= band), np.mean(err < -band), np.mean(err > band))

def coherence_rate(X_ref, X_q, idx5):
    ref = X_ref[idx5]
    same_par = ((ref[:, COL_PARITY] == 0) == (X_q[COL_PARITY] == 0))
    age_ok  = np.abs(ref[:, COL_AGE]  - X_q[COL_AGE])  <= AGE_TOL
    gest_ok = np.abs(ref[:, COL_GEST] - X_q[COL_GEST]) <= GEST_TOL
    return np.mean(same_par & age_ok & gest_ok)

def savefig(fig, name):
    fig.savefig(os.path.join(FIGDIR, name + '.pdf'), bbox_inches='tight')
    fig.savefig(os.path.join(FIGDIR, name + '.png'), bbox_inches='tight', dpi=300)
    plt.close(fig); print('saved:', name)

# ---------------- 计算：实验 C 扩展（五组归因一致性，需要归因权重 W，稍慢）----------------
Crec = {k: [] for k in ['qdlm5', 'knn5', 'lr5', 'random5', 'bottom5']}
mse_rec = []
for th in range(TRIALS):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)
    pred_q, W = hybrid_predict(X_train, y_train, X_test, M_FIG, FEN,
                               hyb['local_h_gau'][th], hyb['local_h_epan'][th],
                               hyb['local_h_naive'][th], hyb['local_k'][th], return_W=True)
    mse_rec.append(np.mean((pred_q - y_test) ** 2))
    n_train, t = len(X_train), len(X_test)
    # GE_KNN：与预测相同的欧式距离，取最近 5 个
    D = np.linalg.norm(X_test[:, None, :] - X_train[None, :, :], axis=2)
    knn5_all = np.argsort(D, axis=1)[:, :5]
    # GE_LR：影响函数 |r_i * x_q'(X'X)^{-1} x_i| 最大的 5 个（含截距列）
    Xd = np.hstack([np.ones((n_train, 1)), X_train])
    Xt = np.hstack([np.ones((t, 1)), X_test])
    beta = np.linalg.lstsq(Xd, y_train, rcond=None)[0]
    resid = y_train - Xd @ beta
    Hv = Xt @ np.linalg.solve(Xd.T @ Xd, Xd.T)          # (t, n_train) 杠杆成分
    INFL = np.abs(Hv * resid[None, :])
    lr5_all = np.argsort(-INFL, axis=1)[:, :5]
    rng = np.random.default_rng(th)
    for qi in range(t):
        wrow = W[qi]
        top5 = np.argsort(wrow)[-5:]
        pos_w = np.where(wrow > 0)[0]
        bottom5 = pos_w[np.argsort(wrow[pos_w])[:5]] if len(pos_w) >= 5 else pos_w
        rand5 = rng.choice(n_train, size=5, replace=False)
        xq = X_test[qi]
        Crec['qdlm5'].append(coherence_rate(X_train, xq, top5))
        Crec['knn5'].append(coherence_rate(X_train, xq, knn5_all[qi]))
        Crec['lr5'].append(coherence_rate(X_train, xq, lr5_all[qi]))
        Crec['random5'].append(coherence_rate(X_train, xq, rand5))
        Crec['bottom5'].append(coherence_rate(X_train, xq, bottom5))
    print('trial %d done' % (th + 1))
stored = hyb['AE_lc_hybrid'][FEN, :TRIALS]
print('sanity: reproduced %.8f  stored %.8f  max diff %.2e'
      % (np.mean(mse_rec), np.mean(stored), np.abs(np.array(mse_rec) - stored).max()))
CKIND = ['qdlm5', 'knn5', 'lr5', 'random5', 'bottom5']
CLAB = ['$AE_\\mathrm{active, hybrid}$\ntop-5', '$GE_\\mathrm{KNN}$\ntop-5',
        '$GE_\\mathrm{LR}$\ntop-5', 'Random-5', 'Lowest-\nweight-5']
CCOL5 = [C_QDLM, C_KNN, C_LR, C_IDEAL, C_UNDER]   # 五组五色：橙/灰/蓝/绿/红褐
d6 = {k: np.asarray(Crec[k]) * 100 for k in CKIND}
print('means (%):', {k: round(float(d6[k].mean()), 1) for k in CKIND})

# ===== C2：五组归因一致性 小提琴+散点（m=6）=====
fig, ax = plt.subplots(figsize=(6.2, 3.4))
parts = ax.violinplot([d6[k] for k in CKIND], positions=range(5), widths=0.7,
                      showmeans=False, showmedians=True, showextrema=False)
for pc, c in zip(parts['bodies'], CCOL5):
    pc.set_facecolor(c); pc.set_alpha(0.55); pc.set_edgecolor('none')
parts['cmedians'].set_color('#333333'); parts['cmedians'].set_linewidth(1.2)
rng = np.random.default_rng(0)
for i, k in enumerate(CKIND):
    v = d6[k]
    idx = rng.choice(v.size, size=min(600, v.size), replace=False)
    xs = i + rng.uniform(-0.16, 0.16, idx.size)
    ax.scatter(xs, v[idx], s=3, color=CCOL5[i], alpha=0.18, edgecolor='none', zorder=3)
    ax.text(i, 105, '%.1f' % v.mean(), ha='center', fontsize=11,
            color='black', fontweight='bold')   # 顶部均值统一黑色
ax.set_xticks(range(5)); ax.set_xticklabels(CLAB, fontsize=12)
ax.set_ylabel('Clinical-coherence rate (%)', fontsize=12.9); ax.set_ylim(-5, 112),
ax.grid(axis='y', zorder=0); ax.set_axisbelow(True)
ax.spines[['top', 'right']].set_visible(False)
ax.set_title('Clinical coherence of attribution, $m=6$  (top numbers: group means)', pad=14, y=1.02, fontsize=13)
# ax.text(4.45, 108, 'top numbers: mean (%)', ha='right', fontsize=8, color='#888888')
fig.tight_layout()
# ---- 路径：在 Result_figure 下新建一个文件夹（名字自己改） ----
FIGDIR = os.path.join(BASE, 'Result_figure')
os.makedirs(FIGDIR, exist_ok=True)   # 文件夹不存在就自动新建

def savefig(fig, name):
    fig.savefig(os.path.join(FIGDIR, name + '.pdf'))
    plt.show()                        # 先保存再显示（show 会清空画布，顺序不能反）

savefig(fig, 'C2_violin_5way')
