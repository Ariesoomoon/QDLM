# Fig11_A2_stacked_100pct.py
# Paper: Main Figure 11 (Section 7.2) -> Result_figure/A2_stacked_100pct.pdf
# Formerly: Simulation/fig_A2_stacked_100pct-use1.py (verified numerically identical to the paper figure).
# Run from this project folder.
# -*- coding: utf-8 -*-
"""
实验 A 图（版式 2，推荐）：100% 堆叠水平条形图，与 warfarin Table 5 结构同构。
用法：把本文件放到  z_Real data_hospital_stage2/Simulation/  下，
      在 Simulation/ 中运行  python fig_A2_stacked_100pct-use.py
输出：{BASE}/Result_figure/clinical_figures/A2_stacked_100pct.pdf 和 .png
方案：AE_active,Hybrid（QDLM）；GE_KNN；GE_LR。
      QDLM 为原始 hybrid_algorithm 的逐样本复现，运行时自动与
      Result_data/hospital_stage2_hybrid.npy 的 AE_lc_hybrid 校验（m=6）。
数据与原始实验一致：LHS_based_hospital_stage2.npy（2220 条），
      train_test_split(test_size=0.2, random_state=th), th=0..39。
"""

import os, math, random
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

# ---------------- 画图全局样式（与正文图一致：Times New Roman + 橙/灰/蓝）----------------
from matplotlib import rcParams
rcParams.update({
    "font.family": "Times New Roman",   # 本机无该字体时 matplotlib 自动回退
    "font.size": 10.5, "mathtext.fontset": "stix",
    "axes.titlesize": 11.5, "axes.labelsize": 11,
    "xtick.labelsize": 10, "ytick.labelsize": 10, "legend.fontsize": 12,
    "axes.linewidth": 0.8, "axes.edgecolor": "#444444",
    "xtick.color": "#444444", "ytick.color": "#444444",
    "grid.color": "#DDDDDD", "grid.linewidth": 0.6,
    "pdf.fonttype": 42, "ps.fonttype": 42,
})
C_QDLM = 'black'   # QDLM 橙
C_KNN  = 'black'   # GE_KNN 灰
C_LR   = 'black'   # GE_LR 蓝
C_IDEAL, C_UNDER, C_OVER = '#729B79', '#B0483C', '#DFA45B'   # A2 堆叠语义色
C_TN, C_TP, C_FN, C_FP = '#729B79', '#3E6B4F', '#B0483C', '#DFA45B'  # B5 决策构成色

SCHEMES = ['AE_active,Hybrid', 'GE_KNN', 'GE_LR']
SLAB = {'AE_active,Hybrid': r'$AE_\mathrm{active, hybrid}$',
        'GE_KNN': r'$GE_\mathrm{KNN}$', 'GE_LR': r'$GE_\mathrm{LR}$'}
SC   = {'AE_active,Hybrid': C_QDLM, 'GE_KNN': C_KNN, 'GE_LR': C_LR}
MK   = {'AE_active,Hybrid': 'o', 'GE_KNN': 's', 'GE_LR': '^'}


# ---------------- 路径与数据 ----------------
BASE = os.path.dirname(os.path.abspath(__file__))   # script sits in the stage2 project folder
FIGDIR = os.path.join(BASE, 'Result_figure')
os.makedirs(FIGDIR, exist_ok=True)

data = np.load(os.path.join(BASE, 'Result_data/LHS_based_hospital_stage2.npy'),
               allow_pickle=True).tolist()
X = np.asarray(data['X_ah_combine_2000'])      # (2220, 7)，min-max 归一化
y = np.asarray(data['generated_y_2000'])       # (2220,)，第二产程时长（天）
hyb = np.load(os.path.join(BASE, 'Result_data/hospital_stage2_hybrid.npy'),
              allow_pickle=True).tolist()
knn_res = np.load(os.path.join(BASE, 'Result_data/hospital_stage2_knn.npy'),
                  allow_pickle=True).tolist()

# 列顺序 ['age','height','weight','BMI','total_days','gravidity','parity']
AGE_MIN, AGE_MAX = 19.0, 39.0
GEST_MIN, GEST_MAX = 231.0, 293.0
AGE_TOL  = 5.0 / (AGE_MAX - AGE_MIN)           # 5 岁 -> 归一化单位
GEST_TOL = 7.0 / (GEST_MAX - GEST_MIN)         # 7 天 -> 归一化单位
COL_AGE, COL_GEST, COL_PARITY = 0, 4, 6
TRIALS = 40
M_FIG, FEN = 6, 2                              # 正文用 m=6；m=(fen+1)*2

# 分产次 90 分位数阈值（“延长”的可操作化定义，用全数据集固定）
par_all = X[:, COL_PARITY]
P90 = {'nulliparous': np.quantile(y[par_all == 0], 0.9),
       'multiparous': np.quantile(y[par_all > 0], 0.9)}

# ---------------- 三个预测方案 ----------------
def mblocks_idx(n, m):
    a = n / m
    return [(int(a * i), int(a * (i + 1))) for i in range(m)]

def hybrid_predict(X_train, y_train, X_test, m, fen_now,
                   adapt_gau, adapt_epan, adapt_nai, adapt_knn, d=7, return_W=False):
    """AE_active,Hybrid（QDLM）逐样本复现；return_W=True 时返回归因权重矩阵。"""
    bounds = mblocks_idx(len(X_train), m)
    t = X_test.shape[0]
    fit_blocks = np.zeros((t, m)); active_m = np.zeros(t)
    W_blocks = np.zeros((t, len(X_train))) if return_W else None
    random.seed(0)
    assigns = [random.randint(1, 4) for _ in range(m)]
    for i, (s_, e_) in enumerate(bounds):
        b_x = X_train[s_:e_]; b_y = y_train[s_:e_]; n = e_ - s_
        xt = X_test.reshape(t, d, 1).repeat(n, axis=2)
        bx = np.repeat(b_x.T.reshape(1, d, n), t, axis=0)
        LOG = math.log(len(X_train), n)
        if assigns[i] == 1:
            h = min(1.0, adapt_gau[fen_now][i] ** LOG)
            dn = (np.linalg.norm((xt - bx) / h, axis=1)) ** 2
            w = np.exp(-dn)
        elif assigns[i] == 2:
            h = min(1.0, adapt_epan[fen_now][i] ** LOG)
            dn = (np.linalg.norm((xt - bx) / h, axis=1)) ** 2
            w = np.where((1 - dn) > 0, 1 - dn, 0)
        elif assigns[i] == 3:
            h = min(1.0, adapt_nai[fen_now][i] ** LOG)
            dn = np.linalg.norm((xt - bx) / h, axis=1)
            w = np.where(dn <= 1, 1.0, 0.0)
        else:
            k = math.ceil((adapt_knn[fen_now][i] ** LOG) / m)
            dn = np.linalg.norm(xt - bx, axis=1)
            idx = np.argsort(dn, axis=1)
            w = np.zeros((t, n)); w[np.arange(t)[:, None], idx[:, :k]] = 1.0
        a0 = w @ b_y; b0 = w.sum(1)
        fit = np.divide(a0, b0, out=np.zeros_like(a0), where=b0 != 0)
        active = (np.abs(fit) >= 1.0 / len(X_train)).astype(float)
        active_m += active; fit_blocks[:, i] = fit * active
        if return_W:
            wn = np.divide(w, b0[:, None], out=np.zeros_like(w), where=b0[:, None] != 0)
            W_blocks[:, s_:e_] = wn * active[:, None]
    pred = np.divide(fit_blocks.sum(1), active_m, out=np.zeros(t), where=active_m != 0)
    if return_W:
        W = np.divide(W_blocks, active_m[:, None],
                      out=np.zeros_like(W_blocks), where=active_m[:, None] != 0)
        return pred, W
    return pred

def ge_knn_predict(X_train, y_train, X_test, k):
    dn = np.linalg.norm(X_test[:, None, :] - X_train[None, :, :], axis=2)
    idx = np.argsort(dn, axis=1)
    return y_train[idx][:, :k].sum(1) / k

def lr_predict(X_train, y_train, X_test):
    return LinearRegression().fit(X_train, y_train).predict(X_test)

# ---------------- 指标函数 ----------------
def ideal_under_over(pred, actual, tol=0.20):
    band = tol * np.abs(actual); err = pred - actual
    return (np.mean(np.abs(err) <= band), np.mean(err < -band), np.mean(err > band))

def coherence_rate(X_ref, X_q, idx5):
    ref = X_ref[idx5]
    same_par = ((ref[:, COL_PARITY] == 0) == (X_q[COL_PARITY] == 0))
    age_ok  = np.abs(ref[:, COL_AGE]  - X_q[COL_AGE])  <= AGE_TOL
    gest_ok = np.abs(ref[:, COL_GEST] - X_q[COL_GEST]) <= GEST_TOL
    return np.mean(same_par & age_ok & gest_ok)

def savefig(fig, name):
    fig.savefig(os.path.join(FIGDIR, name + '.pdf'), bbox_inches='tight')
    fig.savefig(os.path.join(FIGDIR, name + '.png'), bbox_inches='tight', dpi=300)
    plt.close(fig); print('saved:', name)

# ---------------- 计算：实验 A（分产次 理想/低估/高估，20% 容差，40 次划分）----------------
GROUPS = ['nulliparous', 'multiparous']
Arec = {s: {g: [] for g in GROUPS} for s in SCHEMES}
mse_rec = []
for th in range(TRIALS):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)
    par_te = X_test[:, COL_PARITY]
    gmask = {'nulliparous': par_te == 0, 'multiparous': par_te > 0}
    pred_q = hybrid_predict(X_train, y_train, X_test, M_FIG, FEN,
                            hyb['local_h_gau'][th], hyb['local_h_epan'][th],
                            hyb['local_h_naive'][th], hyb['local_k'][th])
    mse_rec.append(np.mean((pred_q - y_test) ** 2))
    preds = {'AE_active,Hybrid': pred_q,
             'GE_KNN': ge_knn_predict(X_train, y_train, X_test, int(knn_res['global_k'][th])),
             'GE_LR': lr_predict(X_train, y_train, X_test)}
    for s in SCHEMES:
        for g in GROUPS:
            Arec[s][g].append(ideal_under_over(preds[s][gmask[g]], y_test[gmask[g]]))
stored = hyb['AE_lc_hybrid'][FEN, :TRIALS]
print('sanity: reproduced %.8f  stored %.8f  max diff %.2e'
      % (np.mean(mse_rec), np.mean(stored), np.abs(np.array(mse_rec) - stored).max()))
# 百分比 mean/sd：A100[(g, s)] = (mean[ideal,under,over], sd[...])
A100 = {(g, s): (np.mean(Arec[s][g], 0) * 100, np.std(Arec[s][g], 0) * 100)
        for g in GROUPS for s in SCHEMES}
GTIT = {'nulliparous': 'Nulliparous', 'multiparous': 'Multiparous'}
METS = ['ideal', 'under', 'over']
MLAB = {'ideal': 'Ideal', 'under': 'Underestimation', 'over': 'Overestimation'}

# ===== A2：实验 A 100% 堆叠水平条形图（与 warfarin Table 5 结构同构）=====
SEMC = {'ideal': C_IDEAL, 'under': C_UNDER, 'over': C_OVER}
fig, axes = plt.subplots(1, 2, figsize=(7.6, 2.9), sharey=True)
for ax, g in zip(axes, GROUPS):
    ypos = np.arange(len(SCHEMES))[::-1]
    left = np.zeros(len(SCHEMES))
    for mi, m in enumerate(METS):
        v = np.array([A100[(g, s)][0][mi] for s in SCHEMES])
        ax.barh(ypos, v, left=left, color=SEMC[m], edgecolor='white', linewidth=0.8,
                height=0.56, label=MLAB[m], zorder=3)
        for yi, vi, li in zip(ypos, v, left):
            if vi > 7:
                ax.text(li + vi / 2, yi, '%.1f' % vi, ha='center', va='center',
                        fontsize=11, color='white', zorder=4)
        left += v
    ax.set_yticks(ypos); ax.set_yticklabels([SLAB[s] for s in SCHEMES], fontsize=12)
    ax.set_xlim(0, 100); ax.set_xlabel('Percentage of test patients (%)', fontsize=12)
    ax.set_title(GTIT[g], pad=6)
    ax.spines[['top', 'right']].set_visible(False)
    ax.grid(axis='x', zorder=0); ax.set_axisbelow(True)
    for tl in ax.get_yticklabels():
        if 'AE_' in tl.get_text():
            tl.set_color(C_QDLM); tl.set_fontweight('bold')
handles, labels = axes[0].get_legend_handles_labels()
fig.legend(handles, labels, frameon=False, ncol=3, loc='lower center',
           bbox_to_anchor=(0.5, -0.04))
fig.tight_layout(rect=[0, 0.06, 1, 1])


# ---- 路径：在 Result_figure 下新建一个文件夹（名字自己改） ----
FIGDIR = os.path.join(BASE, 'Result_figure')
os.makedirs(FIGDIR, exist_ok=True)   # 文件夹不存在就自动新建

def savefig(fig, name):
    fig.savefig(os.path.join(FIGDIR, name + '.pdf'))
    plt.show()                        # 先保存再显示（show 会清空画布，顺序不能反）
savefig(fig, 'A2_stacked_100pct')





