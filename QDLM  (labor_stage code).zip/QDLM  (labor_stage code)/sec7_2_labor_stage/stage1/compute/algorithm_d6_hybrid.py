# Paper: Section 7.2 labor stage1 - compute script (writes/updates Result_data/hospital_stage1_*.npy).
# Formerly: Algorithm/algorithm_d6_hybrid.py. Run from this compute/ folder (project root = one level up).
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Function_same_block_warfarin import generate_data, hybrid_algorithm_test, MSE_pri_TQMA
# from Function_diff_block import generate_data, hybrid_algorithm_test, MSE_pri_TQMA
import numpy as np
from sklearn.model_selection import train_test_split
time_start = time.time()


'''0. including hybrid algorithm on original data and perturbed data;
for perturbed data, blocks number is fixed to 50, remember to change range(fen_num) to range(fen_num-1, fen_num) in "hybrid_algorithm_test"!!! '''


'''1. on original data'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/LHS_based_hospital_stage1.npy', allow_pickle=True)
hospital_data = loadData.tolist()
X = hospital_data['X_ah_combine_2000']
y = hospital_data['generated_y_2000']
print(hospital_data.keys())


# # load the localization parameters
# loadData_knn = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_knn.npy', allow_pickle=True)
# loadData_gau = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_gau.npy', allow_pickle=True)
# loadData_epan = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_epan.npy', allow_pickle=True)
# loadData_naive = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_naive.npy', allow_pickle=True)
# 
# 
# # hospital_stage1_hybrid = {}
# # np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_hybrid.npy', hospital_stage1_hybrid)
# # print('save hospital_stage1_hybrid.npy done')
# 
# # hospital_stage1_hybrid = {}
# hospital_stage1_hybrid['local_h_epan'] = loadData_epan.tolist()['local_h']
# hospital_stage1_hybrid['local_h_gau'] = loadData_gau.tolist()['local_h']
# hospital_stage1_hybrid['local_h_naive'] = loadData_naive.tolist()['local_h']
# hospital_stage1_hybrid['local_k'] = loadData_knn.tolist()['local_k']
# hospital_stage1_hybrid['AE_lc_epan'] = loadData_epan.tolist()['AE_log_actives']  # AE_lc_epan: AE_log_actives_epan
# hospital_stage1_hybrid['AE_lc_gau'] = loadData_gau.tolist()['AE_log_actives']
# hospital_stage1_hybrid['AE_lc_naive'] = loadData_naive.tolist()['AE_log_actives']
# hospital_stage1_hybrid['AE_lc_k'] = loadData_knn.tolist()['AE_log_actives']
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_hybrid.npy', hospital_stage1_hybrid)
# print('--------------------------------------------------------------save hospital_stage1_hybrid.npy done')
# print(hospital_stage1_hybrid.keys())
# print(loadData_naive.tolist()['AE_log_actives'].shape) # (25, 40)





loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_hybrid.npy', allow_pickle=True)
hospital_stage1_hybrid = loadData.tolist()
adapt_epan = loadData.tolist()['local_h_epan']
adapt_gau = loadData.tolist()['local_h_gau']
adapt_nai = loadData.tolist()['local_h_naive']
adapt_knn = loadData.tolist()['local_k']
AE_lc_hybrid = np.empty(shape=(25, 40))

# d = 7
# f = 5
# s = 2
# trails = 40
# fen_num, gap = 25, 2 # m = 2,4,...,50, 一共2200数据， 200测试
#
#
# # 1.3. Calculating the hybrid algorithm
# for th in range(trails):
#     # (1) create data and load parameter
#     print('                                                                                  trail:', th + 1)
#     X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)  # shuffle:bool, default=True
#
#     adapt_epan_1 = adapt_epan[th]
#     adapt_gau_1 = adapt_gau[th]
#     adapt_nai_1 = adapt_nai[th]
#     adapt_knn_1 = adapt_knn[th]
#
#     print('The first training data, X_train[0]: %s, y_train[0]: %s' % (X_train[0], y_train[0]))
#     AE = hybrid_algorithm_test(X_train, y_train, X_test, y_test, adapt_gau_1, adapt_epan_1, adapt_nai_1, adapt_knn_1, d, gap, fen_num)
#     AE = np.array(AE)
#     AE_lc_hybrid[:, th] = np.squeeze(AE)
#
#
# hospital_stage1_hybrid['AE_lc_hybrid'] = AE_lc_hybrid
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_hybrid.npy', hospital_stage1_hybrid)
# print('save hospital_stage1_hybrid.npy done')
# time_total = time.time() - time_start
# print('runing time:', time_total)




# # 保存线性回归的结果
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_hybrid.npy', allow_pickle=True)
# hospital_stage1_hybrid = loadData.tolist()
# loadData_gau = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_gau.npy', allow_pickle=True)
# hospital_stage1_gau = loadData_gau.tolist()
# hospital_stage1_hybrid['GEs_LR'] = hospital_stage1_gau['GEs_LR']
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_hybrid.npy', hospital_stage1_hybrid)
# print('--------------------------------------------------------------save hospital_stage1_hybrid.npy done')
# time_total = time.time() - time_start
# print('runing time:', time_total)
# print(hospital_stage1_hybrid.keys())



