# Paper: Section 7.2 labor stage1 - compute script (writes/updates Result_data/hospital_stage1_*.npy).
# Formerly: Algorithm/algorithm_d6_LR.py. Run from this compute/ folder (project root = one level up).
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Function_same_block_warfarin import GE_gaussiank, LE_gaussiank_test, \
    AE_gaussiank_test, AE_adapt_gaussiank_test, AE_active_gaussiank_test, LE_gaussiank_adapt_test
# from Function_diff_block import generate_data, GE_gaussiank, LE_gaussiank_test, AE_gaussiank_test, AE_adapt_gaussiank_test, AE_active_gaussiank_test
import numpy as np
from sklearn.model_selection import train_test_split
time_start = time.time()

import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import confusion_matrix, accuracy_score, mean_absolute_error, mean_squared_error
from sklearn.impute import SimpleImputer
import os
import warnings
import matplotlib.pyplot as plt
import seaborn as sns



'''1. Initialization'''

d = 7
f = 5
s = 2
trails = 40
fen_num, gap = 25, 2 # m = 2,4,...,50, 一共2200数据， 200测试

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/LHS_based_hospital_stage1.npy', allow_pickle=True)
hospital_data = loadData.tolist()
X = hospital_data['X_ah_combine_2000']
y = hospital_data['generated_y_2000']
print(hospital_data.keys())


# 50 type of divisions, 40trails, average by axis=1(by trail axis)
GEs = []


# load the localization parameters
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_gau.npy', allow_pickle=True)
hospital_stage1_gau = loadData.tolist()



'''2. 20 trails: calculating the MSE of GE, LE, AE(with h given global), AE_adapt, AE_log, AE_log_active with gaussian kernel'''
for th in range(trails):
    # (1) create data and load parameter
    print('                                                                                  trail:', th + 1)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)  # shuffle:bool, default=True

    print(X_train.shape)
    model = LinearRegression()
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    # mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    GEs.append(mse)
    print('GEs:', GEs)
    # (93, 7)
    # 0.025649956064984575


'''3. save MSE'''
hospital_stage1_gau['GEs_LR'] = GEs
np.save(os.path.dirname(os.getcwd()) + '/Result_data/hospital_stage1_gau.npy', hospital_stage1_gau)
print('--------------------------------------------------------------save hospital_stage1_gau.npy done')
time_total = time.time() - time_start
print('runing time:', time_total)





# gau
# GEs: [0.0016503050181717114, 0.001676440647848738, 0.001258102563893326, 0.0017361196566097825, 0.0017166639062808527, 0.0014629434738179462, 0.0017727021763100927, 0.0012686568486775043, 0.0018193417852338338, 0.0015900759855190063, 0.0015622422721371192, 0.0016105966165626405, 0.0015101733009947166, 0.0016513407499053813, 0.0015511585772432172, 0.001530567823041271, 0.0015739919869503293, 0.0013041136891658242, 0.0013593729369466626, 0.0020596962583645934, 0.0014475868053495514, 0.0014752062443596499, 0.0018903015957290425, 0.0014418227821055695, 0.0014761613520755828, 0.0015897083036680376, 0.001376057535342604, 0.001491924061644413, 0.0016922322449913658, 0.0014720014558735502, 0.0014696264403422567, 0.002003475847990578, 0.0014829104477884945, 0.0015343743952828152, 0.0013803531947557239, 0.0015148176269706895, 0.0013924797266361827, 0.0015186107047540072, 0.001775587758040307, 0.0014461027835328203]
# --------------------------------------------------------------save hospital_stage1_gau.npy done

# epan
# GEs: [0.0028187349467317956, 0.0030138187309949123, 0.002417809601014477, 0.0032533584796623793, 0.0026723511229559353, 0.0023460001697875256, 0.00299814981475475, 0.0023761335916351184, 0.0028184268789811667, 0.0028066379787616827, 0.002540007334358807, 0.0026505156189184117, 0.002487285667468599, 0.002361509193100079, 0.0024113304000879686, 0.0026056851615807045, 0.002587476422966237, 0.002493053226606113, 0.0022003752734315895, 0.003160106756575506, 0.003117743498007538, 0.002604566149471256, 0.0031480560227977847, 0.0025703504736602645, 0.002826066700499285, 0.0028263868806025455, 0.00244213316512897, 0.0025396985405461694, 0.0032168801612852353, 0.002757576846789781, 0.002126188011202495, 0.0035555944492164657, 0.0026428528285828367, 0.0029497676000533497, 0.002649150327822478, 0.0031485031674867, 0.002432501687702981, 0.00230154275252988, 0.0027344769747458387, 0.0028867009352335125]
# --------------------------------------------------------------save hospital_stage1_epan.npy done

#knn
# GEs: [0.0019786047647580123, 0.0018431675666225101, 0.0015819566293509822, 0.0020016725037494, 0.0020152629932250732, 0.0017275488921846347, 0.0017831052143455746, 0.0016616203829664306, 0.0020092606253837115, 0.002048094971522115, 0.0017579108254659587, 0.0019293300338743724, 0.00200476093892244, 0.0019171846359594485, 0.001763008005049489, 0.00207948251409231, 0.001733822152529652, 0.0017257499564943474, 0.0016820689776340218, 0.0022225018187284184, 0.001800184534002043, 0.0018053175021812765, 0.0018682038851748765, 0.0016613074192301709, 0.0016787791299004505, 0.001881856738649558, 0.0017995527571232925, 0.0017484542582050506, 0.0020587872221963337, 0.0018330023259176785, 0.0017582412317771064, 0.002232078775597919, 0.002023549421292638, 0.0018271162538187335, 0.0018433945113502336, 0.0016545019043278746, 0.0020041875367010184, 0.001785136065342529, 0.0019026800265432562, 0.0019064798783664063]
# --------------------------------------------------------------save hospital_stage1_knn.npy done

# Hybrid_Error: [0.00222847024171801, 0.0026006241801131533, 0.002640195328397975, 0.003211517652175527, 0.0028165191319388314, 0.0033782221659533675, 0.004507166501700485, 0.004752395976538091, 0.0047158687490548145, 0.004905478262743689, 0.0045993542965574565, 0.0050959399207067, 0.005107723111038955, 0.005070918937122761, 0.005180066208828234, 0.005382751623552466, 0.0057370460523907185, 0.0054356641926990475, 0.005935381109243928, 0.005933788315281791, 0.005769817464097466, 0.005693248346940355, 0.006470646449622137, 0.007558316399486161, 0.007329656308940013]
# save hospital_stage1_hybrid.npy done



