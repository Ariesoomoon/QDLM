# Paper: Appendix Figure 15 (warfarin per-agent distance bars, m=6) -> Fig_Warfarin_per_agent_contrast_m6.pdf
# Formerly: 可解释与隐私实验/Warfarin_Interp_CaseStudy_m6_final（距离柱状图）.py. Run from this project folder.
"""
================================================================================
Warfarin Interpretability Case Study -- per-agent top-attribution samples
                         (HYBRID, m = 6)
================================================================================
Fixed trial, ONE query from the test set, m = 6 parties (contiguous
equal-size blocks, warfarin mblocks). For every agent j (each using its OWN
algorithm from the seed-0 assignment: gau/epan/nai/knn, with its own h_j or
k_j after the logarithmic mechanism):
  * compute the local LAR weights over its local samples;
  * extract the TOP samples (top-5 core; extended up to top-10 via the rule
    "weight >= the 10th largest weight", ties broken by distance);
  * extract 5 UNIMPORTANT samples (smallest weights / farthest) for contrast.

Clinical design (different from the maternity case study):
  * QUERY: the BEST-PREDICTED test patient (strategy 'accurate') -- the
    case study should showcase a patient whose QDLAR prediction is nearly
    exact. NOTE: an extreme patient such as the maximum-dose one
    (230 mg/week) is unsuitable: no local block contains similar
    high-dose neighbors, so every agent's prediction collapses to the
    usual dose range (observed: 42.7 vs. 230.0 mg/week);
  * STRATA: AMIODARONE use (feature 5). Amiodarone inhibits warfarin
    metabolism, so co-medicated patients need markedly lower doses; it is
    the standard clinical stratifier for warfarin dosing (together with
    enzyme inducers, feature 4). We show that a high-dose query is explained
    by similar patients of the SAME medication status.

Outputs:
  Fig 1: 2x3 scatter panels per (feature pair x stratum) -- local samples in
         gray, top-5 attribution samples in orange (bubble = weight), query
         as a blue star; axes denormalized to original units;
  Fig 2: (a) per-agent mean distance of top-5 vs. unimportant samples to the
         query; (b) per-feature |difference| between each agent's top-5 mean
         vector and the query;
  Table: query + per-agent top-2 + 5 unimportant samples (console/.tex/.csv).

Data: warfarin_afterpreprocess.npy {'X': (5699,6), 'y': (5699,)}, features
= [Race, Age, Height, Weight, Enzyme inducer, Amiodarone] (order fixed by
preprocess.py); parameters: warfarin_hybrid.npy dicts {trial: {fen: array}};
split 80/20 as the accuracy pipeline.
================================================================================
"""

import os
import math
import random
import time
import numpy as np
import matplotlib.pyplot as plt
import warnings
from matplotlib import rcParams

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)
warnings.filterwarnings('ignore')

from sklearn.model_selection import train_test_split

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
DATA_DIR = os.environ.get('QDLAR_DATA_DIR', os.getcwd())
FIG_DIR = os.environ.get('QDLAR_FIG_DIR',
                         os.getcwd() + '/Result_figure/Interp_figure')
os.makedirs(FIG_DIR, exist_ok=True)

DATA_FILE = os.path.join(DATA_DIR, 'Result_data/warfarin_afterpreprocess.npy')
PARA_FILE = os.path.join(DATA_DIR, 'Result_data/warfarin_hybrid.npy')

DIM = 6
M_FIXED = 6
TOP_K = 5            # core top-k
TOP_MAX = 10         # extension cap via the threshold rule
N_UNIMPORTANT = 5    # contrast samples per agent (same count as TOP_K, so the
                     # top-vs-unimportant comparison is fair: 5 vs 5)
CASE_TRIAL = 0
# query selection:
#   'accurate' = test patient with the SMALLEST QDLAR test error (default;
#                the case study should showcase a well-predicted patient --
#                an extreme patient such as the 230 mg/week maximum-dose one
#                has no similar neighbors in ANY local block and every
#                agent's prediction collapses to the usual dose range);
#   'high'     = highest-dose test patient (clinically most delicate, but
#                typically poorly predicted, see above);
#   'median'   = median-dose patient; or an integer test-set index
QUERY_STRATEGY = 'accurate'

# !!! Column order of warfarin_afterpreprocess.npy, fixed by preprocess.py:
#     features = ['Race', 'Age', 'Height', 'Weight', 'Medications', 'Amiodarone']
#     (Medications was converted to the 0/1 enzyme-inducer indicator)
FEATURE_NAMES = ['Race', 'Age', 'Height', 'Weight',
                 'Enzyme inducer', 'Amiodarone']
# pairwise combinations of the three continuous features
# (indices: 1 = Age, 2 = Height, 3 = Weight)
PAIR_LIST = [(1, 3), (1, 2), (2, 3)]
AMIO_IDX = 5         # amiodarone feature index (stratifier)
# dose was MinMax-normalized in preprocess.py (scaler_y); for DISPLAY of the
# query / prediction in mg/week (original unit)
Y_MIN, Y_MAX = 2.1, 230.0
# LabelEncoder classes of the 'Race' column (alphabetical order)
RACE_LABELS = {0: 'Asian', 1: 'Black or African American', 2: 'Unknown',
               3: 'White'}
# NWK = Nadaraya-Watson kernel estimator: the Gaussian / Epanechnikov / naive
# agents are all NWK with different kernels; KNN is the k-nearest-neighbor one
ALGO_NAMES = {1: 'NWK(Gaussian)', 2: 'NWK(Epan)', 3: 'NWK(naive)', 4: 'KNN'}

# ----------------------------------------------------------------------------
# Denormalization (DISPLAY ONLY -- does not affect any computation)
# ----------------------------------------------------------------------------
# preprocess.py normalized X with sklearn's MinMaxScaler FIT ON THE FULL
# 5,699 records, feature by feature:
#     x_norm = (x_orig - min) / (max - min)
#     <==>   x_orig = x_norm * (max - min) + min          (*)
# Because the scaler was fit on the full dataset, every normalized column
# spans exactly [0, 1], and the (min, max) constants below -- reconstructed
# from the raw data (warfarin_addINR.csv) through the SAME preprocessing
# (age -> decade medians, dose >= 315 dropped, mean/mode imputation) --
# are EXACT, not estimates:
#   Race:    LabelEncoder over 4 classes (Asian / Black or African American /
#            Unknown / White) -> 0..3
#   Age:     decade medians 14.5, 24.5, ..., 84.5, 95.0
#   Height / Weight: continuous (cm / kg), mean-imputed
#   Enzyme inducer / Amiodarone: binary 0/1
FEAT_MINMAX = {
    0: (0.0, 3.0),        # Race (LabelEncoder, 4 classes)
    1: (14.5, 95.0),      # Age (years; decade medians)
    2: (124.97, 202.0),   # Height (cm)
    3: (30.0, 237.7),     # Weight (kg)
    4: (0.0, 1.0),        # Enzyme inducer (0/1)
    5: (0.0, 1.0),        # Amiodarone (0/1)
}


def denorm(v, f):
    """Map normalized value(s) of feature f back to the original units via (*)."""
    lo, hi = FEAT_MINMAX[f]
    return v * (hi - lo) + lo


# ----------------------------------------------------------------------------
# Warfarin block partition: identical to Function_same_block_warfarin.mblocks
# (contiguous equal-size slices; no shuffle -- the split already shuffles)
# ----------------------------------------------------------------------------
def mblocks(x, y, m):
    blocks = []
    for i in range(m):
        a = len(x) / m
        begin, end = int(a * i), int(a * (i + 1))
        blocks.append((x[begin:end], y[begin:end]))
    return blocks


# ----------------------------------------------------------------------------
# Exact replication of the hybrid assignment & per-block kernels
# ----------------------------------------------------------------------------
def get_assignments(m):
    random.seed(0)
    return [random.randint(1, 4) for _ in range(m)]


def get_fen_dict(entry, fen):
    if fen in entry:
        return entry[fen]
    return entry[str(fen)]


def get_block_params(para, trial, m):
    fen = m // 2 - 1
    return {
        1: np.atleast_1d(get_fen_dict(get_fen_dict(para['local_h_gau'], trial), fen)).astype(float),
        2: np.atleast_1d(get_fen_dict(get_fen_dict(para['local_h_epan'], trial), fen)).astype(float),
        3: np.atleast_1d(get_fen_dict(get_fen_dict(para['local_h_naive'], trial), fen)).astype(float),
        4: np.atleast_1d(get_fen_dict(get_fen_dict(para['local_k'], trial), fen)).astype(float),
    }


def agent_local_model(x_q, b_x, b_y, N, m, a, params_i):
    """One agent's weights/fit/param for query x_q (hybrid kernels + log rule)."""
    n = len(b_x)
    LOG = math.log(N, n)
    # every h below is AFTER the logarithmic mechanism, i.e. h_j^{log}
    if a == 1:
        h = min(1.0, params_i ** LOG)
        dis = np.linalg.norm((b_x - x_q) / h, axis=1) ** 2
        w = np.exp(-dis)
        param_str = '$h_j^{\\mathrm{log}}$ = %.3f' % h
    elif a == 2:
        h = min(1.0, params_i ** LOG)
        dis = np.linalg.norm((b_x - x_q) / h, axis=1) ** 2
        w = np.where(1 - dis > 0, 1 - dis, 0.0)
        param_str = '$h_j^{\\mathrm{log}}$ = %.3f' % h
    elif a == 3:
        h = min(1.0, params_i ** LOG)
        dis = np.linalg.norm((b_x - x_q) / h, axis=1)
        w = (dis <= 1).astype(float)
        param_str = '$h_j^{\\mathrm{log}}$ = %.3f' % h
    else:
        k = int(math.ceil((params_i ** LOG) / m))
        k = max(1, min(k, n))
        dis = np.linalg.norm(b_x - x_q, axis=1)
        w = np.zeros(n)
        w[np.argsort(dis)[:k]] = 1.0
        # localization parameter for KNN (Definition 3): k-NN radius,
        # clipped to (0,1] as Definition 3 assumes h_j in (0,1] (in the
        # sparse 6-d space the radius can slightly exceed 1)
        radius = min(np.sort(dis)[k - 1], 1.0)
        param_str = '$h_j^{\\mathrm{log}}$ = %.3f' % radius
    fit = 0.0 if w.sum() == 0 else float(np.dot(w, b_y) / w.sum())
    active = abs(fit) >= 1.0 / N
    dist = np.linalg.norm(b_x - x_q, axis=1)
    return w, fit, active, dist, param_str


# ----------------------------------------------------------------------------
def run_case_study():
    print('\n' + '=' * 74)
    print('Warfarin per-agent top-attribution case study (HYBRID, m = %d, '
          'query strategy = %s)' % (M_FIXED, QUERY_STRATEGY))
    print('=' * 74)
    dat = np.load(DATA_FILE, allow_pickle=True).tolist()
    X, y = dat['X'], dat['y']
    X_vic, X_test, y_vic, y_test = train_test_split(
        X, y, test_size=0.2, random_state=CASE_TRIAL)
    para = np.load(PARA_FILE, allow_pickle=True).tolist()
    params = get_block_params(para, CASE_TRIAL, M_FIXED)
    assigns = get_assignments(M_FIXED)

    N = len(X_vic)
    # --- diagnostic: check the normalization range of every feature ---------
    print('\n  [denorm check] per-feature min/max of the normalized data:')
    for f in range(DIM):
        print('    %-16s min = %.4f, max = %.4f'
              % (FEATURE_NAMES[f], X_vic[:, f].min(), X_vic[:, f].max()))
    blocks = mblocks(X_vic, y_vic, M_FIXED)

    # query: 'accurate' (default) / high-dose / median-dose / fixed index
    if QUERY_STRATEGY == 'accurate':
        # scan the whole test set: run the QDLAR aggregate for every test
        # patient and keep the one with the smallest |prediction - truth|.
        # (6 agents x ~1,140 test patients -- cheap, exact same model as below)
        print('\n  scanning the test set for the best-predicted query ...')
        errs = np.zeros(len(X_test))
        for c in range(len(X_test)):
            fits_c = []
            for j in range(M_FIXED):
                b_x, b_y = np.array(blocks[j][0]), np.array(blocks[j][1])
                a = assigns[j]
                _, fit_c, act_c, _, _ = agent_local_model(
                    X_test[c], b_x, b_y, N, M_FIXED, a, params[a][j])
                if act_c:
                    fits_c.append(fit_c)
            pred_c = np.mean(fits_c) if fits_c else 0.0
            errs[c] = abs(pred_c - y_test[c])
        qid = int(np.argmin(errs))
        print('  best query: test sample #%d, |pred - y| = %.4f (normalized)'
              ' = %.2f mg/week' % (qid, errs[qid],
                                   errs[qid] * (Y_MAX - Y_MIN)))
        p10, p25, p50 = np.percentile(errs * (Y_MAX - Y_MIN), [10, 25, 50])
        print('  test-error distribution (mg/week): 10%% = %.1f, 25%% = %.1f,'
              ' median = %.1f' % (p10, p25, p50))
    elif QUERY_STRATEGY == 'high':
        qid = int(np.argmax(y_test))
    elif QUERY_STRATEGY == 'median':
        qid = int(np.argsort(y_test)[len(y_test) // 2])
    else:
        qid = int(QUERY_STRATEGY)
    x_q, y_q = X_test[qid], y_test[qid]
    # -------------------- QUERY REPORT (for the paper) ----------------------
    # original inputs (exact inverse of the preprocessing MinMaxScaler) and
    # the prediction in both normalized and original (mg/week) units
    y_dose = y_q * (Y_MAX - Y_MIN) + Y_MIN
    print('\n' + '-' * 60)
    print('  QUERY REPORT  (test sample #%d, strategy = %s)'
          % (qid, QUERY_STRATEGY))
    print('-' * 60)
    print('  original inputs:')
    print('    Race           = %s (code %d)'
          % (RACE_LABELS[int(round(denorm(x_q[0], 0)))],
             int(round(denorm(x_q[0], 0)))))
    print('    Age            = %.1f years (decade median)'
          % denorm(x_q[1], 1))
    print('    Height         = %.1f cm' % denorm(x_q[2], 2))
    print('    Weight         = %.1f kg' % denorm(x_q[3], 3))
    print('    Enzyme inducer = %d' % int(round(denorm(x_q[4], 4))))
    print('    Amiodarone     = %d' % int(round(denorm(x_q[5], 5))))
    print('  normalized input vector:')
    print('    x_q = [%s]' % ', '.join('%.4f' % v for v in x_q))
    print('  true dose (normalized)      y = %.4f' % y_q)
    print('  true dose (original)        y = %.1f mg/week' % y_dose)
    print('  (QDLAR prediction and test error are reported below, after the')
    print('   per-agent models are computed)')
    print('-' * 60)
    feat_range = np.maximum(X_vic.max(axis=0) - X_vic.min(axis=0), 1e-12)

    agents = []
    for j in range(M_FIXED):
        b_x, b_y = np.array(blocks[j][0]), np.array(blocks[j][1])
        a = assigns[j]
        w, fit, active, dist, pstr = agent_local_model(
            x_q, b_x, b_y, N, M_FIXED, a, params[a][j])
        w_norm = w / w.sum() if w.sum() > 0 else w

        # ranking: weight desc, then distance asc
        order = sorted(range(len(b_x)), key=lambda i: (-w_norm[i], dist[i]))
        # threshold rule: weight >= 10th largest weight, between TOP_K and TOP_MAX
        tau = w_norm[order[min(TOP_MAX, len(order)) - 1]]
        k_hi = int(np.sum(w_norm >= tau - 1e-15))
        k_hi = int(np.clip(k_hi, TOP_K, TOP_MAX))
        top_idx = order[:k_hi]
        unimp_idx = sorted(range(len(b_x)),
                           key=lambda i: (w_norm[i], -dist[i]))[:N_UNIMPORTANT]

        agents.append({'bx': b_x, 'by': b_y, 'a': a, 'w': w_norm, 'fit': fit,
                       'active': active, 'dist': dist, 'pstr': pstr,
                       'top': top_idx, 'unimp': unimp_idx})
        d_top = np.mean([np.linalg.norm((b_x[i] - x_q) / feat_range)
                         for i in top_idx[:TOP_K]])
        d_un = np.mean([np.linalg.norm((b_x[i] - x_q) / feat_range)
                        for i in unimp_idx])
        print('  Agent %d [%s, %s]: fit = %.3f, active = %s, highlighted = %d, '
              'mean dist(top-%d) = %.3f, mean dist(unimportant) = %.3f'
              % (j + 1, ALGO_NAMES[a], pstr, fit, active, k_hi, TOP_K,
                 d_top, d_un))

    act_fits = [ag['fit'] for ag in agents if ag['active']]
    pred = np.mean(act_fits) if act_fits else np.mean([ag['fit'] for ag in agents])
    print('\n  QDLAR prediction (normalized) = %.4f, true y = %.4f'
          % (pred, y_q))
    print('  QDLAR prediction (original)   = %.1f mg/week, true dose = %.1f mg/week'
          % (pred * (Y_MAX - Y_MIN) + Y_MIN,
             y_q * (Y_MAX - Y_MIN) + Y_MIN))
    print('  test error                    = %.2f mg/week'
          % (abs(pred - y_q) * (Y_MAX - Y_MIN)))
    print('  per-agent predictions (normalized): %s'
          % ', '.join('A%d=%.3f' % (j + 1, ag['fit'])
                      for j, ag in enumerate(agents)))

    # ------------- VERIFICATION (for the figure caption) --------------------
    # QDLAR aggregates the QUALIFIED agents' predictions by a simple average:
    #     y_hat(x_q) = (1/m*) * sum_{j in A(x_q)} f_j(x_q),  m* = |A(x_q)|.
    # The unit transform phi(v) = (Y_MAX-Y_MIN)*v + Y_MIN (mg/week) is
    # AFFINE, hence phi(y_hat) = (1/m*) * sum phi(f_j): the QDLAR prediction
    # in mg/week is EXACTLY the average of the active agents' predicted
    # values shown in the panel titles.
    print('\n' + '-' * 60)
    print('  VERIFICATION: QDLAR prediction = average of the active '
          'agents\' predicted values')
    print('-' * 60)
    for j, ag in enumerate(agents):
        print('    Agent %d [%s]: fit = %.4f --> %.2f mg/week, active = %s'
              % (j + 1, ALGO_NAMES[ag['a']], ag['fit'],
                 ag['fit'] * (Y_MAX - Y_MIN) + Y_MIN, ag['active']))
    act = [ag for ag in agents if ag['active']]
    avg_norm = float(np.mean([ag['fit'] for ag in act]))
    avg_mg = float(np.mean([ag['fit'] * (Y_MAX - Y_MIN) + Y_MIN
                            for ag in act]))
    pred_mg = pred * (Y_MAX - Y_MIN) + Y_MIN
    print('    m* = %d active agent(s)' % len(act))
    print('    (1/m*)*sum f_j     (normalized) = %.10f' % avg_norm)
    print('    QDLAR prediction   (normalized) = %.10f' % pred)
    print('    |difference|                    = %.3e' % abs(avg_norm - pred))
    print('    (1/m*)*sum phi(f_j) (mg/week)   = %.4f' % avg_mg)
    print('    phi(QDLAR prediction) (mg/week) = %.4f' % pred_mg)
    print('    |difference|                    = %.3e' % abs(avg_mg - pred_mg))

    # ------------------------------- table ---------------------------------
    header = ['Agent', 'Algorithm', 'Tag', 'Sample'] + FEATURE_NAMES \
             + ['y', 'Weight', 'Dist']
    rows = [['Query', '-', '-', '#%d' % qid]
            + ['%.3f' % v for v in x_q] + ['%.3f' % y_q, '-', '-']]
    for j, ag in enumerate(agents):
        for r, i in enumerate(ag['top'][:2], 1):   # table: top-2 only
            rows.append(['A%d' % (j + 1), ALGO_NAMES[ag['a']],
                         'Top-%d' % r, str(i)]
                        + ['%.3f' % v for v in ag['bx'][i]]
                        + ['%.3f' % ag['by'][i], '%.4f' % ag['w'][i],
                           '%.3f' % ag['dist'][i]])
        for r, i in enumerate(ag['unimp'], 1):
            rows.append(['A%d' % (j + 1), ALGO_NAMES[ag['a']],
                         'Unimp-%d' % r, str(i)]
                        + ['%.3f' % v for v in ag['bx'][i]]
                        + ['%.3f' % ag['by'][i], '%.4f' % ag['w'][i],
                           '%.3f' % ag['dist'][i]])
    tex = ['\\begin{table}[htbp]', '\\centering',
           '\\caption{Top-2 attribution and unimportant local samples of '
           'every agent for the query (hybrid QDLAR, warfarin, $m$=%d).}'
           % M_FIXED,
           '\\label{tab:warfarin_per_agent_attribution}',
           '\\begin{tabular}{llll%s}' % ('c' * (len(header) - 4)),
           '\\toprule', ' & '.join(header) + ' \\\\', '\\midrule']
    tex.append(' & '.join(rows[0]) + ' \\\\')
    tex.append('\\midrule')
    for r in rows[1:]:
        tex.append(' & '.join(r) + ' \\\\')
    tex += ['\\bottomrule', '\\end{tabular}', '\\end{table}']
    tex_file = os.path.join(FIG_DIR, 'Table_warfarin_per_agent_top5.tex')
    with open(tex_file, 'w') as f:
        f.write('\n'.join(tex))
    csv_file = os.path.join(FIG_DIR, 'Table_warfarin_per_agent_top5.csv')
    with open(csv_file, 'w') as f:
        f.write(','.join(header) + '\n')
        for r in rows:
            f.write(','.join(r) + '\n')
    print('  Saved: %s\n  Saved: %s' % (tex_file, csv_file))

    # --------------------------- figure 1: scatter panels -------------------
    # 3 continuous-feature pairs x amiodarone strata. Amiodarone inhibits
    # warfarin metabolism (co-medicated patients need lower doses) and is the
    # standard medication stratifier for warfarin dosing. Robust to the
    # normalization: the smallest normalized value corresponds to "no
    # amiodarone".
    amio0 = np.sort(np.unique(X_vic[:, AMIO_IDX]))[0]
    tol = 1e-6
    q_amio = x_q[AMIO_IDX]
    print('\n  query (normalized): amiodarone = %.3f --> %s'
          % (q_amio, 'amiodarone-free' if q_amio <= amio0 + tol
             else 'amiodarone user'))

    # stratum labels describe WHICH local samples are shown in gray
    strata = [
        ('all', 'all local samples', lambda V: np.ones(len(V), dtype=bool)),
        ('amio_free', 'only amiodarone-free local samples',
         lambda V: V[:, AMIO_IDX] <= amio0 + tol),
        ('amio_user', 'only amiodarone-user local samples',
         lambda V: V[:, AMIO_IDX] > amio0 + tol),
    ]

    # for (fi, fj) in PAIR_LIST:
    #     for s_tag, s_label, s_mask in strata:
    #         fig, axes = plt.subplots(2, 3, figsize=(19, 11))
    #         for j, ag in enumerate(agents):
    #             ax = axes[j // 3, j % 3]
    #             mask = s_mask(ag['bx'])
    #             # plot coordinates are mapped back to the original units via
    #             # denorm(); sizes/weights are unaffected (display only)
    #             ax.scatter(denorm(ag['bx'][mask, fi], fi),
    #                        denorm(ag['bx'][mask, fj], fj), s=16,
    #                        color='#CCCCCC', alpha=0.7, zorder=1,
    #                        label='Local training samples')
    #             core = [i for i in ag['top'][:TOP_K] if mask[i]]
    #             if core:
    #                 # bubble area scaled RELATIVE to the agent's own largest
    #                 # weight (max = 540 pt^2): keeps the proportionality
    #                 # within each agent while preventing huge bubbles from
    #                 # spilling out of the panel (KNN agents can have
    #                 # w_norm ~ 0.2, i.e. s ~ 700 under an absolute scaling)
    #                 w_core = ag['w'][core]
    #                 ax.scatter(denorm(ag['bx'][core, fi], fi),
    #                            denorm(ag['bx'][core, fj], fj),
    #                            s=90 + 450 * w_core / w_core.max(),
    #                            color='#D97A4A', edgecolor='darkred',
    #                            linewidth=1.0, zorder=3,
    #                            label='Top-%d attribution samples' % TOP_K)
    #             ax.scatter(denorm(x_q[fi], fi), denorm(x_q[fj], fj), s=320,
    #                        marker='*', c='blue', zorder=4, label='Query')
    #             # pad the axes so bubbles sitting on the boundary (e.g. the
    #             # query at the maximal age) are not clipped
    #             ax.margins(x=0.14, y=0.14)
    #             ax.set_xlabel(FEATURE_NAMES[fi], fontsize=19)
    #             ax.set_ylabel(FEATURE_NAMES[fj], fontsize=19)
    #             ax.tick_params(labelsize=13)
    #             # two-line title: avoids overlap between adjacent panels;
    #             # the predicted value is mapped back to the ORIGINAL unit
    #             # (mg/week) via dose = fit*(Y_MAX-Y_MIN)+Y_MIN (display only)
    #             pred_mg = ag['fit'] * (Y_MAX - Y_MIN) + Y_MIN
    #             ax.set_title('Agent %d [%s, %s]\npredicted value = %.1f mg/week'
    #                          % (j + 1, ALGO_NAMES[ag['a']], ag['pstr'],
    #                             pred_mg), fontsize=18, weight='bold')
    #             # identical legend in every panel -> show it only in the
    #             # first, together with the bubble-size note
    #             if j == 0:
    #                 ax.legend(loc='best', fontsize=15, framealpha=0.9)
    #                 ax.text(0.97, 0.03,
    #                         "larger bubble = stronger influence\n"
    #                         "on this agent's prediction",
    #                         transform=ax.transAxes, ha='right', va='bottom',
    #                         fontsize=11.5, style='italic', color='#555555')
    #             ax.spines['top'].set_visible(False)
    #             ax.spines['right'].set_visible(False)
    #         plt.suptitle('Local training samples each agent relies on '
    #                      '($m$ = %d, %s)' % (M_FIXED, s_label),
    #                      fontsize=25, weight='bold', y=0.99)
    #         plt.tight_layout(rect=[0, 0, 1, 0.96])
    #         out1 = os.path.join(
    #             FIG_DIR, 'Fig_Warfarin_scatter_%s_vs_%s_%s.pdf'
    #                      % (FEATURE_NAMES[fi].replace(' ', '_'),
    #                         FEATURE_NAMES[fj].replace(' ', '_'), s_tag))
    #         plt.savefig(out1, dpi=600, format='pdf', bbox_inches='tight',
    #                     pad_inches=0.2)
    #         plt.show()
    #         print('Saved: %s' % out1)

    # ----------------- figure 2: contrast + feature similarity --------------
    fig = plt.figure(figsize=(17, 7.5))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.3, 1.25], wspace=0.4)

    # (a) mean normalized distance: top-5 vs unimportant, per agent
    ax = fig.add_subplot(gs[0, 0])
    d_top = [np.mean([np.linalg.norm((ag['bx'][i] - x_q) / feat_range)
                      for i in ag['top'][:TOP_K]]) for ag in agents]
    d_un = [np.mean([np.linalg.norm((ag['bx'][i] - x_q) / feat_range)
                     for i in ag['unimp']]) for ag in agents]
    xpos = np.arange(M_FIXED)
    width = 0.42
    ax.bar(xpos - width / 2, d_top, width, color='#D97A4A', edgecolor='white',
           label='Top-%d attribution samples' % TOP_K)
    ax.bar(xpos + width / 2, d_un, width, color='royalblue', edgecolor='white',
           label='Unimportant samples')
    for j in range(M_FIXED):
        ax.text(xpos[j] - width / 2, d_top[j] + 0.01, '%.2f' % d_top[j],
                ha='center', va='bottom', fontsize=16, rotation=30, color='#8C4A20')
        ax.text(xpos[j] + width / 2, d_un[j] + 0.01, '%.2f' % d_un[j],
                ha='center', va='bottom', fontsize=16, rotation=30, color='royalblue')
    ax.set_xticks(xpos)
    ax.set_xticklabels(['Agent %d' % (j + 1) for j in range(M_FIXED)],
                       fontsize=18, rotation=30)
    ax.set_ylim(0, max(d_un) * 1.4)
    ax.set_ylabel('Mean distance to query', fontsize=20)
    ax.tick_params(axis='y', labelsize=16)
    # ax.set_title('(a) Top-attribution samples are much\ncloser to the query',
    #              fontsize=20, weight='bold', pad=12)
    ax.legend(loc='upper left', ncol=1, fontsize=18, framealpha=0.9)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', linestyle='--', alpha=0.3)



    # (b) per-feature |difference| of top-5 mean vs query (normalized)
    ax = fig.add_subplot(gs[0, 1])

    diff = np.array([np.abs(ag['bx'][ag['top'][:TOP_K]].mean(axis=0) - x_q)
                     / feat_range for ag in agents])
    un_all = np.concatenate([ag['bx'][ag['unimp']] for ag in agents])
    diff_un = np.abs(un_all.mean(axis=0) - x_q) / feat_range
    mat = np.vstack([diff, diff_un])
    # custom colormap matching the paper palette: white -> light orange ->
    # the attribution orange #D97A4A -> deep brown
    from matplotlib.colors import LinearSegmentedColormap
    cmap_diff = LinearSegmentedColormap.from_list(
        'attr_orange',
        ['#FFFFFF', '#FBEAD3', '#F2C894', '#D97A4A', '#A85A2A', '#6E3A14'])
    im = ax.imshow(mat, cmap=cmap_diff, aspect='auto', vmin=0,
                   vmax=max(mat.max(), 0.05))
    ax.set_xticks(range(DIM))
    # feature labels on TOP of the heatmap
    ax.set_xticklabels(FEATURE_NAMES, fontsize=18, rotation=25, ha='left')
    ax.xaxis.set_ticks_position('top')
    ax.set_yticks(range(M_FIXED + 1))
    ax.set_yticklabels(['Agent %d top-%d' % (j + 1, TOP_K)
                        for j in range(M_FIXED)]
                       + ['Unimportant'], fontsize=18)
    vmax_t = im.get_clim()[1]
    for a in range(M_FIXED + 1):
        for b in range(DIM):
            # white text on dark cells for readability
            txt_c = 'white' if mat[a, b] > 0.55 * vmax_t else 'black'
            ax.text(b, a, '%.2f' % mat[a, b], ha='center', va='center',
                    fontsize=19, color=txt_c)
    # ax.set_title('(b) Feature-wise difference to the query',
    #              fontsize=20, weight='bold', pad=12)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    # plt.suptitle('Top-attribution samples are similar to the query, '
    #              'unimportant ones are not ($m$ = %d)' % M_FIXED,
    #              fontsize=22, weight='bold', y=1.0)

    # plt.tight_layout(rect=[0, 0, 1, 0.2])

    out2 = os.path.join(FIG_DIR, 'Fig_Warfarin_per_agent_contrast_m6.pdf')
    plt.savefig(out2, dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out2)


if __name__ == '__main__':
    time_start = time.time()
    run_case_study()
    print('\nTotal time: %.1f seconds' % (time.time() - time_start))
