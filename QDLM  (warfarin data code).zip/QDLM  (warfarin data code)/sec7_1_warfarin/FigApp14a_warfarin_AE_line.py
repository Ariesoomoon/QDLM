# Paper: Appendix Figure 14a (warfarin AE vs m, line version) -> Result_figure/hybrid_AE.pdf
# Formerly: Simulation/simulation_d6_mix(line, use).py. Run from this project folder.
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import time, os
time_start = time.time()


from matplotlib.ticker import FuncFormatter
import pdb, time, os
import sys

from matplotlib import rcParams
fontsize_specific = 16
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
'''1. load data'''
loadData_gau = np.load(os.getcwd() + '/Result_data/warfarin_gau.npy', allow_pickle=True)
warfarin_gau = loadData_gau.tolist()
MSE_gau_mean = [np.mean(warfarin_gau['GEs'])] * 50
LE_gau_mean = np.mean(warfarin_gau['LEs'], axis=1)

loadData_knn = np.load(os.getcwd() + '/Result_data/warfarin_knn.npy', allow_pickle=True)
warfarin_knn = loadData_knn.tolist()
MSE_knn_mean = [np.mean(warfarin_knn['GEs'])] * 50
LE_knn_mean = np.mean(warfarin_knn['LEs'], axis=1)

loadData = np.load(os.getcwd() + '/Result_data/warfarin_hybrid.npy', allow_pickle=True)
warfarin_hybrid = loadData.tolist()
AE_lc_epan_mean = np.mean(loadData.tolist()['AE_lc_epan'], axis=1)
AE_lc_gau_mean = np.mean(loadData.tolist()['AE_lc_gau'], axis=1)
AE_lc_naive_mean = np.mean(loadData.tolist()['AE_lc_naive'], axis=1)
AE_lc_knn_mean = np.mean(loadData.tolist()['AE_lc_k'], axis=1)
AE_lc_hybrid_mean = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)
MSE_lr_mean = [np.mean(warfarin_hybrid['MSE_lr'])] * 50      # linear regression
print(warfarin_hybrid.keys())
print(MSE_lr_mean)


'''figure 1: compare the AE_log_active with optimal algorithm (AE) gaussian kernel'''
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
M_nwk = [i for i in range(2, 101, 2)]


M_nwk = M_nwk[::2]
AE_lc_knn_mean = AE_lc_knn_mean[::2]
AE_lc_naive_mean = AE_lc_naive_mean[::2]
AE_lc_epan_mean = AE_lc_epan_mean[::2]
AE_lc_gau_mean = AE_lc_gau_mean[::2]
AE_lc_hybrid_mean = AE_lc_hybrid_mean[::2]
MSE_lr_mean = MSE_lr_mean[::2]
MSE_knn_mean = MSE_knn_mean[::2]

# ax.plot(M_nwk, LE_gau_mean, c='royalblue', linestyle=':', linewidth=2.0)

ax.plot(M_nwk, AE_lc_knn_mean, c='forestgreen', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk, AE_lc_naive_mean, c='darkcyan', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk, AE_lc_epan_mean, c='tomato', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk, AE_lc_gau_mean, c='darkslateblue', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk, MSE_lr_mean, c='royalblue', marker='s',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk, MSE_knn_mean, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk, AE_lc_hybrid_mean, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=5)


plt.legend(['$AE_\mathrm{active, Knn}$', '$AE_\mathrm{active, Naive}$', '$AE_\mathrm{active, Epan}$', '$AE_\mathrm{active, Gau}$','$GE_\mathrm{LR}$', '$GE_\mathrm{Knn}$', '$AE_\mathrm{active, hybrid}$'], ncol=2, loc='upper left', fontsize='14')
ax.set_xlabel('Number of local agents', fontsize='18')
ax.set_ylabel('MSE', fontsize='18')
# plt.yscale('log')
plt.ylim(0.00365, 0.0045)
plt.savefig(os.getcwd() + '/Result_figure/hybrid_AE.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()













