# Paper: Appendix Figure 14b (warfarin AE, m=10 zoom bar version) -> Result_figure/Hybrid_AE_warfarin.pdf
# Formerly: Simulation/simulation_d6_mix(bar).py. Run from this project folder.
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import pdb, time, os
import sys

from matplotlib import rcParams
fontsize_specific = 16
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
'''1. load data'''
loadData_naive = np.load(os.getcwd() + '/Result_data/warfarin_naive.npy', allow_pickle=True)
warfarin_naive = loadData_naive.tolist()
print(warfarin_naive.keys())
GEs_naive = [np.mean(warfarin_naive['GEs'])] * 50
LEs_naive = np.mean(warfarin_naive['LEs'], axis=1)
AE_log_actives_naive = np.mean(warfarin_naive['AE_log_actives'], axis=1)

loadData_gau = np.load(os.getcwd() + '/Result_data/warfarin_gau.npy', allow_pickle=True)
warfarin_gau = loadData_gau.tolist()
print(warfarin_gau.keys())
GEs_gau = [np.mean(warfarin_gau['GEs'])] * 50
LEs_gau = np.mean(warfarin_gau['LEs'], axis=1)
AE_log_actives_gau = np.mean(warfarin_gau['AE_log_actives'], axis=1)

loadData_epan = np.load(os.getcwd() + '/Result_data/warfarin_epan.npy', allow_pickle=True)
warfarin_epan = loadData_epan.tolist()
GEs_epan = [np.mean(warfarin_epan['GEs'])] * 50
LEs_epan = np.mean(warfarin_epan['LEs'], axis=1)
AE_log_actives_epan = np.mean(warfarin_epan['AE_log_actives'], axis=1)

loadData_knn = np.load(os.getcwd() + '/Result_data/warfarin_knn.npy', allow_pickle=True)
warfarin_knn = loadData_knn.tolist()
GEs_knn = [np.mean(warfarin_knn['GEs'])] * 50
LEs_knn = np.mean(warfarin_knn['LEs'], axis=1)
AE_log_actives_knn = np.mean(warfarin_knn['AE_log_actives'], axis=1)
print(min(warfarin_knn['global_k']))  # 36

loadData_knn = np.load(os.getcwd() + '/Result_data/warfarin_hybrid.npy', allow_pickle=True)
warfarin_hybrid = loadData_knn.tolist()
GEs_lr = [np.mean(warfarin_hybrid['MSE_lr'])] * 50
AE_lc_hybrid_mean = np.mean(warfarin_hybrid['AE_lc_hybrid'], axis=1)


fig = plt.figure(tight_layout=True)
# (1) MSE
colors = ['black', 'royalblue', 'brown']
labels = ['$GE_\mathrm{Knn}$', '$GE_\mathrm{LR}$', '$AE_\mathrm{active, hybrid}$']
# labels = ['$AE_{ori}$', '$AE_{TQMA4}$', '$AE_{TQMA4Swap38}$', '$AE_{TQMA4Swap38, attack}$']
data=[GEs_knn[4], GEs_lr[4], AE_lc_hybrid_mean[4]]
x_range = np.arange(0,6,2)
plt.bar(x_range, data, align='center', alpha=0.7, color=colors, tick_label=labels, width=1.2)
for a,b in zip(x_range,data):
    plt.text(a,b,'%.5f'%b,ha='center',va='bottom',fontsize=18)

plt.ylim(0.00365, 0.004)

plt.ylabel('MSE', fontsize='18')
plt.xlabel('When there are 10 local agents', fontsize='18')
# plt.title('Effective of bounded swapping for doctors (attack 1322)\n(d=5, m=20)')
plt.savefig(os.getcwd() + '/Result_figure/Hybrid_AE_warfarin.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()
