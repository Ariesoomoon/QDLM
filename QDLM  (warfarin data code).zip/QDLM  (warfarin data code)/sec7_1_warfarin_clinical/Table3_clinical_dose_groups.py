# Table3_clinical_dose_groups.py
# Paper: Main Table 3 (Section 7.1) - prints the clinical dose-group percentages and counts.
# Formerly: Simulation/cilnical percentage and num.py. Run from this project folder.
import numpy as np
from Function_same_block_warfarin_epan import clinical_percentage
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import pdb, time, os
import sys

'''
1. 
应该在每一次分割里进行y和fit的计算
20trail，每次都对应一个不同的训练集和测试集y_tes、一组局部参数、一组fit，所以应该在每一次trail中进行相应的fit和y_tes的计算，然后对percentage求平均。

2. 
perc_low_under: percentage of patients with an underestimate dose of warfarin in patients requiring low actual dose wafarin for a therapeutic effect.
perc_low_over: percentage of patients with an overestimate dose of warfarin in patients requiring low actual dose wafarin for a therapeutic effect.
perc_low_ideal: percentage of patients with an ideal dose of warfarin in patients requiring low actual dose wafarin for a therapeutic effect.
perc_high_under: percentage of patients with an underestimate dose of warfarin in patients requiring high actual dose wafarin for a therapeutic effect.
perc_intermediate_ideal: percentage of patients with an ideal dose of warfarin in patients requiring intermediate actual dose wafarin for a therapeutic effect.
因此，一个不错的算法应该在perc_low_over， perc_high_under， perc_intermediate_ideal取值较大。

3. why np.empty(shape=(9, 20)) ?
nine Comparative Measure according to the clinical value
'''


'''1. load data'''
# loadData = np.load(os.getcwd() + '/Result_data/warfarin_afterpreprocess.npy', allow_pickle=True)
# warfarin_afterpreprocess = loadData.tolist()
# X = warfarin_afterpreprocess['X']
# y = warfarin_afterpreprocess['y']
# print(warfarin_afterpreprocess.keys())


print('-------------------------------------------------------------- warfarin_epan')
loadData_epan = np.load(os.getcwd() + '/Result_data/warfarin_epan.npy', allow_pickle=True)
warfarin_epan = loadData_epan.tolist()
# print(warfarin_epan.keys())
# print(warfarin_epan['percs_AE'])
print(warfarin_epan['percs_AE'].shape)
percs_AE_epan = np.mean(warfarin_epan['percs_AE'], axis=1)
print('percs_AE_epan:', percs_AE_epan)
percs_LE_epan = np.mean(warfarin_epan['percs_LE'], axis=1)
print('percs_LE_epan:', percs_LE_epan)
percs_GE_epan = np.mean(warfarin_epan['percs_GE'], axis=1)
print('percs_GE_epan:',percs_GE_epan)


print('-------------------------------------------------------------- warfarin_gau')
loadData_gau = np.load(os.getcwd() + '/Result_data/warfarin_gau.npy', allow_pickle=True)
warfarin_gau = loadData_gau.tolist()
# print(warfarin_gau.keys())
# print(warfarin_gau['percs_AE'])
print(warfarin_gau['percs_AE'].shape)
percs_AE_gau = np.mean(warfarin_gau['percs_AE'], axis=1)
print('percs_AE_gau:', percs_AE_gau)
percs_LE_gau = np.mean(warfarin_gau['percs_LE'], axis=1)
print('percs_LE_gau:', percs_LE_gau)
percs_GE_gau = np.mean(warfarin_gau['percs_GE'], axis=1)
print('percs_GE_gau:', percs_GE_gau)


print('-------------------------------------------------------------- warfarin_naive')
loadData_naive = np.load(os.getcwd() + '/Result_data/warfarin_naive.npy', allow_pickle=True)
warfarin_naive = loadData_naive.tolist()
# print(warfarin_naive.keys())
# print(warfarin_naive['percs_AE'])
print(warfarin_naive['percs_AE'].shape)
percs_AE_naive = np.mean(warfarin_naive['percs_AE'], axis=1)
print('percs_AE_naive:', percs_AE_naive)
percs_LE_naive = np.mean(warfarin_naive['percs_LE'], axis=1)
print('percs_LE_naive:', percs_LE_naive)
percs_GE_naive = np.mean(warfarin_naive['percs_GE'], axis=1)
print('percs_GE_naive:', percs_GE_naive)


print('-------------------------------------------------------------- warfarin_knn')
loadData_knn = np.load(os.getcwd() + '/Result_data/warfarin_knn.npy', allow_pickle=True)
warfarin_knn = loadData_knn.tolist()
# print(warfarin_knn.keys())
# print(warfarin_knn['percs_AE'])
print(warfarin_knn['percs_AE'].shape)
percs_AE_knn = np.mean(warfarin_knn['percs_AE'], axis=1)
print('percs_AE_knn:', percs_AE_knn)
percs_LE_knn = np.mean(warfarin_knn['percs_LE'], axis=1)
print('percs_LE_knn:', percs_LE_knn)
percs_GE_knn = np.mean(warfarin_knn['percs_GE'], axis=1)
print('percs_GE_knn:', percs_GE_knn)


print('-------------------------------------------------------------- warfarin_lr')
loadData_hybrid = np.load(os.getcwd() + '/Result_data/warfarin_hybrid.npy', allow_pickle=True)
warfarin_hybrid = loadData_hybrid.tolist()
print(warfarin_hybrid.keys())
print(warfarin_hybrid['percs_lr'].shape)
percs_GE_lr = np.mean(warfarin_hybrid['percs_lr'], axis=1)
print('percs_GE_lr:', percs_GE_lr)



# patients number requiring low, intermediate and high actual dose
num_lows = np.mean(warfarin_hybrid['num_lows'])
num_highs = np.mean(warfarin_hybrid['num_highs'])
num_intermediates = np.mean(warfarin_hybrid['num_intermediates'])
print('num_lows:', num_lows)
print('num_intermediates:', num_intermediates)
print('num_highs:', num_highs)
# num_lows: 368.2  -- 368
# num_intermediates: 632.3 -- 632
# num_highs: 139.5 -- 140






print('table 4: ------------------------------------------------------------------------------------------------------')
print('-------------------------------------------------------------- warfarin_naive')
loadData_naive = np.load(os.getcwd() + '/Result_data/warfarin_naive.npy', allow_pickle=True)
warfarin_naive = loadData_naive.tolist()
# print(warfarin_naive.keys())
# print(warfarin_naive['percs_AE'])
print(warfarin_naive['percs_AE'].shape)
percs_AE_naive = np.mean(warfarin_naive['percs_AE'], axis=1)
print('percs_AE_naive:', percs_AE_naive)
percs_LE_naive = np.mean(warfarin_naive['percs_LE'], axis=1)
print('percs_LE_naive:', percs_LE_naive)
percs_GE_naive = np.mean(warfarin_naive['percs_GE'], axis=1)
print('percs_GE_naive:', percs_GE_naive)


print('-------------------------------------------------------------- warfarin_lr')
loadData_hybrid = np.load(os.getcwd() + '/Result_data/warfarin_hybrid.npy', allow_pickle=True)
warfarin_hybrid = loadData_hybrid.tolist()
print(warfarin_hybrid['percs_lr'].shape)
percs_GE_lr = np.mean(warfarin_hybrid['percs_lr'], axis=1)
print('percs_GE_lr:', percs_GE_lr)


print('-------------------------------------------------------------- warfarin_hybrid')
print(warfarin_hybrid['percs_AE'].shape)
percs_AE_hybrid = np.mean(warfarin_hybrid['percs_AE'], axis=1)
print('percs_AE_hybrid:', percs_AE_hybrid)

'''
percs_AE [0.00125237 0.87138143 0.1273662  0.93686462 0.00228327 0.06085211
 0.22836084 0.20521927 0.56641989]
percs_LE [0.02194744 0.82923348 0.14881909 0.8967982  0.0061628  0.097039
 0.26976663 0.21476644 0.51546693]
percs_GE [0.00233285 0.83726842 0.16039873 0.9011885  0.00411964 0.09469185
 0.24051406 0.20913399 0.55035195]

'''

print('percs_LE_naive:', percs_LE_naive)
LE_naive_std = np.std(warfarin_naive['percs_LE'], axis=1)
print('LE_naive_std:', LE_naive_std)


print('percs_AE_naive:', percs_AE_naive)
AE_naive_std = np.std(warfarin_naive['percs_AE'], axis=1)
print('AE_naive_std:', AE_naive_std)


print('percs_GE_naive:', percs_GE_naive)
GE_naive_std = np.std(warfarin_naive['percs_GE'], axis=1)
print('GE_naive_std:', GE_naive_std)


print('percs_AE_hybrid:', percs_AE_hybrid)
AE_hybrid_std = np.std(warfarin_hybrid['percs_AE'], axis=1)
print('AE_hybrid_std:', AE_hybrid_std)


print('percs_GE_lr:', percs_GE_lr)
GE_LR_std = np.std(warfarin_hybrid['percs_lr'], axis=1)
print('GE_LR_std:', GE_LR_std)



