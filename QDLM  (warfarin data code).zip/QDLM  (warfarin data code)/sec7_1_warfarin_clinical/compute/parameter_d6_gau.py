# Paper: Main Table 3 (Section 7.1 clinical) - parameter tuning (initializes Result_data/warfarin_*.npy).
# Formerly: Parameter training/parameter_d6_gau.py. Run from this compute/ folder (project root = one level up).
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from Function_same_block_warfarin_gau import generate_data, global_parameter_h, local_parameter_h_test
# from Function_diff_block import generate_data, global_parameter_h, local_parameter_h_test
import numpy as np
from sklearn.model_selection import train_test_split
time_start = time.time()


'''0. replace to Gaussian kernel of all cv-5 function in Function_same_block_gau.py !!!!'''


'''1. Initialization'''
d = 6
f = 5
s = 2
trails = 100
# fen_num, gap = 50, 2 # m = 2,4,...,60
fen_num, gap = 21, 1  # m = 21
warfarin_gau = {}
# global_h = []
local_h = {}

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/warfarin_afterpreprocess.npy', allow_pickle=True)
warfarin_afterpreprocess = loadData.tolist()
X = warfarin_afterpreprocess['X']
y = warfarin_afterpreprocess['y']
print(warfarin_afterpreprocess.keys())

# loadData_gau = np.load(os.path.dirname(os.getcwd()) + '/Result_data/warfarin_gau.npy', allow_pickle=True)
# warfarin_gau = loadData_gau.tolist()



'''2. training parameter for global and local: 20 random seed for 20 trails, with different splitting'''
for th in range(trails):
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=th)  # shuffle:bool, default=True
    print('\n--------------------------------------------------------------trail:', th)

    # gh_trail1 = global_parameter_h(X_train, y_train, f, d)
    # global_h.append(gh_trail1)
    # print(global_h)
    lh_trail1 = local_parameter_h_test(X_train, y_train, f, d, fen_num, gap)
    local_h[th] = lh_trail1



'''3. save parameters'''
# warfarin_gau['global_h'] = global_h
warfarin_gau['local_h'] = local_h
# # warfarin_gau['local_h_diff'] = local_h
np.save(os.path.dirname(os.getcwd()) + '/Result_data/warfarin_gau.npy', warfarin_gau)
print('--------------------------------------------------------------save warfarin_gau.npy done')
#pdb.set_trace()
