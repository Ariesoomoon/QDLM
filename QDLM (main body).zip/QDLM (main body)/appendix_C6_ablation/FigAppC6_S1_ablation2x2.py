"""
================================================================================
FigAppC6_S1_ablation2x2.py  --  Sensitivity analysis S1 -- 2x2 ablation: LOGARITHMIC MECHANISM x QUALIFICATION
Paper: Appendix Figure 16 (Section C.6 ablation)
================================================================================
Question: QDLAR adds two components on top of a plain distributed average
(AVM) of local LAR estimates -- the logarithmic localization mechanism
(h_j -> h_j^LOG, LOG = log(N, n_j); k_j -> ceil(k_j^LOG / m)) and the
qualification rule (|fit_j(x)| >= 1/N). Is each of them useful, and how
does their benefit evolve as the same TOTAL data (N = 10,000) is split
into more and more local agents (m = 5, 10, ..., 350)?

Four variants are compared on IDENTICAL data and IDENTICAL trained local
parameters (loaded from trails_d1_hybrid.npy / trails_d5_hybrid.npy --
no retraining, only the prediction switches change):
    (1) QDLAR        : log ON  + qualification ON   (= stored AE_lc_hybrid,
                                                       used as a sanity check)
    (2) log-only     : log ON  + qualification OFF  (plain m-average)
    (3) QC-only      : log OFF + qualification ON   (raw CV h_j / k_j)
    (4) plain AVM    : log OFF + qualification OFF  (standard distributed)
Reference: centralized oracle GE_gau (stored in the same npy).

Outputs (Result_figure/appendix_C6):
    Fig A: MSE-vs-m curves of the 4 variants + oracle, d=1 / d=5 panels
           (mean over 20 trials, shaded = +/- 1 std);
    Fig B: grouped bars at m = 50 / 150 / 300 (the 2x2 at a glance);
    Fig C: qualified-agent ratio m*/m vs m (log vs. no-log);
    Fig D: excess error (MSE - oracle) vs m on log-log axes;
    S1_ablation_d{d}.npy: all curves for later reuse.

Reproducibility: np.random.seed(trial) + generate_data() regenerates the
EXACT data of the original experiments; random.seed(0) reproduces the
algorithm assignment. Variant (1) must coincide with the stored
AE_lc_hybrid -- the script prints the discrepancy as a sanity check.
================================================================================
"""

import os
import math
import random
import time
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
DATA_DIR = os.environ.get('QDLAR_DATA_DIR', os.path.dirname(os.getcwd()))
FIG_DIR = os.environ.get('QDLAR_FIG_DIR',
                         os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C6')
os.makedirs(FIG_DIR, exist_ok=True)

TRIALS = 20
FEN_NUM = 70          # m = 5, 10, ..., 350
GAP = 5
TRAIN_N = 10000       # TOTAL sample size -- fixed while m grows
TEST_N = 1000
DIMS = [1, 5]
PARAM_FILES = {1: 'trails_d1_hybrid.npy', 5: 'trails_d5_hybrid.npy'}
M_LIST = [(i + 1) * GAP for i in range(FEN_NUM)]
M_SHOW = [50, 150, 300]          # m values for the grouped-bar figure

VARIANTS = ['QDLAR (log+QC)', 'log-only', 'QC-only', 'plain AVM']
V_COLORS = {'QDLAR (log+QC)': 'brown', 'log-only': 'royalblue',
            'QC-only': 'forestgreen', 'plain AVM': 'gray'}
V_MARKERS = {'QDLAR (log+QC)': '^', 'log-only': 'o',
             'QC-only': 's', 'plain AVM': 'd'}


# ----------------------------------------------------------------------------
# Data generating process -- EXACT copies from Function_same_block_* so the
# regenerated data coincides with the original experiments bit by bit
# ----------------------------------------------------------------------------
def create_y_g1(data):
    y = np.empty(shape=(len(data)))
    for i in range(len(data)):
        if (data[i] >= 0) and (data[i] <= 0.5):
            y[i] = max(((1.0 - 2 * data[i]) ** 3), 0) * (1.0 + 6 * data[i])
        else:
            y[i] = 0
    return y


def create_y_g2(data):
    y = np.empty(shape=(len(data)))
    for i in range(len(data)):
        norm_row = np.linalg.norm(data[i])
        if (norm_row >= 0) and (norm_row <= 1):
            y[i] = (max((1 - norm_row), 0) ** 5) * (1 + 5 * norm_row) \
                   + 0.2 * norm_row ** 2
        else:
            y[i] = 0.2 * norm_row ** 2
    return y


def generate_data(train, test, d):
    """Same consumption order of np.random as the original pipeline:
    X_train -> X_test -> noise (train only). Seed must be set by the caller."""
    X_train = np.random.uniform(0.0, 1.0, train)
    X_test = np.random.uniform(0.0, 1.0, test)
    if d == 1:
        noise = np.random.normal(0, 0.1, train)
        y_train = create_y_g1(X_train) + noise
        y_test = create_y_g1(X_test)
    else:
        noise = np.random.normal(0, 0.1, train[0])
        y_train = create_y_g2(X_train) + noise
        y_test = create_y_g2(X_test)
    return X_train, y_train, X_test, y_test


def mblocks(x, y, m):
    """Contiguous equal-size blocks (same as the original mblocks)."""
    blocks = []
    for i in range(m):
        a = len(x) / m
        begin, end = int(a * i), int(a * (i + 1))
        blocks.append((x[begin:end], y[begin:end]))
    return blocks


def get_fen(entry, fen):
    """The npy dict keys may be int or str depending on the save version."""
    if fen in entry:
        return entry[fen]
    return entry[str(fen)]


# ----------------------------------------------------------------------------
# One agent's local prediction on the whole test set (vectorized)
# ----------------------------------------------------------------------------
def agent_fit(x_tes, b_x, b_y, N, m, assign, param, use_log, d):
    """fit_j(x) for every test point x (shape (t,)).
    use_log=True  : h_j^LOG with LOG=log(N, n_j) (clipped to 1), or
                    k_j' = ceil(k_j^LOG / m) for KNN;
    use_log=False : the raw CV-trained h_j / k_j (no localization).
    Note: for d = 1 the original pipeline stores X as a 1-d array --
    reshape everything to (n, d) here for uniform handling."""
    x_tes = np.asarray(x_tes).reshape(-1, d)
    b_x = np.asarray(b_x).reshape(-1, d)
    b_y = np.asarray(b_y).ravel()
    n = len(b_x)
    if assign in (1, 2, 3):
        if use_log:
            LOG = math.log(N, n)
            h = min(1.0, param ** LOG)
        else:
            h = float(param)
        diff = (x_tes[:, None, :] - b_x[None, :, :]) / h       # (t, n, d)
        if assign == 1:      # Gaussian, s = 2
            w = np.exp(-np.sum(diff ** 2, axis=2))
        elif assign == 2:    # Epanechnikov
            u = np.sum(diff ** 2, axis=2)
            w = np.where(1 - u > 0, 1 - u, 0.0)
        else:                # naive (uniform)
            u = np.sqrt(np.sum(diff ** 2, axis=2))
            w = (u <= 1).astype(float)
        a0 = w @ b_y
        b0 = w.sum(axis=1)
        fit = np.divide(a0, b0, out=np.zeros_like(a0), where=b0 != 0)
    else:                    # KNN
        if use_log:
            LOG = math.log(N, n)
            k = int(math.ceil((param ** LOG) / m))
        else:
            k = int(round(param))
        k = max(1, min(k, n))
        dis = np.sqrt(np.sum((x_tes[:, None, :] - b_x[None, :, :]) ** 2, axis=2))
        idx = np.argsort(dis, axis=1)[:, :k]
        fit = b_y[idx].mean(axis=1)
    return np.nan_to_num(fit)


# ----------------------------------------------------------------------------
# Main computation: the 2x2 ablation for one dimension d
# ----------------------------------------------------------------------------
def run_ablation(d):
    print('\n' + '=' * 74)
    print('S1 ablation (log x QC), d = %d: N = %d fixed, m = %d..%d, %d trials'
          % (d, TRAIN_N, GAP, FEN_NUM * GAP, TRIALS))
    print('=' * 74)
    para = np.load(os.path.join(DATA_DIR, 'Result_data', PARAM_FILES[d]),
                   allow_pickle=True).tolist()
    mse = {v: np.empty((FEN_NUM, TRIALS)) for v in VARIANTS}
    act_ratio = {'log': np.empty((FEN_NUM, TRIALS)),
                 'nolog': np.empty((FEN_NUM, TRIALS))}

    for trial in range(TRIALS):
        np.random.seed(trial)          # identical data to the original runs
        # NB: the original pipeline passes PLAIN INTEGERS for d = 1 (X is a
        # 1-d array) and tuples for d = 5 -- keep this exactly, otherwise the
        # noise broadcast (and hence the data) differs from the original runs
        train_shape = TRAIN_N if d == 1 else (TRAIN_N, d)
        test_shape = TEST_N if d == 1 else (TEST_N, d)
        X_train, y_train, X_test, y_test = generate_data(
            train_shape, test_shape, d)
        N = len(X_train)
        h_gau = para['local_h_gau'][trial]
        h_epan = para['local_h_epan'][trial]
        h_nai = para['local_h_naive'][trial]
        k_knn = para['local_k'][trial]
        print('  trial %2d/%d' % (trial + 1, TRIALS))

        for fen in range(FEN_NUM):
            m = (fen + 1) * GAP
            blocks = mblocks(X_train, y_train, m)
            random.seed(0)             # identical assignment to the original
            fit_log = np.zeros((TEST_N, m))
            fit_raw = np.zeros((TEST_N, m))
            for j in range(m):
                assign = random.randint(1, 4)
                b_x, b_y = np.asarray(blocks[j][0]), np.asarray(blocks[j][1])
                param = {1: get_fen(h_gau, fen), 2: get_fen(h_epan, fen),
                         3: get_fen(h_nai, fen), 4: get_fen(k_knn, fen)}[assign][j]
                fit_log[:, j] = agent_fit(X_test, b_x, b_y, N, m, assign,
                                          param, use_log=True, d=d)
                fit_raw[:, j] = agent_fit(X_test, b_x, b_y, N, m, assign,
                                          param, use_log=False, d=d)

            # qualification masks (threshold 1/N, as Definition/Algorithm)
            act_log = (np.abs(fit_log) >= 1.0 / N)
            act_raw = (np.abs(fit_raw) >= 1.0 / N)
            act_ratio['log'][fen, trial] = act_log.mean()
            act_ratio['nolog'][fen, trial] = act_raw.mean()

            def qualified_average(F, A):
                num = (F * A).sum(axis=1)
                den = A.sum(axis=1)
                return np.divide(num, den, out=np.zeros_like(num),
                                 where=den != 0)

            pred = {'QDLAR (log+QC)': qualified_average(fit_log, act_log),
                    'log-only': fit_log.mean(axis=1),
                    'QC-only': qualified_average(fit_raw, act_raw),
                    'plain AVM': fit_raw.mean(axis=1)}
            for v in VARIANTS:
                mse[v][fen, trial] = np.mean((pred[v] - y_test) ** 2)

    # ---------------- sanity check against the stored AE_lc_hybrid ----------
    if 'AE_lc_hybrid' in para:
        stored = np.asarray(para['AE_lc_hybrid'])          # (FEN_NUM, TRIALS)
        diff = np.abs(stored - mse['QDLAR (log+QC)']).max()
        print('\n  [sanity check] max |recomputed QDLAR - stored '
              'AE_lc_hybrid| = %.3e' % diff)
    # ---------------- centralized oracle (stored) ---------------------------
    oracle = np.asarray(para['GE_gau']).mean() if 'GE_gau' in para else np.nan
    print('  centralized oracle GE_gau (mean over trials) = %.6e' % oracle)

    out = {'M_LIST': M_LIST, 'oracle': oracle,
           'act_ratio_log': act_ratio['log'],
           'act_ratio_nolog': act_ratio['nolog']}
    for v in VARIANTS:
        out['MSE_' + v] = mse[v]
    out_file = os.path.join(DATA_DIR, 'Result_data', 'S1_ablation_d%d.npy' % d)
    np.save(out_file, out)
    print('  Saved: %s' % out_file)
    return out


# ----------------------------------------------------------------------------
# Console summary: mean MSE at selected m
# ----------------------------------------------------------------------------
def print_summary(res, d):
    print('\n  mean MSE over %d trials (d = %d):' % (TRIALS, d))
    print('  %-6s' % 'm' + ''.join('%18s' % v for v in VARIANTS) + '%14s'
          % 'oracle')
    for m in M_SHOW:
        fen = m // GAP - 1
        row = '%-6d' % m
        for v in VARIANTS:
            row += '%18.6e' % res['MSE_' + v][fen].mean()
        print('  ' + row + '%14.6e' % res['oracle'])


# ----------------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------------
def fig_A_curves(res_all):
    """MSE-vs-m curves, one panel per dimension; mean +/- 1 std shading."""
    fig, axes = plt.subplots(1, 2, figsize=(17, 6.2))
    for k, d in enumerate(DIMS):
        ax, res = axes[k], res_all[d]
        for v in VARIANTS:
            mean = res['MSE_' + v].mean(axis=1)
            std = res['MSE_' + v].std(axis=1)
            ax.plot(M_LIST, mean, c=V_COLORS[v], marker=V_MARKERS[v],
                    markevery=4, markersize=5, linewidth=1.4, label=v)
            ax.fill_between(M_LIST, mean - std, mean + std,
                            color=V_COLORS[v], alpha=0.12)
        ax.axhline(res['oracle'], ls='--', c='black', linewidth=1.4,
                   label='centralized oracle')
        ax.set_xlabel('Number of local agents ($d$ = %d)' % d, fontsize=19)
        ax.set_ylabel('MSE', fontsize=19)
        ax.tick_params(labelsize=14)
        ax.legend(fontsize=13.5, framealpha=0.9)
    plt.suptitle('2$\\times$2 ablation of QDLAR: logarithmic mechanism '
                 '$\\times$ qualification rule ($N$ = %d fixed)' % TRAIN_N,
                 fontsize=21, weight='bold', y=1.02)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'Fig_S1_ablation2x2_curves.pdf')
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out)


def fig_B_bars(res_all):
    """Grouped bars of the 2x2 at m = 50 / 150 / 300."""
    fig, axes = plt.subplots(1, 2, figsize=(17, 6.2))
    xpos = np.arange(len(M_SHOW))
    width = 0.19
    for k, d in enumerate(DIMS):
        ax, res = axes[k], res_all[d]
        for s, v in enumerate(VARIANTS):
            vals = [res['MSE_' + v][m // GAP - 1].mean() * 1e4
                    for m in M_SHOW]
            ax.bar(xpos + (s - 1.5) * width, vals, width,
                   color=V_COLORS[v], edgecolor='white', label=v)
        ax.axhline(res['oracle'] * 1e4, ls='--', c='black', linewidth=1.4,
                   label='centralized oracle')
        ax.set_xticks(xpos)
        ax.set_xticklabels(['$m$ = %d' % m for m in M_SHOW], fontsize=16)
        ax.set_ylabel('MSE ($\\times 10^{-4}$)', fontsize=19)
        ax.set_xlabel('Number of local agents ($d$ = %d)' % d, fontsize=19)
        ax.tick_params(labelsize=14)
        ax.legend(fontsize=13, framealpha=0.9)
        ax.grid(axis='y', linestyle='--', alpha=0.3)
    plt.suptitle('Ablation at selected numbers of local agents '
                 '($N$ = %d fixed)' % TRAIN_N, fontsize=21, weight='bold',
                 y=1.02)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'Fig_S1_ablation2x2_bars.pdf')
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out)


def fig_C_active_ratio(res_all):
    """Qualified-agent ratio m*/m vs m (log vs. no-log)."""
    fig, axes = plt.subplots(1, 2, figsize=(17, 6.2))
    for k, d in enumerate(DIMS):
        ax, res = axes[k], res_all[d]
        ax.plot(M_LIST, res['act_ratio_log'].mean(axis=1), c='brown',
                marker='^', markevery=4, markersize=5, linewidth=1.4,
                label='with logarithmic mechanism')
        ax.plot(M_LIST, res['act_ratio_nolog'].mean(axis=1), c='royalblue',
                marker='o', markevery=4, markersize=5, linewidth=1.4,
                label='without logarithmic mechanism')
        ax.set_xlabel('Number of local agents ($d$ = %d)' % d, fontsize=19)
        ax.set_ylabel('Qualified-agent ratio $m^{*}/m$', fontsize=19)
        ax.set_ylim(-0.03, 1.03)
        ax.tick_params(labelsize=14)
        ax.legend(fontsize=14, framealpha=0.9)
        ax.grid(linestyle='--', alpha=0.3)
    plt.suptitle('Fraction of participants passing the qualification rule',
                 fontsize=21, weight='bold', y=1.02)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'Fig_S1_active_ratio.pdf')
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out)


def fig_D_excess_loglog(res_all):
    """Excess error over the centralized oracle, log-log axes."""
    fig, axes = plt.subplots(1, 2, figsize=(17, 6.2))
    for k, d in enumerate(DIMS):
        ax, res = axes[k], res_all[d]
        for v in VARIANTS:
            excess = np.maximum(res['MSE_' + v].mean(axis=1)
                                - res['oracle'], 1e-12)
            ax.plot(M_LIST, excess, c=V_COLORS[v], marker=V_MARKERS[v],
                    markevery=4, markersize=5, linewidth=1.4, label=v)
        ax.set_xscale('log')
        ax.set_yscale('log')
        ax.set_xlabel('Number of local agents ($d$ = %d)' % d, fontsize=19)
        ax.set_ylabel('Excess error (MSE $-$ oracle)', fontsize=19)
        ax.tick_params(labelsize=14)
        ax.legend(fontsize=13.5, framealpha=0.9)
        ax.grid(linestyle='--', alpha=0.3, which='both')
    plt.suptitle('Excess error of each ablation variant (log--log)',
                 fontsize=21, weight='bold', y=1.02)
    plt.tight_layout()
    out = os.path.join(FIG_DIR, 'Fig_S1_excess_error_loglog.pdf')
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out)


# ----------------------------------------------------------------------------
if __name__ == '__main__':
    time_start = time.time()
    res_all = {}
    for d in DIMS:
        res_all[d] = run_ablation(d)
        print_summary(res_all[d], d)
    fig_A_curves(res_all)
    fig_B_bars(res_all)
    fig_C_active_ratio(res_all)
    fig_D_excess_loglog(res_all)
    print('\nTotal time: %.1f seconds' % (time.time() - time_start))
