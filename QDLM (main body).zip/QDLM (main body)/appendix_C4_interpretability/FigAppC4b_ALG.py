# Paper: Appendix Figure 4b (Section C.4, interpretability Definition 3 / ALG, toy)
# Formerly: Toy_simulation_new_algorithm_interp/Interp_toy_d5_Def3_ALG_hybrid.py
# DIM from env QDLM_DIM (default 5); set QDLM_DIM=1 for the d=1 panel. Run from this folder.
"""
================================================================================
Interpretability Experiment -- Definition 3: Attribution Localization
Granularity (ALG)     *** HYBRID algorithm version, TOY SIMULATION (d = 5) ***
================================================================================
Toy-simulation version of Interp_Def3_ALG_hybrid_new2.py (maternity data).

ALG(x) = 1 - (1/m) * sum_j h_j(x)^d,
where h_j(x) in (0,1] is the localization parameter of participant j and d is
the input dimension. Larger ALG = finer-grained localization.

Per-agent localization parameter in the hybrid system (replicated from the toy
Function_same_block.hybrid_algorithm):
  * gau / epan / nai agents: h_j = min(1, h_adapt,j^LOG), LOG = log(N, n_j)
    (query-independent);
  * KNN agents: h_j(x) = distance between the query x and its k-th nearest
    neighbor within the block (the radius of the k-NN ball), with
    k_eff = ceil(k_adapt,j^LOG / m). This makes ALG query-dependent, so we
    average over test queries.

Toy-simulation setting (generated data, NOT real data):
  * data: np.random.seed(trial) + generate_data(10000, 1000, d) reproduces
    BIT BY BIT the data on which trails_d{1,5}_hybrid.npy were trained
    (X ~ Uniform[0,1]^d, g1 for d = 1 / g2 for d = 5, noise N(0, 0.1) on the
    training responses only);
  * per-block parameters: trails_d{1,5}_hybrid.npy, m = 5,10,...,350 (gap = 5),
    fen = m // 5 - 1, 20 trials;
  * m-grid: m = 1 (standalone LAR baseline) and m = 5, 10, 15, ..., 100.

REQUIREMENT: the TOY Function_same_block.py (the one containing create_y_g1 /
create_y_g2 / generate_data) must be importable from the same folder, and the
parameter file must sit at $QDLAR_DATA_DIR/Result_data/trails_d{1,5}_hybrid.npy.
================================================================================
"""

import os
import sys
import math
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import random
import time
import numpy as np
import matplotlib.pyplot as plt
import warnings
from matplotlib import rcParams

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)
warnings.filterwarnings('ignore')

from common.Function_same_block import mblocks, global_parameter_h, generate_data

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
DATA_DIR = os.environ.get('QDLAR_DATA_DIR', os.path.dirname(os.getcwd()))
FIG_DIR = os.environ.get('QDLAR_FIG_DIR',
                         os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C4')
os.makedirs(FIG_DIR, exist_ok=True)

DIM = int(os.environ.get('QDLM_DIM', 5))   # toy dimension: 1 or 5
PARAM_FILES = {1: 'trails_d1_hybrid.npy', 5: 'trails_d5_hybrid.npy'}
PARA_FILE = os.path.join(DATA_DIR, 'Result_data', PARAM_FILES[DIM])

TRAIN_N = 10000                                # toy training size
TEST_N = 1000                                  # toy test size
GAP = 5                                        # toy m-grid gap
M_LIST = [1] + list(range(5, 105, 5))          # m = 1: standalone LAR baseline
N_TRIALS = int(os.environ.get('QDLAR_N_TRIALS', 20))   # <= 20 (stored params)
N_QUERY = int(os.environ.get('QDLAR_N_QUERY', 200))    # queries per trial
CV_FOLD_GLOBAL = 5                             # CV folds for the m = 1 baseline

RESULT_DIR = os.environ.get('QDLAR_RESULT_DIR',
                            os.path.dirname(os.getcwd()) + '/Result_data_for_interp')
os.makedirs(RESULT_DIR, exist_ok=True)
RESULT_FILE = os.path.join(RESULT_DIR, 'Interp_toy_d%d_ALG_hybrid.npy' % DIM)
FORCE_RERUN = os.environ.get('QDLAR_RERUN', '0') == '1'   # 1: ignore cache

ALGO_NAMES = {1: 'Gaussian', 2: 'Epan', 3: 'Naive', 4: 'KNN'}
ALGO_COLORS = {1: '#4472C4', 2: '#70AD47', 3: '#E5A53A', 4: '#C0504D'}


# ----------------------------------------------------------------------------
def get_assignments(m):
    random.seed(0)
    return [random.randint(1, 4) for _ in range(m)]


def get_fen_dict(entry, fen):
    if fen in entry:
        return entry[fen]
    return entry[str(fen)]


def get_block_params(para, trial, m):
    """Per-block adaptive parameters for party count m (fen = m//GAP - 1)."""
    fen = m // GAP - 1
    return {
        1: np.atleast_1d(get_fen_dict(para['local_h_gau'][trial], fen)).astype(float),
        2: np.atleast_1d(get_fen_dict(para['local_h_epan'][trial], fen)).astype(float),
        3: np.atleast_1d(get_fen_dict(para['local_h_naive'][trial], fen)).astype(float),
        4: np.atleast_1d(get_fen_dict(para['local_k'][trial], fen)).astype(float),
    }


def effective_h_per_query(X_q, X_vic, y_vic, m, params, assigns):
    """H (T, m): per-agent localization parameter h_j(x) for every query.
    gau/epan/nai: h_eff = min(1, h_adapt^LOG) (constant over queries);
    KNN: radius to the k_eff-th nearest neighbor (query-dependent)."""
    blocks = mblocks(X_vic, y_vic, m)
    N = len(X_vic)
    T = len(X_q)
    H = np.zeros((T, m))
    knn_mask = np.zeros(m, dtype=bool)
    for i in range(m):
        b_x = np.array(blocks.loc[i]['block_x'])
        n = len(b_x)
        LOG = math.log(N, n)
        a = assigns[i]
        if a == 4:
            k = int(math.ceil((params[4][i] ** LOG) / m))
            k = max(1, min(k, n))
            dn = np.linalg.norm(X_q[:, None, :] - b_x[None, :, :], axis=2)
            # k-NN radius as h_j; clipped to (0,1] since Definition 3 assumes
            # a normalized localization parameter (a radius > 1 means the ball
            # extends beyond the unit cube)
            H[:, i] = np.clip(np.sort(dn, axis=1)[:, k - 1], 1e-12, 1.0)
            knn_mask[i] = True
        else:
            H[:, i] = min(1.0, params[a][i] ** LOG)
    return H, knn_mask


def load_toy_data(trial):
    """np.random.seed(trial) + generate_data reproduces BIT BY BIT the data
    on which the stored per-block parameters were trained."""
    np.random.seed(trial)
    train_shape = TRAIN_N if DIM == 1 else (TRAIN_N, DIM)
    test_shape = TEST_N if DIM == 1 else (TEST_N, DIM)
    X_tr, y_tr, X_te, y_te = generate_data(train_shape, test_shape, DIM)
    if DIM == 1:                       # kernels below expect 2-D (n, d)
        X_tr = X_tr.reshape(-1, 1)
        X_te = X_te.reshape(-1, 1)
    return X_tr, X_te, y_tr, y_te


# ----------------------------------------------------------------------------
def run_alg_experiment():
    print('\n' + '=' * 74)
    print('Definition 3: ALG vs. m (HYBRID, toy simulation, d = %d)' % DIM)
    print('=' * 74)
    para = np.load(PARA_FILE, allow_pickle=True).tolist()

    alg_mean, alg_std = [], []
    h_by_algo = {a: [] for a in ALGO_NAMES}   # mean h_j per algorithm type
    for m in M_LIST:
        alg_t = []
        h_acc = {a: [] for a in ALGO_NAMES}
        assigns = get_assignments(m) if m > 1 else [1]
        for trial in range(N_TRIALS):
            X_vic, X_test, y_vic, y_test = load_toy_data(trial)
            idx = np.random.RandomState(trial).choice(
                len(X_test), min(N_QUERY, len(X_test)), replace=False)
            X_q = X_test[idx]
            if m == 1:      # standalone LAR: single Gaussian model, global CV h
                h_g = min(1.0, global_parameter_h(
                    X_vic, y_vic, CV_FOLD_GLOBAL, DIM))
                H = np.full((len(X_q), 1), h_g)
            else:
                params = get_block_params(para, trial, m)
                H, _ = effective_h_per_query(X_q, X_vic, y_vic, m,
                                             params, assigns)
            # Definition 3 over ALL agents (KNN via its radius)
            alg_q = 1.0 - np.mean(H ** DIM, axis=1)
            alg_t.append(alg_q.mean())
            for a in ALGO_NAMES:
                cols = [i for i in range(m) if assigns[i] == a]
                if cols:
                    h_acc[a].append(H[:, cols].mean())
        alg_mean.append(np.mean(alg_t))
        alg_std.append(np.std(alg_t))
        for a in ALGO_NAMES:
            h_by_algo[a].append(np.mean(h_acc[a]) if h_acc[a] else np.nan)
        print('  m=%3d: ALG = %.4f ± %.4f, mean h_j by algorithm: %s'
              % (m, alg_mean[-1], alg_std[-1],
                 {ALGO_NAMES[a]: (round(float(h_by_algo[a][-1]), 3)
                                  if not np.isnan(h_by_algo[a][-1]) else None)
                  for a in ALGO_NAMES}))
    return np.array(alg_mean), np.array(alg_std), h_by_algo



# ----------------------------------------------------------------------------
# Result caching: run once, plot many times
# ----------------------------------------------------------------------------
def save_results(alg_mean, alg_std, h_by_algo):
    np.save(RESULT_FILE, {'DIM': DIM, 'M_LIST': list(M_LIST),
                          'N_TRIALS': N_TRIALS, 'N_QUERY': N_QUERY, 'alg_mean': alg_mean, 'alg_std': alg_std, 'h_by_algo': h_by_algo})
    print('Saved: %s' % RESULT_FILE)


def load_results():
    """Return saved results, or None if missing / config mismatch."""
    if not os.path.exists(RESULT_FILE):
        return None
    data = np.load(RESULT_FILE, allow_pickle=True).tolist()
    if list(data['M_LIST']) != list(M_LIST) or \
            data['N_TRIALS'] != N_TRIALS or data['N_QUERY'] != N_QUERY:
        print('  [rerun] saved results use a different configuration '
              '(M_LIST / N_TRIALS / N_QUERY) -- running again.')
        return None
    print('Loaded saved results: %s (no re-run needed)' % RESULT_FILE)
    return (np.asarray(data['alg_mean']), np.asarray(data['alg_std']), data['h_by_algo'])


def plot_alg(alg_mean, alg_std, h_by_algo):
    xpos = np.arange(len(M_LIST))   # evenly spaced categories (m is already gap-5)
    fig, axes = plt.subplots(1, 2, figsize=(14.8, 6))

    # (a) per-agent localization parameter h_j vs. m, one line per algorithm
    ax = axes[0]
    for a in ALGO_NAMES:
        ls = '--' if a == 4 else '-'
        mk = 's' if a == 4 else 'o'
        lab = 'KNN agents' if a == 4 else \
              '%s agents' % ALGO_NAMES[a]
        ax.plot(xpos, h_by_algo[a], marker=mk, color=ALGO_COLORS[a],
                linewidth=2.2, markersize=7, markeredgecolor='white',
                markeredgewidth=1.0, linestyle=ls, label=lab)
    ax.set_xticks(xpos)
    ax.set_xticklabels([str(m) for m in M_LIST], fontsize=15, rotation=45)
    ax.set_xlabel('Number of local agents $m$', fontsize=22)
    ax.set_ylabel('Localization parameter $h_j^{\\mathrm{log}}$', fontsize=22)
    ax.tick_params(axis='y', labelsize=18)
    ax.set_title('(a) Per-agent localization parameter vs. $m$', fontsize=20,
                 weight='bold', pad=12)
    ax.legend(loc='lower right', fontsize=17, framealpha=0.95)
    # clarify why only the Gaussian line has a point at m = 1
    # ax.text(0.4, 0.2, '$m$=1: standalone NWK (Gaussian) only',
    #         transform=ax.transAxes, fontsize=14, color='black',
    #         va='bottom', ha='left',
    #         bbox=dict(boxstyle='round,pad=0.35', facecolor='white',
    #                   edgecolor='#BBBBBB', alpha=0.9))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', linestyle='--', alpha=0.3)

    # (b) ALG
    ax = axes[1]
    ax.plot(xpos, alg_mean, marker='o', color='#D97A4A', linewidth=2.6,
            markersize=8, markeredgecolor='white', markeredgewidth=1.2,
            label='QDLAR ($m>$1)')
    ax.fill_between(xpos, alg_mean - alg_std, alg_mean + alg_std,
                    color='#D97A4A', alpha=0.15)
    ax.plot([xpos[0]], [alg_mean[0]], marker='*', color='black',
            markersize=16, linestyle='none', label='Standalone LAR ($m$=1)')
    ax.set_xticks(xpos)
    ax.set_xticklabels([str(m) for m in M_LIST], fontsize=16, rotation=45)
    ax.set_xlabel('Number of local agents $m$', fontsize=22)
    ax.set_ylabel('ALG', fontsize=20)
    ax.tick_params(axis='y', labelsize=18)
    ax.set_title('(b) Attribution localization granularity vs. $m$',
                 fontsize=20, weight='bold', pad=12)
    ax.legend(loc='lower right', fontsize=17, framealpha=0.95)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', linestyle='--', alpha=0.3)
    plt.suptitle('Localization granularity of the QDLAR '
                 '($d$ = %d)' % DIM, fontsize=22,
                 weight='bold', y=0.96)
    # plt.tight_layout(rect=[0, 0, 1, 0.98])

    plt.tight_layout(rect=[0, 0, 1, 0.98], w_pad=3.0)  # w_pad 控制水平间距
    out = os.path.join(FIG_DIR, 'Fig_Interp_toy_d%d_ALG_hybrid.pdf' % DIM)
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out)


if __name__ == '__main__':
    time_start = time.time()
    results = None if FORCE_RERUN else load_results()
    if results is None:
        results = run_alg_experiment()
        save_results(*results)
    plot_alg(*results)
    print('\nTotal time: %.1f seconds' % (time.time() - time_start))
