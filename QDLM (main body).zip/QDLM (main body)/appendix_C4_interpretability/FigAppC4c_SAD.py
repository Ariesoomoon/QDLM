# Paper: Appendix Figure 4c (Section C.4, interpretability Definition 2 / SAD, toy)
# Formerly: Toy_simulation_new_algorithm_interp/Interp_toy_d5_Def2_SAD_hybrid.py
# DIM from env QDLM_DIM (default 5); set QDLM_DIM=1 for the d=1 panel. Run from this folder.
"""
================================================================================
Interpretability Experiment -- Definition 2: Sample Attribution Depth (SAD)
         *** HYBRID algorithm version, TOY SIMULATION (d = 5) ***
================================================================================
Toy-simulation version of Interp_Def2_SAD_hybrid_new2.py (maternity data).

SAD(x) = (1/m*) * sum_{j active} 1/|A_j(x)|,
where A_j(x) is the attribution set of query x for participant j (local samples
with weight W > 0), and m* is the number of ACTIVATED participants
(qualification rule of the paper's system: |fit_j(x)| >= 1/N).

Toy-simulation setting (generated data, NOT real data):
  * data: np.random.seed(trial) + generate_data(10000, 1000, d) reproduces
    BIT BY BIT the data on which trails_d{1,5}_hybrid.npy were trained
    (X ~ Uniform[0,1]^d, g1 for d = 1 / g2 for d = 5, noise N(0, 0.1) on the
    training responses only);
  * per-block parameters: trails_d{1,5}_hybrid.npy (local_h_gau /
    local_h_epan / local_h_naive / local_k), m = 5,10,...,350 (gap = 5),
    fen = m // 5 - 1, 20 trials;
  * m-grid: m = 1 (standalone LAR baseline: one Gaussian LAR on the whole
    training set with global_parameter_h) and m = 5, 10, 15, ..., 100.

The hybrid setting is replicated EXACTLY from the toy Function_same_block.
hybrid_algorithm:
  * algorithm assignment: random.seed(0); assign = randint(1,4) per block
    (1 = Gaussian, 2 = Epanechnikov, 3 = naive/cube, 4 = KNN);
  * logarithmic mechanism: h_eff = min(1, h^LOG), LOG = log(N, n_j);
    for KNN: k_eff = ceil(k^LOG / m);
  * attribution set size: gau -> n_j (all weights > 0),
    epan/nai -> #samples inside the L2 ball of radius h_eff, knn -> k_eff.

REQUIREMENT: the TOY Function_same_block.py (the one containing create_y_g1 /
create_y_g2 / generate_data) must be importable from the same folder, and the
parameter file must sit at $QDLAR_DATA_DIR/Result_data/trails_d{1,5}_hybrid.npy
(QDLAR_DATA_DIR defaults to the parent of the working directory).
================================================================================
"""

import os
import sys
import math
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import random
import time
import numpy as np
import matplotlib.pyplot as plt
import warnings
from matplotlib import rcParams

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)
warnings.filterwarnings('ignore')

from common.Function_same_block import mblocks, global_parameter_h, generate_data

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
DATA_DIR = os.environ.get('QDLAR_DATA_DIR', os.path.dirname(os.getcwd()))
FIG_DIR = os.environ.get('QDLAR_FIG_DIR',
                         os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C4')
os.makedirs(FIG_DIR, exist_ok=True)

DIM = int(os.environ.get('QDLM_DIM', 5))        # toy dimension: 1 or 5
PARAM_FILES = {1: 'trails_d1_hybrid.npy', 5: 'trails_d5_hybrid.npy'}
PARA_FILE = os.path.join(DATA_DIR, 'Result_data', PARAM_FILES[DIM])

TRAIN_N = 10000                                # toy training size
TEST_N = 1000                                  # toy test size
GAP = 5                                        # toy m-grid gap
M_LIST = [1] + list(range(5, 105, 5))          # m = 1: standalone LAR baseline
N_TRIALS = int(os.environ.get('QDLAR_N_TRIALS', 20))   # <= 20 (stored params)
N_QUERY = int(os.environ.get('QDLAR_N_QUERY', 200))    # queries per trial
CV_FOLD_GLOBAL = 5                             # CV folds for the m = 1 baseline

RESULT_DIR = os.environ.get('QDLAR_RESULT_DIR',
                            os.path.dirname(os.getcwd()) + '/Result_data_for_interp')
os.makedirs(RESULT_DIR, exist_ok=True)
RESULT_FILE = os.path.join(RESULT_DIR, 'Interp_toy_d%d_SAD_hybrid.npy' % DIM)
FORCE_RERUN = os.environ.get('QDLAR_RERUN', '0') == '1'   # 1: ignore cache

ALGO_NAMES = {1: 'Gaussian', 2: 'Epan', 3: 'Naive', 4: 'KNN'}
ALGO_COLORS = {1: '#4472C4', 2: '#70AD47', 3: '#E5A53A', 4: '#C0504D'}


# ----------------------------------------------------------------------------
# Exact replication of the hybrid assignment & per-block kernels (vectorized)
# ----------------------------------------------------------------------------
def get_assignments(m):
    """Same as hybrid_algorithm: random.seed(0), then randint(1,4) per block."""
    random.seed(0)
    return [random.randint(1, 4) for _ in range(m)]


def get_fen_dict(entry, fen):
    if fen in entry:
        return entry[fen]
    return entry[str(fen)]


def get_block_params(para, trial, m):
    """Per-block adaptive parameters for party count m (fen = m//GAP - 1).
    m is a multiple of GAP, so the stored arrays have exactly length m."""
    fen = m // GAP - 1
    return {
        1: np.atleast_1d(get_fen_dict(para['local_h_gau'][trial], fen)).astype(float),
        2: np.atleast_1d(get_fen_dict(para['local_h_epan'][trial], fen)).astype(float),
        3: np.atleast_1d(get_fen_dict(para['local_h_naive'][trial], fen)).astype(float),
        4: np.atleast_1d(get_fen_dict(para['local_k'][trial], fen)).astype(float),
    }


def hybrid_estimates_all_queries(X_q, X_vic, y_vic, m, params, assigns):
    """Vectorized per-block weights/fit/active/attribution-set-size for ALL
    queries at once. Replicates the kernels + logarithmic mechanism +
    qualification rule of the toy Function_same_block.hybrid_algorithm.

    Returns attr_mat (T, m) and active_mat (T, m, bool)."""
    blocks = mblocks(X_vic, y_vic, m)
    N = len(X_vic)
    T = len(X_q)
    attr_mat = np.zeros((T, m))
    active_mat = np.zeros((T, m), dtype=bool)
    for i in range(m):
        b_x = np.array(blocks.loc[i]['block_x'])
        b_y = np.array(blocks.loc[i]['block_y'])
        n = len(b_x)
        LOG = math.log(N, n)                     # logarithmic operator
        a = assigns[i]
        dis = (X_q[:, None, :] - b_x[None, :, :])          # (T, n, d)
        if a == 1:                                         # Gaussian, s = 2
            h = min(1.0, params[1][i] ** LOG)
            dn = np.linalg.norm(dis / h, axis=2) ** 2      # (T, n)
            w = np.exp(-dn)
            attr = np.full(T, float(n))                    # all weights > 0
        elif a == 2:                                       # Epanechnikov
            h = min(1.0, params[2][i] ** LOG)
            dn = np.linalg.norm(dis / h, axis=2) ** 2
            w = np.where(1 - dn > 0, 1 - dn, 0.0)
            attr = (w > 0).sum(axis=1).astype(float)
        elif a == 3:                                       # naive / cube
            h = min(1.0, params[3][i] ** LOG)
            dn = np.linalg.norm(dis / h, axis=2)
            w = (dn <= 1).astype(float)
            attr = (w > 0).sum(axis=1).astype(float)
        else:                                              # KNN
            k = int(math.ceil((params[4][i] ** LOG) / m))
            k = max(1, min(k, n))
            dn = np.linalg.norm(dis, axis=2)
            w = np.zeros((T, n))
            idx = np.argsort(dn, axis=1)[:, :k]
            np.put_along_axis(w, idx, 1.0, axis=1)
            attr = np.full(T, float(k))
        wsum = w.sum(axis=1)
        fit = np.divide(w @ b_y, wsum, out=np.zeros(T), where=wsum > 0)
        attr_mat[:, i] = np.maximum(attr, 1.0)
        active_mat[:, i] = np.abs(fit) >= 1.0 / N          # qualification rule
    return attr_mat, active_mat


def sad_from_estimates(attr_mat, active_mat):
    """SAD(x) = mean over ACTIVE blocks of 1/|A_j(x)|; fallback to all blocks
    if no block is active for a query."""
    inv = 1.0 / attr_mat
    sad = np.zeros(attr_mat.shape[0])
    for t in range(attr_mat.shape[0]):
        act = active_mat[t]
        sad[t] = inv[t][act].mean() if act.any() else inv[t].mean()
    return sad


def load_toy_data(trial):
    """np.random.seed(trial) + generate_data reproduces BIT BY BIT the data
    on which the stored per-block parameters were trained."""
    np.random.seed(trial)
    train_shape = TRAIN_N if DIM == 1 else (TRAIN_N, DIM)
    test_shape = TEST_N if DIM == 1 else (TEST_N, DIM)
    X_tr, y_tr, X_te, y_te = generate_data(train_shape, test_shape, DIM)
    if DIM == 1:                       # kernels below expect 2-D (n, d)
        X_tr = X_tr.reshape(-1, 1)
        X_te = X_te.reshape(-1, 1)
    return X_tr, X_te, y_tr, y_te


# ----------------------------------------------------------------------------
# Experiment
# ----------------------------------------------------------------------------
def run_sad_experiment():
    print('\n' + '=' * 74)
    print('Definition 2: SAD vs. m (HYBRID, toy simulation, d = %d)' % DIM)
    print('=' * 74)
    para = np.load(PARA_FILE, allow_pickle=True).tolist()

    sad_mean, sad_std = [], []
    attr_by_algo = {a: [] for a in ALGO_NAMES}   # mean |A_j(x)| per algorithm

    for m in M_LIST:
        sad_trials = []
        attr_acc = {a: [] for a in ALGO_NAMES}
        assigns = get_assignments(m) if m > 1 else [1]
        for trial in range(N_TRIALS):
            X_vic, X_test, y_vic, y_test = load_toy_data(trial)
            if m == 1:      # standalone LAR: single Gaussian model, h by global CV
                params = {1: np.array([global_parameter_h(
                              X_vic, y_vic, CV_FOLD_GLOBAL, DIM)]),
                          2: None, 3: None, 4: None}
            else:
                params = get_block_params(para, trial, m)
            idx = np.random.RandomState(trial).choice(
                len(X_test), min(N_QUERY, len(X_test)), replace=False)
            attr_mat, active_mat = hybrid_estimates_all_queries(
                X_test[idx], X_vic, y_vic, m, params, assigns)
            sad_trials.append(sad_from_estimates(attr_mat, active_mat).mean())
            for a in ALGO_NAMES:
                cols = [i for i in range(m) if assigns[i] == a]
                if cols:
                    attr_acc[a].append(attr_mat[:, cols].mean())
        sad_mean.append(np.mean(sad_trials))
        sad_std.append(np.std(sad_trials))
        for a in ALGO_NAMES:
            attr_by_algo[a].append(np.mean(attr_acc[a]) if attr_acc[a] else np.nan)
        comp = {ALGO_NAMES[a]: assigns.count(a) for a in ALGO_NAMES}
        print('  m=%3d: SAD = %.4f ± %.4f   (algo mix: %s)'
              % (m, sad_mean[-1], sad_std[-1], comp))
    return np.array(sad_mean), np.array(sad_std), attr_by_algo



# ----------------------------------------------------------------------------
# Result caching: run once, plot many times
# ----------------------------------------------------------------------------
def save_results(sad_mean, sad_std, attr_by_algo):
    np.save(RESULT_FILE, {'DIM': DIM, 'M_LIST': list(M_LIST),
                          'N_TRIALS': N_TRIALS, 'N_QUERY': N_QUERY, 'sad_mean': sad_mean, 'sad_std': sad_std, 'attr_by_algo': attr_by_algo})
    print('Saved: %s' % RESULT_FILE)


def load_results():
    """Return saved results, or None if missing / config mismatch."""
    if not os.path.exists(RESULT_FILE):
        return None
    data = np.load(RESULT_FILE, allow_pickle=True).tolist()
    if list(data['M_LIST']) != list(M_LIST) or \
            data['N_TRIALS'] != N_TRIALS or data['N_QUERY'] != N_QUERY:
        print('  [rerun] saved results use a different configuration '
              '(M_LIST / N_TRIALS / N_QUERY) -- running again.')
        return None
    print('Loaded saved results: %s (no re-run needed)' % RESULT_FILE)
    return (np.asarray(data['sad_mean']), np.asarray(data['sad_std']), data['attr_by_algo'])


def plot_sad(sad_mean, sad_std, attr_by_algo):
    xpos = np.arange(len(M_LIST))   # evenly spaced categories (m is already gap-5)
    fig, axes = plt.subplots(1, 2, figsize=(14.2, 6))

    # (a) attribution set size per algorithm
    ax = axes[0]
    for a in ALGO_NAMES:
        ax.plot(xpos, attr_by_algo[a], marker='o', color=ALGO_COLORS[a],
                linewidth=2.2, markersize=7, markeredgecolor='white',
                markeredgewidth=1.0, label='%s agents' % ALGO_NAMES[a])
    ax.set_yscale('log')
    ax.set_xticks(xpos)
    ax.set_xticklabels([str(m) for m in M_LIST], fontsize=15, rotation=45)
    ax.set_xlabel('Number of local agents $m$', fontsize=22)
    ax.set_ylabel(r'Mean attribution set size $|A_j(x)|$', fontsize=22)
    ax.tick_params(axis='y', labelsize=18)
    ax.set_title('(a) Attribution set size vs. $m$', fontsize=20,
                 weight='bold', pad=12)
    ax.legend(loc='best', ncol=2, fontsize=17, framealpha=0.95)
    # clarify why only the Gaussian line has a point at m = 1
    ax.text(0.3, 0.35, '$m$=1: standalone NWK (Gaussian) only\n'
                        '(no Epan/Naive/KNN agents exist)',
            transform=ax.transAxes, fontsize=14, color='black',
            va='bottom', ha='left',
            bbox=dict(boxstyle='round,pad=0.35', facecolor='white',
                      edgecolor='#BBBBBB', alpha=0.9))
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', linestyle='--', alpha=0.3)

    # (b) SAD
    ax = axes[1]
    ax.plot(xpos, sad_mean, marker='o', color='#D97A4A', linewidth=2.6,
            markersize=8, markeredgecolor='white', markeredgewidth=1.2)
    ax.fill_between(xpos, sad_mean - sad_std, sad_mean + sad_std,
                    color='#D97A4A', alpha=0.15)
    ax.set_xticks(xpos)
    ax.set_xticklabels([str(m) for m in M_LIST], fontsize=16, rotation=45)
    ax.set_xlabel('Number of local agents $m$', fontsize=22)
    ax.set_ylabel('SAD', fontsize=20)
    ax.tick_params(axis='y', labelsize=18)
    ax.set_title('(b) Sample attribution depth vs. $m$', fontsize=20,
                 weight='bold', pad=12)
    # ax.annotate('standalone LAR ($m$=1)', xy=(xpos[0], sad_mean[0]),
    #             xytext=(xpos[1], sad_mean[0] * 1.3),
    #             arrowprops=dict(arrowstyle='->', color='black', lw=1.4),
    #             fontsize=14, color='#555555')
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', linestyle='--', alpha=0.3)
    plt.suptitle('Sample-level interpretability of the QDLAR '
                 '($d$ = %d)' % DIM, fontsize=22,
                 weight='bold', y=0.96)
    plt.tight_layout(rect=[0, 0, 1, 1], w_pad=3.0)  # w_pad 控制水平间距
    out = os.path.join(FIG_DIR, 'Fig_Interp_toy_d%d_SAD_hybrid.pdf' % DIM)
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
    plt.show()
    print('Saved: %s' % out)


if __name__ == '__main__':
    time_start = time.time()
    results = None if FORCE_RERUN else load_results()
    if results is None:
        results = run_sad_experiment()
        save_results(*results)
    plot_sad(*results)
    print('\nTotal time: %.1f seconds' % (time.time() - time_start))
