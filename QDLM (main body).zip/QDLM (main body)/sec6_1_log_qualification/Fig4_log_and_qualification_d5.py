# -*- coding: utf-8 -*-
# Fig4_log_and_qualification_d5.py
# Paper: Main Figure 4 (Section 6.1); also produces Appendix Figure 8(a)
#        (gau2_d5_same_diff_compare.pdf, attendance-autonomy comparison).
# Reads Result_data/trails_d5_gau2.npy (repo root). Run from this folder
# (one level below the repo root). Outputs: Result_figure/sec6_1/.
# Note: the figure-1 (log mechanism) and figure-3 (same/diff block) plotting
# blocks are kept exactly as in the original file (commented out); the active
# block produces gau2_d5_active(logscale).pdf.
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import pdb, time, os
import sys

from matplotlib import rcParams
fontsize_specific = 16
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
'''1. load data'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_gau2.npy', allow_pickle=True)
trails_d5_gau2 = loadData.tolist()
print(trails_d5_gau2.keys())

GEs_mean = [np.mean(trails_d5_gau2['GEs'])] * 70
AEs_mean = np.mean(trails_d5_gau2['AEs'], axis=1)
LEs_mean = np.mean(trails_d5_gau2['LEs'], axis=1)
AE_adapts_mean = np.mean(trails_d5_gau2['AE_adapts'], axis=1)
AE_logs_mean = np.mean(trails_d5_gau2['AE_logs'], axis=1)
AE_log_actives_mean = np.mean(trails_d5_gau2['AE_log_actives'], axis=1)
LE_adapts_mean = np.mean(trails_d5_gau2['LE_adapts'], axis=1)
# AE_log_actives_diff_mean = np.mean(trails_d5_gau2['AE_log_actives_diff'], axis=1)
AE_log_actives_diff_mean = np.mean(trails_d5_gau2['AE_log_actives_diff'], axis=1)



'''figure 1: h^log is effective'''
# 💎 💎 💎 💎 💎
# M_nwk = [i for i in range(5, 355, 5)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# ax.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
# ax.plot(M_nwk, LEs_mean, c='royalblue', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, AEs_mean, c='royalblue', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, AE_adapts_mean, c='brown', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, AE_logs_mean, c='brown', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, GE_gau_mean, c='black', linestyle='--', linewidth=2.0)
# plt.legend(['$GE$', '$LE_{opt}$', '$AE_{opt}$', '$AE_{log}$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE (Gaussian)', fontsize='18')
# # plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_log.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# # plt.show()
#
#
# # +logscale 小图
# left, bottom, width, height = 0.6, 0.55, 0.3, 0.25
# ax1 = fig.add_axes([left, bottom, width, height])
# # ax1.grid(linestyle='-.')
# # M_nwk = [i for i in range(5, 355, 5)]     # m = 5,10, ..., 350
# # ax1.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
# # ax1.plot(M_nwk, LEs_mean, c='royalblue', linestyle=':', linewidth=2.0)
# # ax1.plot(M_nwk, AEs_mean, c='royalblue', linestyle='--', linewidth=2.0)
# # ax1.plot(M_nwk, AE_logs_mean, c='brown', linestyle='--', linewidth=2.0)
# M_nwk = [i for i in range(5, 105, 5)]     # m = 5,10, ..., 350
# ax1.plot(M_nwk, GEs_mean[:20], c='black', linestyle='-.', linewidth=2.0)
# ax1.plot(M_nwk, LEs_mean[:20], c='royalblue', linestyle=':', linewidth=2.0)
# ax1.plot(M_nwk, AEs_mean[:20], c='royalblue', linestyle='--', linewidth=2.0)
# ax1.plot(M_nwk, AE_logs_mean[:20], c='brown', linestyle='--', linewidth=2.0)
#
# ax1.set_ylabel('log(MSE)',fontsize='15')
# plt.yscale('log')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_log(logscale).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



# 💎 💎 💎 💎 💎
# M_nwk = [i for i in range(5, 355, 5)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# M_nwk_sampled = M_nwk[::2]
# GEs_sampled = GEs_mean[::2]
# LEs_mean_sampled = LEs_mean[::2]
# AEs_mean_sampled = AEs_mean[::2]
# AE_logs_mean_sampled = AE_logs_mean[::2]
#
# ax.plot(M_nwk_sampled, GEs_sampled, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(M_nwk_sampled, LEs_mean_sampled, c='forestgreen', marker='o',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(M_nwk_sampled, AEs_mean_sampled, c='royalblue', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
# # ax.plot(M_nwk, AE_adapts_mean, c='brown', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk_sampled, AE_logs_mean_sampled, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
#
#
#
# # ax.plot(M_nwk, GE_gau_mean, c='black', linestyle='--', linewidth=2.0)
# plt.legend(['$GE$', '$LE_\mathrm{opt}$', '$AE_\mathrm{opt}$', '$AE_\mathrm{log}$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local practitioners', fontsize='20')
# ax.set_ylabel('MSE of NWK(Gaussian)', fontsize='20')
# # plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_log.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# # plt.show()
#
#
# # +logscale 小图
# left, bottom, width, height = 0.6, 0.55, 0.3, 0.25
# ax1 = fig.add_axes([left, bottom, width, height])
# # ax1.grid(linestyle='-.')
# # M_nwk = [i for i in range(5, 355, 5)]     # m = 5,10, ..., 350
# # ax1.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
# # ax1.plot(M_nwk, LEs_mean, c='royalblue', linestyle=':', linewidth=2.0)
# # ax1.plot(M_nwk, AEs_mean, c='royalblue', linestyle='--', linewidth=2.0)
# # ax1.plot(M_nwk, AE_logs_mean, c='brown', linestyle='--', linewidth=2.0)
# M_nwk_sampled = [i for i in range(5, 105, 10)]     # m = 5,10, ..., 350
#
# ax1.plot(M_nwk_sampled, GEs_sampled[:10], c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=3)
# ax1.plot(M_nwk_sampled, LEs_mean_sampled[:10], c='forestgreen', marker='o',  linestyle='-', linewidth=1.2, markersize=3)
# ax1.plot(M_nwk_sampled, AEs_mean_sampled[:10], c='royalblue', marker='^',  linestyle='-', linewidth=1.2, markersize=3)
# # ax.plot(M_nwk, AE_adapts_mean, c='brown', linestyle=':', linewidth=2.0)
# ax1.plot(M_nwk_sampled, AE_logs_mean_sampled[:10], c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=3)
#
# ax1.set_ylabel('log(MSE)',fontsize='15')
# plt.yscale('log')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_log(logscale).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()




# '''figure 2: active rule is effective'''
# M_nwk = [i for i in range(5, 351, 5)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
# ax.plot(M_nwk, AE_logs_mean, c='royalblue', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, AE_log_actives_mean, c='brown', linestyle='--', linewidth=2.0)
# plt.legend(['$GE$', '$AE_{log}$', '$AE_{active}$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE (Gaussian)', fontsize='18')
# # plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_active.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# # plt.show()
# # print('picture is done')
#
#
# left, bottom, width, height = 0.64, 0.3, 0.3, 0.25
# ax1 = fig.add_axes([left, bottom, width, height])
# # ax1.grid(linestyle='-.')
# M_nwk = [i for i in range(5, 355, 5)]     # m = 5,10, ..., 350
# ax1.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
# ax1.plot(M_nwk, AE_logs_mean, c='royalblue', linestyle=':', linewidth=2.0)
# ax1.plot(M_nwk, AE_log_actives_mean, c='brown', linestyle='--', linewidth=2.0)
#
#
# ax1.set_ylabel('log(MSE)', fontsize='15')
# plt.yscale('log')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_active(logscale).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


# 💎 💎 💎 💎 💎
'''figure 2: active rule is effective'''
M_nwk = [i for i in range(5, 351, 5)]
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
M_nwk_sampled = M_nwk[::2]  # 每隔10个点，即索引间隔为2（因为5,10,15,...是间隔5）
AE_logs_mean_sampled = AE_logs_mean[::2]
AE_log_actives_mean_sampled = AE_log_actives_mean[::2]
GEs_sampled = GEs_mean[::2]

ax.plot(M_nwk_sampled, GEs_sampled, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=5)
ax.plot(M_nwk_sampled, AE_logs_mean_sampled, c='royalblue', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
ax.plot(M_nwk_sampled, AE_log_actives_mean_sampled, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=5)

plt.legend(['$GE$', '$AE_\mathrm{log}$', '$AE_\mathrm{active}$'], loc='upper left', fontsize='15')
ax.set_xlabel('Number of local practitioners', fontsize='20')
ax.set_ylabel('MSE of NWK(Gaussian)', fontsize='20')

left, bottom, width, height = 0.64, 0.3, 0.3, 0.25
ax1 = fig.add_axes([left, bottom, width, height])
# ax1.grid(linestyle='-.')

M_nwk = [i for i in range(5, 355, 5)]     # m = 5,10, ..., 350
ax1.plot(M_nwk_sampled, GEs_sampled, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=2)
ax1.plot(M_nwk_sampled, AE_logs_mean_sampled, c='royalblue', marker='^',  linestyle='-', linewidth=1.2, markersize=2)
ax1.plot(M_nwk_sampled, AE_log_actives_mean_sampled, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=2)

ax1.set_ylabel('log(MSE)', fontsize='14')
plt.yscale('log')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_active(logscale).pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




'''figure 3: MSE of same block size and different block size'''
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# M_nwk = [i for i in range(5, 351, 5)]
# print(LE_adapts_mean)
# # ax.plot(M_nwk, LE_adapts_mean, c='forestgreen', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, AE_log_actives_mean, c='royalblue', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, AE_log_actives_diff_mean, c='brown', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
#
#
# # ax.plot(M_nwk, LE_adapts_mean, c='forestgreen', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, AE_log_actives_mean, c='royalblue', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, AE_log_actives_diff_mean, c='brown', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
#
# ax.plot(M_nwk, LE_adapts_mean, c='forestgreen', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
# ax.plot(M_nwk, AE_log_actives_mean, c='royalblue', marker='^',  linestyle='-', linewidth=1.2, markersize=4)
# ax.plot(M_nwk, AE_log_actives_diff_mean, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=4)
# ax.plot(M_nwk, GEs_mean, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=4)
#
#
#
#
# plt.ylim(0.0005, 0.0032)
# plt.legend(['$LE_{adapt}$', '$AE_{active, same}$', '$AE_{active,diff}$', '$GE$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE (Gaussian)', fontsize='18')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_same_diff_compare.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



# 💎 💎 💎 💎 💎
# # 每隔10个点取一次
# M_nwk = [i for i in range(5, 351, 5)]
# M_nwk_sampled = M_nwk[::2]  # 每隔10个点，即索引间隔为2（因为5,10,15,...是间隔5）
# LE_adapts_sampled = LE_adapts_mean[::2]
# AE_log_actives_sampled = AE_log_actives_mean[::2]
# AE_log_actives_diff_sampled = AE_log_actives_diff_mean[::2]
# GEs_sampled = GEs_mean[::2]
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
#
# ax.plot(M_nwk_sampled, LE_adapts_sampled, c='forestgreen', marker='o',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(M_nwk_sampled, AE_log_actives_sampled, c='royalblue', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(M_nwk_sampled, AE_log_actives_diff_sampled, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
# ax.plot(M_nwk_sampled, GEs_sampled, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=4)
#
# plt.ylim(0.0005, 0.0032)
# plt.legend(['$LE_\mathrm{adapt}$', '$AE_\mathrm{active, same}$', '$AE_\mathrm{active,diff}$', '$GE$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE (Gaussian)', fontsize='18')
#
# # 保存图像
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/sec6_1/gau2_d5_same_diff_compare.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()

