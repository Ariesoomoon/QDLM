# Paper: Main Figure 9 (Section 6.4) - core module (accuracy/privacy/interpretability trade-offs).
# Formerly: Toy_simulation_tradeoff(...)_v加速/tradeoff_hj_core1.py
# Reads root-level Result_data/trails_d{1,5}_hybrid.npy; own caches stay in this folder.
"""
tradeoff_hj_core.py -- pairwise metric trade-offs of QDLAR as the local
parameter h_j varies (toy simulation, SAME-size blocks only).

Experiment
----------
Every party's STORED optimal local parameter (trails_d{1,5}_hybrid.npy, no
re-training anywhere) is scaled by a common factor rho:
    kernel parties (gau/epan/nai):  h_j(rho) = min(1, rho * h_j*)
    KNN parties:                    k_j(rho) = clip(round(rho * k_j*), 1, n_j)
i.e. all parties move collectively and fairly around their own optimum.
The QDLAR logarithmic mechanism (h -> min(1, h^LOG), k -> ceil(k^LOG/m))
and the qualification rule |fit| >= 1/N are then applied as usual.

At every rho in RHO_LIST (rho = 1 is the trained optimum), three metrics:
    MSE  -- QDLAR aggregate (qualified parties, equal weights = the paper's
            central rule for same-size blocks) on the noiseless test set;
    ALG  -- Definition-3 average localization gap, 1 - mean_j h_j(x)^d over
            ALL parties, averaged over N_QUERY test queries;
    AUC  -- membership-inference attack AUC, replicating the user's toy
            protocol (MIA_toy_LAR_20trial.py):
              * shadow model: global Gaussian LAR, h by 3-fold CV on 2000
                adversary samples (seed 7777+trial pool, same DGP);
              * LOCAL: party 1's own model (log mechanism, NO
                qualification), members = party 1's block, non-members =
                pool segment of the same size;
              * CENTRAL: QDLAR aggregate (log mechanism + qualification),
                members = 2000 victim subsamples (seed 9999+trial),
                non-members = 2000 pool samples;
              * attack features {|fit|, loss, both} x classifiers
                {LR, RF, MLP}; the plotted curve is the STRONGEST attack
                (max over the 9 combinations) on the central model --
                every combination is stored for both local and central.

Settings: m in {5, 10, 15, 20}, same-size blocks, 20 trials (mean +/- sd).
All data / result / figure paths default to the CURRENT folder (flat,
online-run friendly).  Results cached in tradeoff_hj_results_d{DIM}.npy --
re-running only re-plots.  Trials are independent and run in parallel
worker processes (QDLAR_JOBS, default all cores).

Outputs (per dimension d):
    Fig_tradeoff_hj_MSE_ALG_d{d}.pdf     dual-axis, 2x2 panels over m
    Fig_tradeoff_hj_MSE_AUC_d{d}.pdf
    Fig_tradeoff_hj_ALG_AUC_d{d}.pdf
    Fig_tradeoff_hj_MSE_mechanisms_d{d}.pdf
        mechanism ablation on MSE: QDLAR (log + qualification) vs. log-only
        vs. qualification-only (separate cheap run, no ALG/MIA; uses the
        STORED local parameters, distances precomputed once per party via
        Function_same_block_new -- several times faster than the main run)
    tradeoff_hj_results_d{d}.npy         full cache (all attacks stored)
    tradeoff_hj_mech_results_d{d}.npy    mechanism-ablation cache

Requires Function_same_block_new.py (Function_same_block + the mechanism
switches hybrid_party_fit_fast / hybrid_central_combine) in the same folder.

Environment overrides: QDLAR_DIM (set by the drivers), QDLAR_N_TRIALS,
QDLAR_M_LIST, QDLAR_RHO_LIST, QDLAR_TRAIN_N, QDLAR_TEST_N, QDLAR_N_QUERY,
QDLAR_JOBS, QDLAR_DATA_DIR, QDLAR_RESULT_DIR, QDLAR_FIG_DIR,
QDLAR_AUC_VIEW ('central_MLP_Attack-III' default; also 'central_max',
'local_max', or e.g. 'local_RF_Attack-I' for one fixed combination),
QDLAR_RERUN=1.
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import math
import random
import time

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score
import warnings
warnings.filterwarnings('ignore')          # MLP convergence notes etc.

try:
    sys.stdout.reconfigure(line_buffering=True)   # online platforms buffer
except Exception:
    pass

from common.Function_same_block_new import (
    generate_data, create_y_g1, create_y_g2, global_parameter_h,
    hybrid_party_precompute, hybrid_party_fit_fast, hybrid_central_combine)

# ----------------------------------------------------------------------------
# Configuration (env-overridable)
# ----------------------------------------------------------------------------
DATA_DIR = os.environ.get('QDLAR_DATA_DIR', os.path.dirname(os.getcwd()) + '/Result_data')  # root-level cache (de-duplicated)
RESULT_DIR = os.environ.get('QDLAR_RESULT_DIR', os.path.dirname(os.path.abspath(__file__)))  # tradeoff caches stay in this folder
FIG_DIR = os.environ.get('QDLAR_FIG_DIR', os.path.dirname(os.getcwd()) + '/Result_figure/sec6_4')
os.makedirs(RESULT_DIR, exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)

DIM = int(os.environ.get('QDLAR_DIM', '1'))
TRAIN_N = int(os.environ.get('QDLAR_TRAIN_N', '10000'))
TEST_N = int(os.environ.get('QDLAR_TEST_N', '1000'))
N_QUERY = int(os.environ.get('QDLAR_N_QUERY', '200'))
N_TRIALS = int(os.environ.get('QDLAR_N_TRIALS', '20'))
M_LIST = [int(s) for s in os.environ.get('QDLAR_M_LIST', '5,10,15,20').split(',')]
RHO_LIST = [float(s) for s in os.environ.get(
    'QDLAR_RHO_LIST',
    '0.25,0.35,0.5,0.7,0.85,1.0,1.2,1.45,1.75,2.1,2.5').split(',')]
N_JOBS = int(os.environ.get('QDLAR_JOBS', '-1'))
FORCE_RERUN = os.environ.get('QDLAR_RERUN', '') == '1'
AUC_VIEW = os.environ.get('QDLAR_AUC_VIEW', 'central_MLP_Attack-III')

HYBRID_PARA_FILE = os.path.join(DATA_DIR, 'trails_d%d_hybrid.npy' % DIM)
RESULT_CACHE = os.path.join(RESULT_DIR, 'tradeoff_hj_results_d%d.npy' % DIM)
MECH_CACHE = os.path.join(RESULT_DIR,
                          'tradeoff_hj_mech_results_d%d.npy' % DIM)


# MIA protocol constants (identical to MIA_toy_LAR_20trial.py)
CV_SHADOW = 3
S_GAU = 2
N_ADV = 2000
N_NON1 = 1000
N_BALANCED = 1000
CENTRAL_CASE = 2000

ATTACKS = ['Attack-I', 'Attack-II', 'Attack-III']
CLFS = ['LR', 'RF', 'MLP']
AUC_KEYS = ['%s_%s' % (c, a) for c in CLFS for a in ATTACKS]


def _fmt_dur(sec):
    if sec < 90:
        return '%.0f s' % sec
    if sec < 5400:
        return '%.1f min' % (sec / 60)
    return '%.2f h' % (sec / 3600)


# ----------------------------------------------------------------------------
# Data and stored parameters
# ----------------------------------------------------------------------------
def load_toy_data(trial):
    """Bit-exact victim pool: np.random.seed(trial) + generate_data."""
    np.random.seed(trial)
    train_shape = TRAIN_N if DIM == 1 else (TRAIN_N, DIM)
    test_shape = TEST_N if DIM == 1 else (TEST_N, DIM)
    X_tr, y_tr, X_te, y_te = generate_data(train_shape, test_shape, DIM)
    if DIM == 1:
        X_tr = X_tr.reshape(-1, 1)
        X_te = X_te.reshape(-1, 1)
    return X_tr, y_tr, X_te, y_te


def generate_pool(n):
    """Adversary pool from the same DGP (noisy y, like the training set)."""
    if DIM == 1:
        X = np.random.uniform(0.0, 1.0, n)
        y = create_y_g1(X) + np.random.normal(0, 0.1, n)
        X = X.reshape(-1, 1)
    else:
        X = np.random.uniform(0.0, 1.0, (n, DIM))
        y = create_y_g2(X) + np.random.normal(0, 0.1, n)
    return X, y


def get_blocks(X, y, m):
    b = len(y) // m
    return [(X[i * b:(i + 1) * b], y[i * b:(i + 1) * b]) for i in range(m)]


def get_assignments(m):
    random.seed(0)
    return [random.randint(1, 4) for _ in range(m)]


_STORE = {'file': None, 'reported': False}


def load_stored_params(trial, m):
    """Stored hybrid parameters {assign: array of length m} for this trial.
    The correct fen entry is found BY VECTOR LENGTH (the stored m values
    are 5,10,...,350, so lengths identify m unambiguously)."""
    if _STORE['file'] is None:
        if not os.path.exists(HYBRID_PARA_FILE):
            raise FileNotFoundError(
                'stored parameters %s not found -- this experiment never '
                'trains parameters, upload the file first' % HYBRID_PARA_FILE)
        _STORE['file'] = np.load(HYBRID_PARA_FILE, allow_pickle=True).tolist()
    para = _STORE['file']
    if not _STORE['reported']:
        _STORE['reported'] = True
        if os.environ.get('QDLAR_QUIET_STORE') != '1':
            e = para['local_h_gau'].get(0, para['local_h_gau'].get('0', {}))
            ms = sorted({len(np.atleast_1d(v)) for v in e.values()})
            print('[params] %s: stored m values %s (length-inferred)'
                  % (os.path.basename(HYBRID_PARA_FILE), ms))
    out = {}
    for a, key in ((1, 'local_h_gau'), (2, 'local_h_epan'),
                   (3, 'local_h_naive'), (4, 'local_k')):
        e = para[key].get(trial, para[key].get(str(trial), {}))
        arr = None
        for v in e.values():
            v = np.atleast_1d(np.asarray(v, dtype=float)).ravel()
            if len(v) == m:
                arr = v
                break
        if arr is None:
            raise ValueError('no stored length-%d parameter vector in %s[%s] '
                             'for trial %d' % (m, HYBRID_PARA_FILE, key, trial))
        out[a] = arr
    return out


# ----------------------------------------------------------------------------
# Local models with scaled parameters (QDLAR log mechanism inside)
# ----------------------------------------------------------------------------
def _cdist(A, B):
    return np.linalg.norm(A[:, None, :] - B[None, :, :], axis=2)


def party_output(X_q, b_x, b_y, assign, base_param, rho, m, log_mech=True):
    """fit (T,), h_loc (T,) for one party at scaling rho.  With log_mech
    (default) the QDLAR logarithmic mechanism is applied; log_mech=False
    uses the raw rho-scaled parameters (mechanism ablation)."""
    n = len(b_y)
    T = len(X_q)
    LOG = math.log(TRAIN_N, n)
    if assign == 4:                                     # KNN
        k = int(round(rho * base_param))
        k = max(1, min(k, n))
        if log_mech:
            k = int(math.ceil(k ** LOG / m))            # log mechanism
            k = max(1, min(k, n))
        dn = _cdist(X_q, b_x)
        srt = np.argsort(dn, axis=1)
        idx = srt[:, :k]
        fit = b_y[idx].mean(axis=1)
        radius = np.sort(dn, axis=1)[:, k - 1]
        h_loc = np.clip(radius, 1e-12, 1.0)
    else:
        h = min(1.0, rho * base_param)                  # h_j in (0, 1]
        if log_mech:
            h = min(1.0, h ** LOG)                      # log mechanism
        dn = _cdist(X_q, b_x) / h
        if assign == 1:                                 # Gaussian, s = 2
            w = np.exp(-dn ** 2)
        elif assign == 2:                               # Epanechnikov
            w = np.where(1 - dn ** 2 > 0, 1 - dn ** 2, 0.0)
        else:                                           # naive / cube
            w = (dn <= 1).astype(float)
        wsum = w.sum(axis=1)
        fit = np.divide(w @ b_y, wsum, out=np.zeros(T), where=wsum > 0)
        h_loc = np.full(T, h)
    return fit, np.clip(h_loc, 1e-12, 1.0)


def central_predict(X_q, blocks, assigns, params, rho, m,
                    log_mech=True, qualify=True):
    """QDLAR aggregate: log mechanism + qualification, equal weights over
    active parties (the paper's central rule for same-size blocks).
    log_mech=False / qualify=False switch the two mechanisms off
    individually (mechanism ablation)."""
    T = len(X_q)
    fit_sum = np.zeros(T)
    n_active = np.zeros(T)
    for j, (b_x, b_y) in enumerate(blocks):
        fit_j, _ = party_output(X_q, b_x, b_y, assigns[j],
                                params[assigns[j]][j], rho, m,
                                log_mech=log_mech)
        if qualify:
            active = (np.abs(fit_j) >= 1.0 / TRAIN_N).astype(float)
        else:
            active = np.ones(T)
        fit_sum += fit_j * active
        n_active += active
    return np.divide(fit_sum, n_active, out=np.zeros(T), where=n_active > 0)


def alg_gap(X_q, blocks, assigns, params, rho, m):
    """Definition-3 ALG: 1 - mean_j h_j(x)^d over ALL parties."""
    T = len(X_q)
    acc = np.zeros(T)
    for j, (b_x, b_y) in enumerate(blocks):
        _, h_loc = party_output(X_q, b_x, b_y, assigns[j],
                                params[assigns[j]][j], rho, m)
        acc += h_loc ** DIM
    return float(np.mean(1.0 - acc / m))


# ----------------------------------------------------------------------------
# MIA (replication of the user's toy protocol; Function_toy_MIA was not
# provided, so the three prediction-vector functions are reimplemented here
# following Function_same_block_warfarin_MIA.py and MIA_toy_LAR_20trial.py)
# ----------------------------------------------------------------------------
def prediction_vector_LAR(x_tra, y_tra, x_tes, y_tes, h):
    """Global Gaussian LAR (shadow model), s = 2 -- verbatim logic of the
    user's prediction_vector_LAR."""
    dn = _cdist(x_tes, x_tra) / h
    w = np.exp(-dn ** S_GAU)
    wsum = w.sum(axis=1)
    fit = np.divide(w @ y_tra, wsum, out=np.zeros(len(y_tes)),
                    where=wsum > 0)
    return np.abs(fit), (fit - y_tes) ** 2


def local_mia_vectors(X_q, y_q, b_x, b_y, assign, base_param, rho, m):
    """Party 1's OWN model (log mechanism, NO qualification): |fit| and
    squared loss on the queries."""
    fit, _ = party_output(X_q, b_x, b_y, assign, base_param, rho, m)
    return np.abs(fit), (fit - y_q) ** 2


def _attack_features(fit_abs, loss, kind):
    if kind == 'Attack-I':
        return fit_abs.reshape(-1, 1)
    if kind == 'Attack-II':
        return loss.reshape(-1, 1)
    return np.column_stack([fit_abs, loss])


def _make_clf(name, trial):
    if name == 'LR':
        return LogisticRegression(max_iter=1000, random_state=trial)
    if name == 'RF':
        return RandomForestClassifier(n_estimators=100, random_state=trial)
    return MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=500,
                         random_state=trial)


def run_attacks(shadow, victim_pairs, trial):
    """shadow: (fit_abs_mem_s, loss_mem_s, fit_abs_non_s, loss_non_s);
    victim_pairs: {'local': (mem, non), 'central': (mem, non)} with
    mem/non = (fit_abs, loss).  Returns {'local': {key: auc},
    'central': {key: auc}}."""
    fm_s, lm_s, fn_s, ln_s = shadow
    y_tr = np.hstack([np.ones(len(fm_s)), np.zeros(len(fn_s))])
    out = {}
    for side, (mem, non) in victim_pairs.items():
        fm, lm = mem
        fn, ln = non
        y_te = np.hstack([np.ones(len(fm)), np.zeros(len(fn))])
        aucs = {}
        for atk in ATTACKS:
            X_tr = np.vstack([_attack_features(fm_s, lm_s, atk),
                              _attack_features(fn_s, ln_s, atk)])
            X_te = np.vstack([_attack_features(fm, lm, atk),
                              _attack_features(fn, ln, atk)])
            for c in CLFS:
                clf = _make_clf(c, trial)
                clf.fit(X_tr, y_tr)
                aucs['%s_%s' % (c, atk)] = float(
                    roc_auc_score(y_te, clf.predict_proba(X_te)[:, 1]))
        out[side] = aucs
    return out


# ----------------------------------------------------------------------------
# One trial: all m, all rho (self-contained seeds -> parallel-safe)
# ----------------------------------------------------------------------------
def run_single_trial(trial, m):
    X_vic, y_vic, X_test, y_test = load_toy_data(trial)

    np.random.seed(7777 + trial)
    max_local = TRAIN_N // min(M_LIST)
    X_pool, y_pool = generate_pool(N_ADV + N_NON1 +
                                   max(max_local, CENTRAL_CASE))
    X_adv, y_adv = X_pool[:N_ADV], y_pool[:N_ADV]
    X_non1, y_non1 = X_pool[N_ADV:N_ADV + N_NON1], y_pool[N_ADV:N_ADV + N_NON1]
    X_rest = X_pool[N_ADV + N_NON1:]
    y_rest = y_pool[N_ADV + N_NON1:]

    # shadow model (rho-independent, m-independent)
    h_shadow = float(global_parameter_h(X_adv, y_adv.ravel(), CV_SHADOW, DIM))
    np.random.seed(5555 + trial)
    idx_adv = np.random.choice(len(X_adv), N_BALANCED, replace=False)
    fm_s, lm_s = prediction_vector_LAR(X_adv, y_adv, X_adv[idx_adv],
                                       y_adv[idx_adv], h_shadow)
    fn_s, ln_s = prediction_vector_LAR(X_adv, y_adv, X_non1, y_non1, h_shadow)
    shadow = (fm_s, lm_s, fn_s, ln_s)

    # central-attack member subsample (seed convention of the user's code)
    n_central = min(CENTRAL_CASE, len(X_vic))
    np.random.seed(9999 + trial)
    idx_vic = np.random.choice(len(X_vic), n_central, replace=False)
    X_vic_m, y_vic_m = X_vic[idx_vic], y_vic[idx_vic]
    X_non_c, y_non_c = X_rest[:n_central], y_rest[:n_central]

    X_query = X_test[:N_QUERY]
    if True:
        blocks = get_blocks(X_vic, y_vic, m)
        assigns = get_assignments(m)
        params = load_stored_params(trial, m)
        n1 = len(blocks[0][1])
        X_non_l, y_non_l = X_rest[:n1], y_rest[:n1]
        rec_m = {'MSE': [], 'ALG': [], 'h_mean': [],
                 'AUC_central': [], 'AUC_local': []}
        for rho in RHO_LIST:
            fit_test = central_predict(X_test, blocks, assigns, params, rho, m)
            mse = float(np.mean((fit_test - y_test) ** 2))
            alg = alg_gap(X_query, blocks, assigns, params, rho, m)
            # mean effective kernel bandwidth after the log mechanism
            hs = []
            for j, (b_x, b_y) in enumerate(blocks):
                a = assigns[j]
                if a != 4:
                    h = min(1.0, rho * params[a][j])
                    hs.append(min(1.0, h ** math.log(TRAIN_N, len(b_y))))
            # local attack vectors (party 1)
            b_x1, b_y1 = blocks[0]
            fm_l, lm_l = local_mia_vectors(b_x1, b_y1, b_x1, b_y1,
                                           assigns[0], params[assigns[0]][0],
                                           rho, m)
            fn_l, ln_l = local_mia_vectors(X_non_l, y_non_l, b_x1, b_y1,
                                           assigns[0], params[assigns[0]][0],
                                           rho, m)
            # central attack vectors
            fit_c_mem = central_predict(X_vic_m, blocks, assigns, params,
                                        rho, m)
            fm_c, lm_c = np.abs(fit_c_mem), (fit_c_mem - y_vic_m) ** 2
            fit_c_non = central_predict(X_non_c, blocks, assigns, params,
                                        rho, m)
            fn_c, ln_c = np.abs(fit_c_non), (fit_c_non - y_non_c) ** 2
            aucs = run_attacks(shadow,
                               {'local': ((fm_l, lm_l), (fn_l, ln_l)),
                                'central': ((fm_c, lm_c), (fn_c, ln_c))},
                               trial)
            rec_m['MSE'].append(mse)
            rec_m['ALG'].append(alg)
            rec_m['h_mean'].append(float(np.mean(hs)) if hs else np.nan)
            rec_m['AUC_central'].append(aucs['central'])
            rec_m['AUC_local'].append(aucs['local'])
    return rec_m


# ----------------------------------------------------------------------------
# Driver over trials (parallel), cache, fingerprint
# ----------------------------------------------------------------------------
def _param_sig():
    if os.path.exists(HYBRID_PARA_FILE):
        return [(os.path.basename(HYBRID_PARA_FILE),
                 int(os.path.getsize(HYBRID_PARA_FILE)))]
    return []


def _fingerprint():
    return {'DIM': DIM, 'TRAIN_N': TRAIN_N, 'TEST_N': TEST_N,
            'N_QUERY': N_QUERY, 'N_TRIALS': N_TRIALS, 'M_LIST': list(M_LIST),
            'RHO_LIST': list(RHO_LIST), 'param_sig': _param_sig()}


def get_results():
    if not FORCE_RERUN and os.path.exists(RESULT_CACHE):
        pack = np.load(RESULT_CACHE, allow_pickle=True).tolist()
        if pack.get('fingerprint') == _fingerprint():
            print('Loaded saved results from %s (no re-run needed).'
                  % RESULT_CACHE)
            return pack['results']
        print('Cached results match a different configuration -- re-running.')
    from joblib import Parallel, delayed
    load_stored_params(0, M_LIST[0])     # print the coverage report once,
    _STORE['reported'] = True            # here in the main process
    results = {}
    t_start = time.time()
    for im, m in enumerate(M_LIST):
        print('[stage %d/%d] m=%d: %d trials x %d rho values ...'
              % (im + 1, len(M_LIST), m, N_TRIALS, len(RHO_LIST)))
        t0 = time.time()
        if N_JOBS == 1 or N_TRIALS == 1:
            per_trial = [run_single_trial(t, m) for t in range(N_TRIALS)]
        else:
            os.environ['QDLAR_QUIET_STORE'] = '1'   # no prints in workers
            try:
                per_trial = Parallel(n_jobs=N_JOBS)(
                    delayed(run_single_trial)(t, m) for t in range(N_TRIALS))
            finally:
                os.environ.pop('QDLAR_QUIET_STORE', None)
        results[m] = _stack_trials(per_trial)
        np.save(RESULT_CACHE, {'fingerprint': _fingerprint(),
                               'results': results})      # checkpoint per m
        el = time.time() - t_start
        eta = el / (im + 1) * (len(M_LIST) - im - 1)
        print('[prog %d/%d] m=%d done in %s | elapsed %s | ETA %s'
              % (im + 1, len(M_LIST), m, _fmt_dur(time.time() - t0),
                 _fmt_dur(el), _fmt_dur(eta)))
    np.save(RESULT_CACHE, {'fingerprint': _fingerprint(), 'results': results})
    print('Saved results to %s' % RESULT_CACHE)
    return results


def _stack_trials(per_trial):
    keys = per_trial[0].keys()
    out = {}
    for k in keys:
        if k in ('AUC_central', 'AUC_local'):
            out[k] = np.array([[ [tr[k][r][key] for key in AUC_KEYS]
                                 for r in range(len(RHO_LIST))]
                               for tr in per_trial])     # (trials, rho, 9)
        else:
            out[k] = np.array([tr[k] for tr in per_trial])  # (trials, rho)
    return out


# ----------------------------------------------------------------------------
# Mechanism ablation on MSE: how much do the logarithmic mechanism and the
# qualification rule each contribute?  Three variants of the central rule:
#   full      -- QDLAR: log mechanism + qualification (the main experiment)
#   log_only  -- log mechanism, NO qualification (all m parties averaged)
#   qual_only -- qualification, NO log mechanism (raw rho-scaled params)
# MSE only (no ALG / MIA), separate cache -> much cheaper than the main run.
# ----------------------------------------------------------------------------
MECH_VARIANTS = ['full', 'log_only', 'qual_only']
MECH_LABEL = {'full': 'QDLAR (log + qualification)',
              'log_only': 'log mechanism only',
              'qual_only': 'qualification only'}
MECH_STYLE = {'full': dict(color='#8C2D04', lw=2.6, ls='-', marker='o',
                           ms=5, zorder=5),
              'log_only': dict(color='#08589E', lw=2.0, ls='-', marker='s',
                               ms=4.5, zorder=4),
              'qual_only': dict(color='#1B7837', lw=2.0, ls='-', marker='^',
                                ms=4.5, zorder=4)}


def run_mech_trial(trial, m):
    """MSE of the three mechanism variants at every rho (one trial).
    Uses the STORED local parameters (no re-training) and the fast path of
    Function_same_block_new: distances are computed once per party, the
    rho sweep x mechanism variants only re-weights them."""
    X_vic, y_vic, X_test, y_test = load_toy_data(trial)
    blocks = get_blocks(X_vic, y_vic, m)
    assigns = get_assignments(m)
    params = load_stored_params(trial, m)
    # one-time per party: distances (KNN also sorted order + prefix sums)
    pre = [hybrid_party_precompute(X_test, b_x, b_y, assigns[j])
           for j, (b_x, b_y) in enumerate(blocks)]

    def _fits(use_log):
        return np.column_stack([
            hybrid_party_fit_fast(pre[j], assigns[j], blocks[j][1],
                                  params[assigns[j]][j], rho, m, TRAIN_N,
                                  use_log=use_log)
            for j in range(m)])

    def _mse(fit):
        return float(np.mean((fit - y_test) ** 2))

    out = {v: [] for v in MECH_VARIANTS}
    for rho in RHO_LIST:
        fit_log = _fits(use_log=True)              # shared by full/log_only
        fit_raw = _fits(use_log=False)             # qual_only
        out['full'].append(_mse(hybrid_central_combine(
            fit_log, TRAIN_N, use_qualify=True)))
        out['log_only'].append(_mse(hybrid_central_combine(
            fit_log, TRAIN_N, use_qualify=False)))
        out['qual_only'].append(_mse(hybrid_central_combine(
            fit_raw, TRAIN_N, use_qualify=True)))
    return out


def _mech_fingerprint():
    fp = _fingerprint()
    fp['mech_fmt'] = 1
    return fp


def get_mech_results():
    if not FORCE_RERUN and os.path.exists(MECH_CACHE):
        pack = np.load(MECH_CACHE, allow_pickle=True).tolist()
        if pack.get('fingerprint') == _mech_fingerprint():
            print('Loaded saved mechanism-ablation results from %s '
                  '(no re-run needed).' % MECH_CACHE)
            return pack['results']
        print('Cached mechanism-ablation results match a different '
              'configuration -- re-running.')
    from joblib import Parallel, delayed
    load_stored_params(0, M_LIST[0])
    _STORE['reported'] = True
    results = {}
    t_start = time.time()
    for im, m in enumerate(M_LIST):
        t0 = time.time()
        if N_JOBS == 1 or N_TRIALS == 1:
            per_trial = [run_mech_trial(t, m) for t in range(N_TRIALS)]
        else:
            os.environ['QDLAR_QUIET_STORE'] = '1'
            try:
                per_trial = Parallel(n_jobs=N_JOBS)(
                    delayed(run_mech_trial)(t, m) for t in range(N_TRIALS))
            finally:
                os.environ.pop('QDLAR_QUIET_STORE', None)
        results[m] = {v: np.array([tr[v] for tr in per_trial])
                      for v in MECH_VARIANTS}          # (trials, rho)
        np.save(MECH_CACHE, {'fingerprint': _mech_fingerprint(),
                             'results': results})
        el = time.time() - t_start
        eta = el / (im + 1) * (len(M_LIST) - im - 1)
        print('[mech %d/%d] m=%d done in %s | elapsed %s | ETA %s'
              % (im + 1, len(M_LIST), m, _fmt_dur(time.time() - t0),
                 _fmt_dur(el), _fmt_dur(eta)))
    np.save(MECH_CACHE, {'fingerprint': _mech_fingerprint(),
                         'results': results})
    print('Saved mechanism-ablation results to %s' % MECH_CACHE)
    return results


def plot_mech(results):
    """MSE vs rho for the three mechanism variants, 2x2 panels over m."""
    import matplotlib
    # matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    rcParams.update({'font.family': 'Times New Roman', 'font.size': 15,
                     'mathtext.fontset': 'stix'})
    x = np.arange(len(RHO_LIST))
    i_base = RHO_LIST.index(1.0) if 1.0 in RHO_LIST else None
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8.6))
    for ax, m in zip(axes.flat, M_LIST):
        for v in MECH_VARIANTS:
            arr = results[m][v]                        # (trials, rho)
            mu, sd = arr.mean(axis=0), arr.std(axis=0)
            st = MECH_STYLE[v]
            ax.plot(x, mu, label=MECH_LABEL[v], **st)
            ax.fill_between(x, mu - sd, mu + sd, color=st['color'],
                            alpha=0.10)
        if i_base is not None:
            ax.axvline(i_base, color='#636363', ls='-', lw=1.4)
        ax.set_xticks(x)
        ax.set_xticklabels([('%g' % r) for r in RHO_LIST], fontsize=15,
                           rotation=45)
        ax.set_xlabel(r'local-parameter scaling $\rho$'
                      r'  ($h_j\to\rho h_j$, $k_j\to\rho k_j$)', fontsize=18)
        ax.set_ylabel('MSE')
        ax.set_yscale('log')
        ax.set_title(r'$m=%d$' % m)
        ax.grid(alpha=0.25)
        ax.legend(fontsize=12, loc='best', frameon=False)
    fig.suptitle(r'Mechanism ablation on MSE under collective local-parameter'
                 r' scaling ($d=%d$, equal-size setting)' % DIM,
                 weight='bold', fontsize=20)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fpath = os.path.join(FIG_DIR,
                         'Fig_tradeoff_hj_MSE_mechanisms_d%d.pdf' % DIM)
    fig.savefig(fpath, dpi=600, bbox_inches='tight')
    plt.show()
    plt.close(fig)
    print('Saved %s' % fpath)


# ----------------------------------------------------------------------------
# Plotting: dual-axis pairwise trade-offs, 2x2 panels over m
# ----------------------------------------------------------------------------
def _auc_view_series(rec, view):
    """(rho,) mean and sd of the selected AUC view over trials."""
    arr_c = rec['AUC_central']          # (trials, rho, 9)
    arr_l = rec['AUC_local']
    if view == 'central_max':
        v = arr_c.max(axis=2)
    elif view == 'local_max':
        v = arr_l.max(axis=2)
    else:
        side, key = view.split('_', 1)
        idx = AUC_KEYS.index(key)
        v = (arr_c if side == 'central' else arr_l)[:, :, idx]
    return v.mean(axis=0), v.std(axis=0)


def plot_pair(results, met_a, met_b, fname, better_a, better_b):
    """met in {'MSE','ALG','AUC'}; better in {'down','up'}."""
    import matplotlib
    # matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    rcParams.update({'font.family': 'Times New Roman', 'font.size': 15,
                     'mathtext.fontset': 'stix'})

    def series(rec, met):
        if met == 'AUC':
            return _auc_view_series(rec, AUC_VIEW)
        return rec[met].mean(axis=0), rec[met].std(axis=0)

    x = np.arange(len(RHO_LIST))
    i_base = RHO_LIST.index(1.0) if 1.0 in RHO_LIST else None
    CA, CB = '#8C2D04', '#08589E'
    fig, axes = plt.subplots(2, 2, figsize=(11.5, 8.6))
    for ax, m in zip(axes.flat, M_LIST):
        rec = results[m]
        mu_a, sd_a = series(rec, met_a)
        mu_b, sd_b = series(rec, met_b)
        ax2 = ax.twinx()
        ln1 = ax.plot(x, mu_a, color=CA, lw=2.4, marker='o', ms=5,
                      label=met_a + (' (lower better)' if better_a == 'down'
                                     else ' (higher better)'))
        ax.fill_between(x, mu_a - sd_a, mu_a + sd_a, color=CA, alpha=0.12)
        ln2 = ax2.plot(x, mu_b, color=CB, lw=2.0, ls='-', marker='s', ms=4.5,
                       label=met_b + (' (lower better)' if better_b == 'down'
                                      else ' (higher better)'))
        ax2.fill_between(x, mu_b - sd_b, mu_b + sd_b, color=CB, alpha=0.10)
        if i_base is not None:
            ax.axvline(i_base, color='#636363', ls='-', lw=1.4)
            # ax.text(i_base, ax.get_ylim()[1], r' $\rho=1$ (trained)',
            #         color='#636363', fontsize=11, va='top')
        ax.set_xticks(x)
        ax.set_xticklabels([('%g' % r) for r in RHO_LIST], fontsize=14,
                           rotation=45)
        ax.set_xlabel(r'local-parameter scaling $\rho$'
                      r'  ($h_j\to\rho h_j$, $k_j\to\rho k_j$)', fontsize=16)
        ax.set_ylabel(met_a, color=CA)
        ax2.set_ylabel(met_b, color=CB)
        ax.tick_params(axis='y', colors=CA)
        ax2.tick_params(axis='y', colors=CB)
        if met_a == 'MSE':
            ax.set_yscale('log')
        ax.set_title(r'$m=%d$' % m)
        ax.grid(alpha=0.25)
        lns = ln1 + ln2
        ax.legend(lns, [l.get_label() for l in lns], fontsize=16,
                  loc='best', frameon=False)
    fig.suptitle(r'QDLAR under collective local-parameter scaling: %s vs. %s'
                 r' ($d=%d$, equal-size setting)' % (met_a, met_b, DIM),weight='bold',
                 fontsize=20)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fpath = os.path.join(FIG_DIR, fname)
    fig.savefig(fpath, dpi=600, bbox_inches='tight')
    plt.show()
    plt.close(fig)
    print('Saved %s' % fpath)


# ----------------------------------------------------------------------------
# Combined d=1 + d=5 figures at a single party count m (M_FIX, default 10):
# every figure has exactly TWO panels (d=1 | d=5).  The per-dimension caches
# produced by tradeoff_hj_d1.py / tradeoff_hj_d5.py are loaded for plotting
# only -- run those two drivers first.  Driver: tradeoff_hj_d1d5.py.
# ----------------------------------------------------------------------------
M_FIX = int(os.environ.get('QDLAR_M_FIX', '10'))


def _load_pack_dim(kind, dim):
    """Load a per-dimension cache ('main' or 'mech') for plotting."""
    path = os.path.join(
        RESULT_DIR,
        ('tradeoff_hj_results_d%d.npy' if kind == 'main'
         else 'tradeoff_hj_mech_results_d%d.npy') % dim)
    if not os.path.exists(path):
        raise SystemExit('Missing cache %s -- run tradeoff_hj_d%d.py first.'
                         % (path, dim))
    pack = np.load(path, allow_pickle=True).tolist()
    fp = pack.get('fingerprint', {})
    for k, v in (('DIM', dim), ('M_LIST', list(M_LIST)),
                 ('RHO_LIST', list(RHO_LIST)), ('N_TRIALS', N_TRIALS)):
        if fp.get(k) != v:
            print('WARNING: %s was computed with %s=%s (current: %s).'
                  % (path, k, fp.get(k), v))
    return pack['results']


def _metric_series(rec, met):
    """(rho,) mean and sd of one metric over trials (AUC uses AUC_VIEW)."""
    if met == 'AUC':
        return _auc_view_series(rec, AUC_VIEW)
    return rec[met].mean(axis=0), rec[met].std(axis=0)


def _better_tag(met, better):
    return met + (' (lower better)' if better == 'down'
                  else ' (higher better)')


def _pair_panel(ax, rec, met_a, met_b, better_a, better_b):
    """One dual-axis trade-off panel at the fixed m; returns legend lines."""
    x = np.arange(len(RHO_LIST))
    i_base = RHO_LIST.index(1.0) if 1.0 in RHO_LIST else None
    CA, CB = '#8C2D04', '#08589E'
    mu_a, sd_a = _metric_series(rec, met_a)
    mu_b, sd_b = _metric_series(rec, met_b)
    ax2 = ax.twinx()
    ln1 = ax.plot(x, mu_a, color=CA, lw=2.4, marker='o', ms=6,
                  label=_better_tag(met_a, better_a))
    lo_a = mu_a - sd_a
    if met_a == 'MSE':                     # log axis cannot show <= 0
        lo_a = np.maximum(lo_a, np.maximum(mu_a, 1e-300) * 0.5)
    ax.fill_between(x, lo_a, mu_a + sd_a, color=CA, alpha=0.12)
    ln2 = ax2.plot(x, mu_b, color=CB, lw=2.0, ls='-', marker='s', ms=5.5,
                   label=_better_tag(met_b, better_b))
    ax2.fill_between(x, mu_b - sd_b, mu_b + sd_b, color=CB, alpha=0.10)
    if i_base is not None:
        ax.axvline(i_base, color='#636363', ls='-', lw=1.4)
    ax.set_xticks(x)
    ax.set_xticklabels([('%g' % r) for r in RHO_LIST], fontsize=15,
                       rotation=45)
    ax.set_xlabel(r'local-parameter scaling $\rho$'
                  r'  ($h_j\to\rho h_j$, $k_j\to\rho k_j$)', fontsize=18)
    ax.set_ylabel(met_a, color=CA)
    ax2.set_ylabel(met_b, color=CB)
    ax.tick_params(axis='y', colors=CA)
    ax2.tick_params(axis='y', colors=CB)
    if met_a == 'MSE':
        ax.set_yscale('log')
    ax.grid(alpha=0.25)
    return ln1 + ln2


def plot_pair_d1d5(res_by_dim, met_a, met_b, fname, better_a, better_b):
    """Trade-off of met_a vs. met_b at m = M_FIX: two panels (d=1 | d=5)."""
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    rcParams.update({'font.family': 'Times New Roman', 'font.size': 15,
                     'mathtext.fontset': 'stix'})
    if M_FIX not in M_LIST:
        raise SystemExit('M_FIX=%d is not in M_LIST %s.'
                         % (M_FIX, M_LIST))
    fig, axes = plt.subplots(1, 2, figsize=(13.6, 5.6))
    lns = None
    for ax, dim in ((axes[0], 1), (axes[1], 5)):
        lns = _pair_panel(ax, res_by_dim[dim][M_FIX], met_a, met_b,
                          better_a, better_b) if lns is None else               _pair_panel(ax, res_by_dim[dim][M_FIX], met_a, met_b,
                          better_a, better_b)
        ax.set_title(r'$d=%d$' % dim, fontsize=22, weight='bold')
    # fig.suptitle(r'QDLAR under collective local-parameter scaling: %s vs. %s'
    #              r' ($m=%d$, equal-size setting)'
    #              % (met_a, met_b, M_FIX), weight='bold', fontsize=19, y=0.99)
    fig.legend(lns, [l.get_label() for l in lns], loc='lower center',
               ncol=2, fontsize=18, frameon=False,
               bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(rect=[0, 0.07, 1, 0.95])
    fpath = os.path.join(FIG_DIR, fname)
    fig.savefig(fpath, dpi=600, bbox_inches='tight', pad_inches=0.1)
    plt.close(fig)
    print('Saved %s' % fpath)


def plot_mech_d1d5(mech_by_dim, fname):
    """Mechanism ablation on MSE at m = M_FIX: two panels (d=1 | d=5)."""
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    rcParams.update({'font.family': 'Times New Roman', 'font.size': 15,
                     'mathtext.fontset': 'stix'})
    if M_FIX not in M_LIST:
        raise SystemExit('M_FIX=%d is not in M_LIST %s.'
                         % (M_FIX, M_LIST))
    x = np.arange(len(RHO_LIST))
    i_base = RHO_LIST.index(1.0) if 1.0 in RHO_LIST else None
    fig, axes = plt.subplots(1, 2, figsize=(13.6, 5.6))
    lns = None
    for ax, dim in ((axes[0], 1), (axes[1], 5)):
        for v in MECH_VARIANTS:
            arr = mech_by_dim[dim][M_FIX][v]           # (trials, rho)
            mu, sd = arr.mean(axis=0), arr.std(axis=0)
            st = MECH_STYLE[v]
            ln = ax.plot(x, mu, label=MECH_LABEL[v], **st)
            lo = np.maximum(mu - sd, np.maximum(mu, 1e-300) * 0.5)
            ax.fill_between(x, lo, mu + sd, color=st['color'], alpha=0.10)
            if lns is None:
                lns = []
            if dim == 1:
                lns += ln
        if i_base is not None:
            ax.axvline(i_base, color='#636363', ls='-', lw=1.4)
        ax.set_xticks(x)
        ax.set_xticklabels([('%g' % r) for r in RHO_LIST], fontsize=18,
                           rotation=45)
        ax.set_xlabel(r'local-parameter scaling $\rho$'
                      r'  ($h_j\to\rho h_j$, $k_j\to\rho k_j$)',
                      fontsize=20)
        ax.set_ylabel('MSE')
        ax.set_yscale('log')
        ax.set_title(r'$d=%d$' % dim, fontsize=22, weight='bold')
        ax.grid(alpha=0.25)
    # fig.suptitle(r'Mechanism ablation on MSE under collective local-parameter'
    #              r' scaling ($m=%d$, equal-size setting)' % M_FIX,
    #              weight='bold', fontsize=19, y=0.99)
    fig.legend(lns, [l.get_label() for l in lns], loc='lower center',
               ncol=3, fontsize=18, frameon=False,
               bbox_to_anchor=(0.5, 0.0))
    fig.tight_layout(rect=[0, 0.07, 1, 0.95])
    fpath = os.path.join(FIG_DIR, fname)
    fig.savefig(fpath, dpi=600, bbox_inches='tight', pad_inches=0.1)
    plt.close(fig)
    print('Saved %s' % fpath)


def main_d1d5():
    """Combined d=1 + d=5 figures at m = M_FIX (caches must exist)."""
    res = {d: _load_pack_dim('main', d) for d in (1, 5)}
    mech = {d: _load_pack_dim('mech', d) for d in (1, 5)}
    print('Combined d=1 + d=5 trade-off figures at m = %d' % M_FIX)
    plot_pair_d1d5(res, 'MSE', 'ALG',
                   'Fig_tradeoff_hj_MSE_ALG_d1d5_m%d.pdf' % M_FIX,
                   'down', 'up')
    plot_pair_d1d5(res, 'MSE', 'AUC',
                   'Fig_tradeoff_hj_MSE_AUC_d1d5_m%d----11.pdf' % M_FIX,
                   'down', 'down')
    plot_pair_d1d5(res, 'ALG', 'AUC',
                   'Fig_tradeoff_hj_ALG_AUC_d1d5_m%d----22.pdf' % M_FIX,
                   'up', 'down')
    plot_mech_d1d5(mech,
                   'Fig_tradeoff_hj_MSE_mechanisms_d1d5_m%d---33.pdf' % M_FIX)





def main():
    print('h_j-scaling trade-off | d = %d | m in %s | rho in %s | %d trials'
          % (DIM, M_LIST, RHO_LIST, N_TRIALS))
    results = get_results()
    plot_pair(results, 'MSE', 'ALG',
              'Fig_tradeoff_hj_MSE_ALG_d%d.pdf' % DIM, 'down', 'up')
    plot_pair(results, 'MSE', 'AUC',
              'Fig_tradeoff_hj_MSE_AUC_d%d.pdf' % DIM, 'down', 'down')
    plot_pair(results, 'ALG', 'AUC',
              'Fig_tradeoff_hj_ALG_AUC_d%d.pdf' % DIM, 'up', 'down')
    mech = get_mech_results()
    plot_mech(mech)


if __name__ == '__main__':
    # main()
    main_d1d5()
