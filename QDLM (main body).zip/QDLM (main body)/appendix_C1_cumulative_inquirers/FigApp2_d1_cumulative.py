import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import os
from matplotlib import rcParams
fontsize_specific = 18
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)

'''1. load data'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d1_gau2.npy', allow_pickle=True)
trails_d1_gau2 = loadData.tolist()
print(trails_d1_gau2.keys())

GEs_mean = [np.mean(trails_d1_gau2['GEs'])] * 70
AEs_mean = np.mean(trails_d1_gau2['AEs'], axis=1)  # average AE, LE, GE of 20 trails, axis=1 means averaging on trail axis
LEs_mean = np.mean(trails_d1_gau2['LEs'], axis=1)
AE_adapts_mean = np.mean(trails_d1_gau2['AE_adapts'], axis=1)
AE_logs_mean = np.mean(trails_d1_gau2['AE_logs'], axis=1)
AE_log_actives_mean = np.mean(trails_d1_gau2['AE_log_actives'], axis=1)
LE_adapts_mean = np.mean(trails_d1_gau2['LE_adapts'], axis=1)
AE_log_actives_diff_mean = np.mean(trails_d1_gau2['AE_log_actives_diff'], axis=1)
last_block_size = trails_d1_gau2['last_block_size']



''' ---------------------- m=5,10,20; N=1000,2000,3000,...,10000 ---------------------------------'''
GEs_Nchange_mean = np.mean(trails_d1_gau2['GEs_Nchange'], axis=1)
AE_active_m5_Nchange_mean = np.mean(trails_d1_gau2['AE_active_m5_Nchange'], axis=1)
AE_active_m10_Nchange_mean = np.mean(trails_d1_gau2['AE_active_m10_Nchange'], axis=1)
AE_active_m20_Nchange_mean = np.mean(trails_d1_gau2['AE_active_m20_Nchange'], axis=1)

# 当病人有10,000:
print(GEs_Nchange_mean)  # 2.30688721e-05
print(GEs_mean)          # 2.0423391940236692e-05

# 当病人的数量增加时：
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
num_patient = [i for i in range(1000, 10001, 1000)]  # [1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000, 10000]

ax.plot(num_patient, GEs_Nchange_mean, c='black', marker='s', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(num_patient, AE_active_m5_Nchange_mean, c='brown', marker='o', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(num_patient, AE_active_m10_Nchange_mean, c='royalblue', marker='o', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(num_patient, AE_active_m20_Nchange_mean, c='forestgreen', marker='o', linestyle='-', linewidth=1.4, markersize=4)
plt.legend(['$GE$', '$AE_\mathrm{active}(m=5)$', '$AE_\mathrm{active}(m=10)$', '$AE_\mathrm{active}(m=20)$'], ncol=2, loc='upper left', fontsize='15')
ax.set_xlabel('Number of clients ($d$=1)', fontsize='18')
ax.set_ylabel('MSE (Gaussian)', fontsize='18')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C1/Increasing_clients_d1.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()






