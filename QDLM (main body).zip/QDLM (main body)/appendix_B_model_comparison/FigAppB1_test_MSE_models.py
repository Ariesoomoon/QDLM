# FigAppB1_test_MSE_models.py
# Paper: Appendix Figure 1 (Appendix B, test-MSE comparison of local algorithms).
# Formerly: Algorithm_MIA/appendix中的MIA实验（比较不同局部算法的精度）.py
# Run from this folder (one level below the repo root).
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# -------------------------------------------------
# 0. 全局字体设置（关键：必须 rcParams.update）
# -------------------------------------------------
fontsize_specific = 18
config = {
    "font.family": "Times New Roman",
    "font.size": fontsize_specific,
    "mathtext.fontset": "stix",
    "axes.unicode_minus": False,   # 负号正常显示
}
plt.rcParams.update(config)

# -------------------------------------------------
# 1. 整理数据
# -------------------------------------------------
data = {
    "Model": ["LAR", "KRR", "Linear", "MLP", "1NN"],
    "d=1_mean": [0.000090, 0.000120, 0.035715, 0.000146, 0.009937],
    "d=1_std":  [0.000037, 0.000046, 0.001474, 0.000066, 0.000723],
    "d=5_mean": [0.001335, 0.002434, 0.001652, 0.000619, 0.011272],
    "d=5_std":  [0.000189, 0.000395, 0.000335, 0.000220, 0.000982],
}

df = pd.DataFrame(data).set_index("Model")
print(df)

# -------------------------------------------------
# 2. 分组柱状图（对数坐标）
# -------------------------------------------------
models = df.index.tolist()
x = np.arange(len(models))
width = 0.35

fig, ax = plt.subplots(figsize=(10, 5))

bars1 = ax.bar(
    x - width / 2, df["d=1_mean"], width,
    yerr=df["d=1_std"], capsize=4,
    label="d = 1", color="#4C72B0", edgecolor="black", linewidth=0.6
)
bars2 = ax.bar(
    x + width / 2, df["d=5_mean"], width,
    yerr=df["d=5_std"], capsize=4,
    label="d = 5", color="#DD8452", edgecolor="black", linewidth=0.6
)

ax.set_yscale("log")
ax.set_ylabel("Test MSE (log scale)", fontsize=fontsize_specific)
# ax.set_xlabel("Model", fontsize=fontsize_specific)
ax.set_title(
    "Test MSE of different regression models",
    fontsize=fontsize_specific + 2, pad=12
)
ax.set_xticks(x)
ax.set_xticklabels(models, fontsize=fontsize_specific)
ax.tick_params(axis="y", labelsize=fontsize_specific)
ax.legend(frameon=False, fontsize=18)
ax.grid(axis="y", linestyle="--", alpha=0.4, which="both")
ax.set_axisbelow(True)

plt.tight_layout()
plt.savefig(os.path.dirname(os.getcwd()) + "/Result_figure/appendix_B/test_mse_bar_log.pdf", dpi=300, bbox_inches="tight")
plt.show()