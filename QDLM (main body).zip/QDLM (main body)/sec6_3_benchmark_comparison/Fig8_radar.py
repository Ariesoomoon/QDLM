"""
================================================================================
Fig8_radar.py  (toy simulation, d = 5)
Paper: Main Figure 8 (Section 6.3)
================================================================================
Radar (spider) charts of the combination strategies at m = M_FIXED.
Five "bigger-is-better" spokes: Accuracy (-log10 MSE), framework-level
interpretability (PWAI; OW/SW score 0 via the data-locality factor L),
Stability (inverse trial-to-trial MSE variability), Efficiency
(log-normalised wall-clock time of the weight computation) and MIA
resistance (1 - AUC); every spoke is min-max scaled across the plotted
methods, so the outer ring is the best.

Outputs (in ../Result_figure/sec6_3/):
  * Fig_combination_radar_noQD_same_m*_d5.pdf / _diff_   (EW, OW, BS, WA, FL)
  * Fig_combination_radar_QD_same_m*_d5.pdf   / _diff_   (EWQD, OWQD, BSQD,
                                                          WAQD, FL)

The AUC spoke needs the MIA results -- if the cached results predate the
MIA extension they are recomputed automatically (fingerprint change).
================================================================================
"""

import os
os.environ['QDLAR_DIM'] = '5'      # must precede the core import

# import combination_foresting_core_gpu_new_change4 as cf
import combination_core_radar as cf

def main():
    results = cf.get_results()
    for setting in ('same', 'diff'):
        cf.plot_radar(results, setting)
    cf.summary_table()

if __name__ == '__main__':
    main()


