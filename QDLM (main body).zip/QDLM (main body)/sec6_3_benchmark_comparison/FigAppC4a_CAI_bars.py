"""
================================================================================
FigAppC4a_CAI_bars.py  (toy simulation; CAI = PWAI, Definition 1)
Paper: Appendix Figure 4a (Section C.4)
================================================================================
PWAI (Definition 1) comparison of combination / forecasting strategies:
EW, OW, BS, BS-QD, WA (QDLAR), QDKRR, QDDT, QDRF, QDLR, QD1NN and classic
federated learning (FL, visibility V = 0).

Outputs (under ../Result_figure/sec6_3/):
  * Fig_combination_PWAI_same_d1.pdf / Fig_combination_PWAI_diff_d1.pdf
        PWAI vs. m, equal-size / heterogeneous-size parties;
        panel (a): aggregation strategies on the same hybrid LAR parties,
        panel (b): QD local algorithms (WA/QDLAR and FL as references);
  * Fig_combination_PWAI_bar_m50_d1.pdf
        grouped bars at the fixed m = M_FIXED (both settings);
  * Fig_combination_PWAI_decomp_same_d1.pdf / _diff_d1.pdf
        distinguishability D and participation rate P vs. m;
  * Fig_combination_tradeoff_same_m50_d1.pdf / _diff_m50_d1.pdf
        test MSE vs. PWAI at m = M_FIXED;
  * Fig_combination_MSE_same_d1.pdf / _diff_d1.pdf (utility record);
  * ../Result_data_for_combination/combination_foresting_gpu_new_summary_d*_m*.csv.

Results are cached in ../Result_data_for_combination/
combination_foresting_gpu_new_results_d*_pwai0.npy -- re-running only re-plots.
================================================================================
"""

import os
os.environ.setdefault('QDLAR_DIM', os.environ.get('QDLM_DIM', '5'))  # must precede the core import; paper used d=1 and d=5 (set QDLM_DIM=1 or QDLAR_DIM=1 for the d=1 panel)

import combination_core_pwai as cf



def main():
    results = cf.get_results()
    for setting in ('same', 'diff'):
        # # cf.plot_metric_two_panels(results, 'PWAI', setting)
        #
        # cf.plot_metric_two_panels(results, 'MSE', setting, logy=True)
        # cf.plot_pwai_decomposition(results, setting)
        #
        # cf.plot_tradeoff(results, setting)
        cf.plot_pareto(results, 'PWAI', setting)
    #     cf.plot_metric_two_panels(results, 'MSE', setting)
    cf.plot_pwai_bars(results)  # PWAI 柱状图
    # cf.summary_table()


if __name__ == '__main__':
    main()


