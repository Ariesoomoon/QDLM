"""
================================================================================
Fig7_pareto_1x3.py -- three Pareto panels in ONE row, shared legend
Paper: Main Figure 7 (Section 6.3)
================================================================================
Panels (fixed m = PARETO_M, one figure per setting and dimension):
  (a) Accuracy-interpretability : x = test MSE (log), y = PWAI
  (b) Accuracy-privacy          : x = test MSE (log), y = MIA AUC
  (c) Privacy-interpretability  : x = PWAI,          y = MIA AUC

One shared legend (single row) below the panels; fonts enlarged relative
to the figure so the row stays readable when inserted full-width.

Plotting-only: reads the shared cache via the core module, no re-run.
OW/OWQD/SW/SWQD are plotted at PWAI = 0 (data-locality factor L = 0).

Run:  python Fig7_pareto_1x3.py            # d = 1 and d = 5
      QDLAR_DIM=5 python Fig7_pareto_1x3.py
      QDLAR_SETTING=same ...                   # default setting: diff
================================================================================
"""

import os
import subprocess
import sys

CORE_MODULE = 'combination_core_pareto'
SETTING = os.environ.get('QDLAR_SETTING', 'diff')




def main():
    import importlib
    import numpy as np
    from matplotlib import pyplot as plt
    from matplotlib.lines import Line2D


    cf = importlib.import_module(CORE_MODULE)

    # 把 METHOD_LABEL 中所有含 'QDLAR' 的地方都改成 'QDLM'
    if hasattr(cf, 'METHOD_LABEL'):
        cf.METHOD_LABEL = {
            k: v.replace('QDLAR', 'QDLM')
            for k, v in cf.METHOD_LABEL.items()
        }

    plt = cf.setup_rcparams()
    results = cf.get_results()

    if cf.PARETO_M not in cf.M_LIST:
        raise SystemExit('PARETO_M=%d is not in M_LIST %s.'
                         % (cf.PARETO_M, cf.M_LIST))
    im = cf.M_LIST.index(cf.PARETO_M)
    mshow = cf.PARETO_M

    # ---------------- data ----------------
    val = {}
    for mtd in cf.METHODS:
        mse = np.nanmean(results[SETTING][mtd]['MSE'][im])
        pwai = np.nanmean(results[SETTING][mtd]['PWAI'][im])
        auc = np.nanmean(results[SETTING][mtd]['AUC'][im])
        if mtd in cf.PWAI_ZERO_METHODS:
            pwai = 0.0                      # L = 0: raw-data pooling
        val[mtd] = dict(mse=mse, pwai=pwai, auc=auc)

    # ---------------- figure ----------------
    fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.0))

    panels = [
        ('mse', 'pwai', True,
         '(a) Accuracy-interpretability Pareto',
         'Test MSE (lower is better, log scale)',
         'CAI (higher is better)'),
        ('mse', 'auc', True,
         '(b) Accuracy-privacy Pareto',
         'Test MSE (lower is better, log scale)',
         'MIA AUC (lower is better)'),
        ('pwai', 'auc', False,
         '(c) Privacy-interpretability Pareto',
         'CAI (higher is better)',
         'MIA AUC (lower is better)'),
    ]

    plotted = []
    for ax, (xk, yk, logx, title, xlab, ylab) in zip(axes, panels):
        xs, ys = [], []
        for mtd in cf.METHODS:
            x, y = val[mtd][xk], val[mtd][yk]
            if np.isnan(x) or np.isnan(y):
                continue
            if mtd not in plotted:
                plotted.append(mtd)
            st = cf.METHOD_STYLE[mtd]
            if st.get('filled', True):
                kw = dict(color=st['color'], edgecolor=st['color'],
                          linewidth=1.0)
            else:
                kw = dict(facecolors='none', edgecolors=st['color'],
                          linewidth=1.9)
            ax.scatter(x, y, s=420, marker=st['marker'],
                       zorder=st['zorder'] + 3, alpha=0.95, **kw)
            xs.append(x); ys.append(y)
        # axes limits
        if logx:
            ax.set_xscale('log')
            ax.set_xlim(min(xs) / 1.8, max(xs) * 2.0)
        else:
            dx = max(max(xs) - min(xs), 0.02)
            ax.set_xlim(min(xs) - 0.18 * dx, max(xs) + 0.22 * dx)
        if yk == 'auc':
            lo = min(min(ys), 0.5)
            hi = max(max(ys), 0.5)
            pad = max(0.18 * (hi - lo), 0.015)
            ax.set_ylim(max(lo - pad, 0.0), min(hi + pad, 1.0))
            ax.axhline(0.5, color='gray', ls=':', lw=1.4, zorder=1)
            ax.annotate('random guess (in MIA)', (ax.get_xlim()[1], 0.5),
                        xytext=(-6, 4), textcoords='offset points',
                        ha='right', fontsize=14, color='black')
        else:
            dy = max(max(ys) - min(ys), 0.02)
            ax.set_ylim(min(min(ys) - 0.15 * dy, 0.0 - 0.05 * dy),
                        max(ys) + 0.18 * dy)
        ax.set_xlabel(xlab, fontsize=17)
        ax.set_ylabel(ylab, fontsize=17)
        ax.set_title(title, fontsize=17, weight='bold', pad=10)
        ax.tick_params(labelsize=14)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.grid(linestyle='--', alpha=0.3)

    # ---------------- shared legend, one row below ----------------
    handles = []
    for mtd in plotted:
        st = cf.METHOD_STYLE[mtd]
        mfc, mec = cf._mk(st)
        handles.append(Line2D(
            [0], [0], marker=st['marker'], color='none',
            markerfacecolor=mfc, markeredgecolor=mec,
            markeredgewidth=1.5, markersize=14,
            label=cf.METHOD_LABEL[mtd]))
    fig.legend(handles=handles, loc='lower center', ncol=len(handles),
               fontsize=15, frameon=False, handletextpad=0.4,
               columnspacing=1.2, bbox_to_anchor=(0.5, 0.0))

    fig.tight_layout(rect=[0, 0.09, 1, 1.0])
    fname = os.path.join(
        cf.PARETO_DIR,
        'Fig_combination_Pareto_1x3_%s_m%d_d%d.pdf'
        % (SETTING, mshow, cf.DIM))
    os.makedirs(cf.PARETO_DIR, exist_ok=True)
    fig.savefig(fname, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.15)
    plt.show()
    plt.close(fig)
    print('Saved: %s' % fname)




if __name__ == '__main__':
    if len(sys.argv) > 1:                       # child mode: one dimension
        os.environ['QDLAR_DIM'] = sys.argv[1]   # must precede the core import
        main()
    elif os.environ.get('QDLAR_DIM'):           # dimension chosen externally
        main()
    else:                                       # parent: run d = 1 and d = 5
        for d in ('1', '5'):
            print('=' * 20 + ' d = %s ' % d + '=' * 20)
            env = dict(os.environ, QDLAR_DIM=d)
            subprocess.run([sys.executable, os.path.abspath(__file__), d],
                           check=True, env=env)
