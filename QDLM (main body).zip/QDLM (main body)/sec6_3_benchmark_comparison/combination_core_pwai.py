# Paper: Appendix Figure 4a (CAI/PWAI bars, Section C.4) - core module (PWAI version).
# Formerly: combination_foresting_core_gpu_new_final2.py
# Run from this folder (one level below the repo root); caches live in ../Result_data_for_combination/.


import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
import math
import random
import time
import numpy as np
from sklearn.model_selection import KFold
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor

# ----------------------------------------------------------------------------
# CPU backend (NumPy).  This version does not use PyTorch / GPU at all.
# ----------------------------------------------------------------------------
_DEV = None
print('[backend] pairwise/kernel/linear-algebra device: NumPy (CPU)')

# --- parallel tuning ---------------------------------------------------------
# Per-party CV tuning (KRR / DT / RF / hybrid h & k) is independent across
# parties, so it is farmed out to worker PROCESSES; deterministic
# per-party results -> identical caches.
#   QDLAR_JOBS=n     worker processes for tuning (default -1 = all cores)
#   QDLAR_RF_JOBS=n  threads per RandomForestRegressor OUTSIDE the parallel
#                    tuning region (inside workers it is forced to 1)
from joblib import Parallel, delayed

# Online platforms pipe stdout -> Python block-buffers it and nothing shows
# for hours.  Line buffering makes every print appear immediately.
try:
    sys.stdout.reconfigure(line_buffering=True)
except Exception:
    pass


def _fmt_dur(sec):
    """Compact duration: 45 s / 12.3 min / 2.4 h."""
    if sec < 90:
        return '%.0f s' % sec
    if sec < 5400:
        return '%.1f min' % (sec / 60)
    return '%.2f h' % (sec / 3600)

N_JOBS = int(os.environ.get('QDLAR_JOBS', '-1'))
RF_NJOBS = int(os.environ.get('QDLAR_RF_JOBS', '-1'))  # worker procs get 1 via env
print('[backend] tuning parallelism: %s worker process(es)'
      % ('all-core' if N_JOBS == -1 else N_JOBS))


def _parallel_tune(fn, items):
    """Run fn(item) for every item, in parallel worker processes when
    QDLAR_JOBS != 1.  Workers re-import this module with QDLAR_RF_JOBS=1
    (no nested thread pools inside workers)."""
    if N_JOBS == 1 or len(items) <= 1:
        return [fn(it) for it in items]
    saved = os.environ.get('QDLAR_RF_JOBS')
    os.environ['QDLAR_RF_JOBS'] = '1'
    try:
        return Parallel(n_jobs=N_JOBS)(
            delayed(fn)(it) for it in items)
    finally:
        if saved is None:
            os.environ.pop('QDLAR_RF_JOBS', None)
        else:
            os.environ['QDLAR_RF_JOBS'] = saved



def _cdist(A, B):
    """(len(A), len(B)) Euclidean distances."""
    A = np.asarray(A, dtype=np.float64)
    B = np.asarray(B, dtype=np.float64)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    if B.ndim == 1:
        B = B.reshape(-1, 1)
    return np.linalg.norm(A[:, None, :] - B[None, :, :], axis=2)


def _solve(A, b):
    """Solve A x = b (float64)."""
    return np.linalg.solve(A, b)


def _knn_select(dn, k):
    """Indices (T, k) of the k nearest neighbours per row + the k-th
    smallest distance per row (T,)."""
    srt = np.argsort(dn, axis=1)
    return srt[:, :k], np.sort(dn, axis=1)[:, k - 1]


from common.Function_same_block import (generate_data, create_y_g1, create_y_g2,
                                 mblocks, global_parameter_h)

# ----------------------------------------------------------------------------
# Configuration (env-overridable)
# ----------------------------------------------------------------------------
RESULT_DIR = os.environ.get('QDLAR_RESULT_DIR', os.path.dirname(os.getcwd()) + '/Result_data_for_combination')
FIG_DIR = os.environ.get('QDLAR_FIG_DIR', os.path.dirname(os.getcwd()) + '/Result_figure/sec6_3')
os.makedirs(RESULT_DIR, exist_ok=True)
os.makedirs(FIG_DIR, exist_ok=True)

DIM = int(os.environ.get('QDLAR_DIM', '1'))          # overridden by drivers
TRAIN_N = int(os.environ.get('QDLAR_TRAIN_N', '2000'))
TEST_N = int(os.environ.get('QDLAR_TEST_N', '1000'))
VAL_N = int(os.environ.get('QDLAR_VAL_N', '2000'))   # for OW / BS weights
N_TRIALS = int(os.environ.get('QDLAR_N_TRIALS', '20'))
N_QUERY = int(os.environ.get('QDLAR_N_QUERY', '200'))
CV_FOLD = 5
M_LIST = [int(s) for s in os.environ.get(
    'QDLAR_M_LIST', '5,10,20,30,40,50,60,70,80,90,100').split(',')]
M_FIXED = int(os.environ.get('QDLAR_M_FIXED', '10'))
FORCE_RERUN = os.environ.get('QDLAR_RERUN', '') == '1'

# PARAM_CACHE = os.path.join(
#     RESULT_DIR, 'combination_foresting_gpu_new_params_d%d.npy' % DIM)
# RESULT_CACHE = os.path.join(
#     RESULT_DIR, 'combination_foresting_gpu_new_results_d%d.npy' % DIM)


PARAM_CACHE = os.path.join(
    RESULT_DIR, 'combination_foresting_gpu_new_params_d%d.npy' % DIM)
RESULT_CACHE = os.path.join(
    RESULT_DIR, 'combination_foresting_gpu_new_results_d%d_pwai0.npy' % DIM)




# method registry ------------------------------------------------------------
METHOD_EW, METHOD_EWQD = 'EW', 'EWQD'
METHOD_OW, METHOD_OWQD = 'OW', 'OWQD'
METHOD_BS, METHOD_BSQD = 'BS', 'BSQD'
METHOD_WA, METHOD_WAQD = 'WA', 'WAQD'
METHOD_QDKRR, METHOD_QDDT, METHOD_QDRF = 'QDKRR', 'QDDT', 'QDRF'
METHOD_QDLR, METHOD_QD1NN, METHOD_FL = 'QDLR', 'QD1NN', 'FL'

METHODS = [METHOD_EW, METHOD_EWQD, METHOD_OW, METHOD_OWQD,
           METHOD_BS, METHOD_BSQD, METHOD_WA, METHOD_WAQD, METHOD_FL]
# panel (a): the four aggregation rules WITHOUT qualification
FAM_PLAIN = [METHOD_EW, METHOD_OW, METHOD_BS, METHOD_WA, METHOD_FL]
# panel (b): the SAME four rules WITH qualification (WAQD = full QDLAR)
FAM_QUAL = [METHOD_EWQD, METHOD_OWQD, METHOD_BSQD, METHOD_WAQD, METHOD_FL]
QD_SET = {METHOD_EWQD, METHOD_OWQD, METHOD_BSQD, METHOD_WAQD}

METHOD_LABEL = {METHOD_EW: 'EW', METHOD_EWQD: 'EWQD',
                METHOD_OW: 'OW', METHOD_OWQD: 'OWQD',
                # METHOD_BS: 'BS', METHOD_BSQD: 'BSQD',
METHOD_BS: 'SW', METHOD_BSQD: 'SWQD',
                METHOD_WA: 'WA', METHOD_WAQD: 'WAQD (QDLAR)',
                METHOD_FL: 'FL'}
# one colour per aggregation rule; WITHOUT qualification = open (hollow)
# marker + solid line, WITH qualification = filled marker + dashed line
# Tol bright palette -- one colour per aggregation rule; open marker = no
# qualification, filled marker (same colour) = with qualification.
METHOD_STYLE = {
    METHOD_EW:   dict(color='#4477AA', marker='s', lw=2.2, ms=8.0, zorder=4,
                      filled=False, ls='-'),
    METHOD_EWQD: dict(color='#4477AA', marker='s', lw=2.2, ms=8.0, zorder=4,
                      filled=True, ls='--'),
    METHOD_OW:   dict(color='#CC6677', marker='^', lw=2.2, ms=8.5, zorder=4,
                      filled=False, ls='-'),
    METHOD_OWQD: dict(color='#CC6677', marker='^', lw=2.2, ms=8.5, zorder=4,
                      filled=True, ls='--'),
    METHOD_BS:   dict(color='#228833', marker='v', lw=2.2, ms=8.5, zorder=4,
                      filled=False, ls='-'),
    METHOD_BSQD: dict(color='#228833', marker='v', lw=2.2, ms=8.5, zorder=4,
                      filled=True, ls='--'),
    METHOD_WA:   dict(color='#EE7733', marker='o', lw=3.0, ms=8.5, zorder=5,
                      filled=False, ls='-'),
    METHOD_WAQD: dict(color='#EE7733', marker='o', lw=3.0, ms=8.5, zorder=6,
                      filled=True, ls='--'),
    METHOD_FL:   dict(color='#AA3377', marker='h', lw=2.0, ms=9.0, zorder=2,
                      filled=True, ls='--'),
}


def _mk(st):
    """Marker face/edge colours from the style's 'filled' flag."""
    if st.get('filled', True):
        return st['color'], st['color']
    return 'none', st['color']

# tuning grids (from the uploaded parameter_d{1,5}_{krr,rf,Rtree}.py)
KRR_LAMBDAS = [0.00001 + 0.0005 * i for i in range(10)]
DT_DEPTHS = [2 * i for i in range(1, 21)]              # 2,4,...,40
RF_TREES = [2 * i for i in range(1, 31)]               # 2,4,...,60
RF_MAX_DEPTH = 5                                        # as Predictedrf
BOOST_MAX_DEPTH = 5
DEPTH_CAP, TREES_CAP = 32, 400                          # caps after log mech.

ALGO_NAMES = {1: 'Gaussian', 2: 'Epanechnikov', 3: 'Naive', 4: 'KNN'}


# ----------------------------------------------------------------------------
# Data (bit-exact reproduction of the paper's toy simulation)
# ----------------------------------------------------------------------------
def load_toy_data(trial):
    """np.random.seed(trial) + generate_data -- identical across all
    scripts, so every method sees exactly the same blocks."""
    np.random.seed(trial)
    train_shape = TRAIN_N if DIM == 1 else (TRAIN_N, DIM)
    test_shape = TEST_N if DIM == 1 else (TEST_N, DIM)
    X_tr, y_tr, X_te, y_te = generate_data(train_shape, test_shape, DIM)
    if DIM == 1:
        X_tr = X_tr.reshape(-1, 1)
        X_te = X_te.reshape(-1, 1)
    return X_tr, y_tr, X_te, y_te


def make_val_data(trial):
    """Labeled validation set (same DGP, with noise) for estimating the
    OW / BS combination weights -- avoids any use of the test labels.
    Drawn from the SAME numpy stream right after train/test, so the
    bit-exactness of load_toy_data() is untouched."""
    np.random.seed(trial)
    train_shape = TRAIN_N if DIM == 1 else (TRAIN_N, DIM)
    test_shape = TEST_N if DIM == 1 else (TEST_N, DIM)
    _ = generate_data(train_shape, test_shape, DIM)      # advance the stream
    if DIM == 1:
        X_val = np.random.uniform(0.0, 1.0, VAL_N).reshape(-1, 1)
        y_val = create_y_g1(X_val.ravel()) \
            + np.random.normal(0, 0.1, VAL_N)
    else:
        X_val = np.random.uniform(0.0, 1.0, (VAL_N, DIM))
        y_val = create_y_g2(X_val) + np.random.normal(0, 0.1, VAL_N)
    return X_val, y_val


def mblocks_diff(x_tra, m):
    """Heterogeneous partition, IDENTICAL to Function_diff_block.mblocks_diff
    (np.random.seed(0) inside): the first m-1 blocks have random sizes in
    [0.8*N/m, N/m), the last block takes the remainder."""
    np.random.seed(0)
    blocks = {}
    start, endlast = 0, 0
    for i in range(m - 1):
        b_size = int(len(x_tra) / m)
        end = np.random.randint(int(b_size * 0.8), b_size)
        end = end + endlast
        blocks[i] = [j for j in range(start, end, 1)]
        endlast, start = end, end
    blocks[i + 1] = [j for j in range(end, len(x_tra), 1)]
    return blocks


def get_assignments(m):
    """Same as hybrid_algorithm: random.seed(0), then randint(1,4) per block.
    1 = Gaussian, 2 = Epanechnikov, 3 = Naive, 4 = KNN."""
    random.seed(0)
    return [random.randint(1, 4) for _ in range(m)]


def get_blocks(X, y, m, setting):
    """Return a list of (b_x, b_y) party data sets."""
    if setting == 'same':
        bdf = mblocks(X, y, m)
        return [(np.array(bdf.loc[i]['block_x']).reshape(-1, DIM),
                 np.array(bdf.loc[i]['block_y'])) for i in range(m)]
    idx = mblocks_diff(X, m)
    return [(X[idx[i]], y[idx[i]]) for i in range(m)]


def block_sizes(blocks):
    return np.array([len(by) for _, by in blocks], dtype=float)


# ----------------------------------------------------------------------------
# 5-fold-CV parameter tuning (per party) + cache
# ----------------------------------------------------------------------------
def _kf():
    # seeded for full reproducibility (the uploaded code used unseeded
    # KFold(shuffle=True); seeding only makes the selection repeatable)
    return KFold(n_splits=CV_FOLD, shuffle=True, random_state=0)


def tune_local_h(b_x, b_y):
    """Kernel bandwidth by the paper's bisection 5-fold CV
    (global_parameter_h of Function_same_block, Gaussian-based CV error,
    exactly the procedure behind the stored local_h_* parameters)."""
    return float(global_parameter_h(b_x, b_y, CV_FOLD, DIM))


def _knn_mse(b_x, b_y, X_q, y_q, k):
    k = max(1, min(int(k), len(b_y)))
    dn = _cdist(X_q, b_x)
    idx, _ = _knn_select(dn, k)
    fit = b_y[idx].mean(axis=1)
    return float(np.mean((fit - y_q) ** 2))


def tune_local_k(b_x, b_y):
    """k of the KNN-LAR variant by 5-fold CV bisection on the block
    (adaptive branch of opt_local_k_d1/d5: p1 = 0.25 n, p2 = 0.75 n)."""
    n = len(b_y)
    p1, p2 = max(1, int(0.25 * n)), max(2, int(0.75 * n))
    cv_compares, k_opts = [], []
    for _ in range(5):
        cv = {}
        for p in {max(1, p1), max(1, p2)}:
            errs = []
            for tr, te in _kf().split(b_x):
                errs.append(_knn_mse(b_x[tr], b_y[tr], b_x[te], b_y[te], p))
            cv[p] = sum(errs) / CV_FOLD
        if len(cv) == 1:
            # small blocks (large m): the bisection bracket has converged
            (p_only, c_only), = cv.items()
            cv_compares.append(c_only); k_opts.append(p_only)
            break
        (p_lo, c_lo), (p_hi, c_hi) = sorted(cv.items())
        if c_lo <= c_hi:
            cv_compares.append(c_lo); k_opts.append(p_lo)
            p1, p2 = max(1, p_lo // 2), max(1, (3 * p_lo) // 2)
        else:
            cv_compares.append(c_hi); k_opts.append(p_hi)
            p1, p2 = max(1, p_hi - p_lo // 2), max(1, p_hi + p_lo // 2)
    return float(k_opts[cv_compares.index(min(cv_compares))])


# ---- KRR (kernels copied from Function_same_block_linshi_rfd5.py) ----------
def _krr_kernel(A, B):
    """d = 1: K(x,y) = min(x,y) + 1;  d = 5: K(x,y) = h3(||x-y||) with
    h3(r) = (1-r)^4 (4r+1) on [0,1] (the user's kernel_d1 / kernel_d3)."""
    if DIM == 1:
        return np.minimum(A.ravel()[:, None], B.ravel()[None, :]) + 1.0
    dis = _cdist(A, B)
    out = np.zeros_like(dis)
    msk = dis <= 1.0
    r = dis[msk]
    out[msk] = (1.0 - r) ** 4 * (4.0 * r + 1.0)
    return out


def _krr_fit_alpha(b_x, b_y, lam):
    n = len(b_y)
    K = _krr_kernel(b_x, b_x)
    A = K + n * lam * np.eye(n)
    try:
        alpha = _solve(A, b_y)
    except np.linalg.LinAlgError:
        alpha = np.linalg.lstsq(A + 1e-10 * np.eye(n), b_y,
                                rcond=None)[0]
    return alpha


def _krr_predict(b_x, alpha, X_q):
    return _krr_kernel(X_q, b_x) @ alpha


def tune_krr(b_x, b_y):
    best_lam, best_err = KRR_LAMBDAS[0], np.inf
    for lam in KRR_LAMBDAS:
        errs = []
        for tr, te in _kf().split(b_x):
            alpha = _krr_fit_alpha(b_x[tr], b_y[tr], lam)
            errs.append(np.mean((_krr_predict(b_x[tr], alpha,
                                              b_x[te]) - b_y[te]) ** 2))
        err = sum(errs) / CV_FOLD
        if err < best_err:
            best_err, best_lam = err, lam
    return float(best_lam)


def tune_dt(b_x, b_y):
    best_dep, best_err = DT_DEPTHS[0], np.inf
    for dep in DT_DEPTHS:
        errs = []
        for tr, te in _kf().split(b_x):
            mdl = DecisionTreeRegressor(max_depth=dep, random_state=0)
            mdl.fit(b_x[tr], b_y[tr])
            errs.append(np.mean((mdl.predict(b_x[te]) - b_y[te]) ** 2))
        err = sum(errs) / CV_FOLD
        if err < best_err:
            best_err, best_dep = err, dep
    return int(best_dep)


def tune_rf(b_x, b_y):
    """n_estimators by 5-fold CV with warm_start: the forest is grown ONCE
    per fold up to max(RF_TREES) and every grid value is evaluated on the
    way (much cheaper than refitting)."""
    grid = sorted(RF_TREES)
    err_acc = {t: [] for t in grid}
    for tr, te in _kf().split(b_x):
        mdl = RandomForestRegressor(n_estimators=grid[0],
                                    max_depth=RF_MAX_DEPTH, warm_start=True,
                                    random_state=0, n_jobs=RF_NJOBS)
        for t in grid:
            mdl.set_params(n_estimators=t)
            mdl.fit(b_x[tr], b_y[tr])        # only adds the missing trees
            err_acc[t].append(
                np.mean((mdl.predict(b_x[te]) - b_y[te]) ** 2))
    best_t = min(grid, key=lambda t: sum(err_acc[t]) / CV_FOLD)
    return int(best_t)


# ---- parameter cache (tuned once, saved, reused by every later run) --------
def _param_fingerprint():
    """Tuned parameters depend on the data (DIM, TRAIN_N) and the CV setup;
    a cache produced under any other configuration is invalid."""
    return {'DIM': DIM, 'TRAIN_N': TRAIN_N, 'CV_FOLD': CV_FOLD}


def load_param_cache():
    """Tuned parameters saved by an earlier run (same configuration)."""
    if not os.path.exists(PARAM_CACHE):
        return {}
    pack = np.load(PARAM_CACHE, allow_pickle=True).tolist()
    if not isinstance(pack, dict) or 'params' not in pack:
        return {}                       # plain-dict cache of older versions
    if pack.get('fingerprint') != _param_fingerprint():
        print('Saved parameters match a different configuration -- '
              're-tuning.')
        return {}
    print('Loaded saved parameters from %s (no re-tuning needed).'
          % PARAM_CACHE)
    return pack['params']


def save_param_cache(cache):
    np.save(PARAM_CACHE, {'fingerprint': _param_fingerprint(),
                          'params': cache})


def get_hybrid_params(trial, m, setting, blocks, assigns, cache):
    """Per-block LAR parameters {algo: array of length m}, tuned per party
    by 5-fold CV and cached to disk (no external parameter files)."""
    key = 'hybrid_%s' % setting
    sub = cache.setdefault(key, {}).setdefault(trial, {})
    if m in sub:
        return sub[m]
    t0 = time.time()
    params = {a: np.zeros(m) for a in (1, 2, 3, 4)}

    def _tune_party(j):
        b_x, b_y = blocks[j]
        return (tune_local_k if assigns[j] == 4 else tune_local_h)(b_x, b_y)

    vals = _parallel_tune(_tune_party, list(range(m)))
    for j, v in enumerate(vals):
        params[assigns[j]][j] = v
    if trial == 0:
        print('    [params] hybrid/%s m=%d: per-party 5-fold CV tuning '
              '(%.1f s for trial 0; later trials tune silently)' %
              (setting, m, time.time() - t0))
    sub[m] = params
    save_param_cache(cache)
    return params


def get_qd_params(method, trial, m, setting, blocks, cache):
    """Per-block parameters of a QD local algorithm (5-fold CV, cached)."""
    tuner = {METHOD_QDKRR: tune_krr, METHOD_QDDT: tune_dt,
             METHOD_QDRF: tune_rf}[method]
    key = '%s_%s' % (method, setting)
    sub = cache.setdefault(key, {}).setdefault(trial, {})
    if m in sub:
        return sub[m]
    t0 = time.time()

    def _tune_party(block):
        return tuner(block[0], block[1])

    sub[m] = np.array(_parallel_tune(_tune_party, blocks))
    if trial == 0:
        print('    [params] %s/%s m=%d: per-party 5-fold CV tuning '
              '(%.1f s for trial 0; later trials tune silently)' %
              (method, setting, m, time.time() - t0))
    save_param_cache(cache)
    return sub[m]


# ----------------------------------------------------------------------------
# Local estimates: per-party predictions / attribution sets / localization
# ----------------------------------------------------------------------------
def lar_block_output(X_q, b_x, b_y, assign, param, m, log_mech):
    """One hybrid-LAR party on all queries (replicates the kernels, the
    logarithmic mechanism h -> min(1, h^LOG), k -> ceil(k^LOG/m), and the
    qualification rule of Function_same_block.hybrid_algorithm).

    Returns fit (T,), attr (T,) = |A_j(x)|, h_loc (T,) = h_j(x) in (0,1]."""
    N = TRAIN_N
    n = len(b_y)
    T = len(X_q)
    LOG = math.log(N, n)                     # logarithmic operator
    if assign == 1:                                   # Gaussian, s = 2
        h = param ** LOG if log_mech else param
        h = min(1.0, h)
        dn = _cdist(X_q, b_x) ** 2 / h ** 2
        w = np.exp(-dn)
        attr = np.full(T, float(n))                 # all weights > 0
        h_loc = np.full(T, h)
    elif assign == 2:                                 # Epanechnikov
        h = param ** LOG if log_mech else param
        h = min(1.0, h)
        dn = _cdist(X_q, b_x) ** 2 / h ** 2
        w = np.where(1 - dn > 0, 1 - dn, 0.0)
        attr = np.maximum((w > 0).sum(axis=1).astype(float), 1.0)
        h_loc = np.full(T, h)
    elif assign == 3:                                 # naive / cube
        h = param ** LOG if log_mech else param
        h = min(1.0, h)
        dn = _cdist(X_q, b_x) / h
        w = (dn <= 1).astype(float)
        attr = np.maximum((w > 0).sum(axis=1).astype(float), 1.0)
        h_loc = np.full(T, h)
    else:                                             # KNN
        k = math.ceil(param ** LOG / m) if log_mech else int(round(param))
        k = max(1, min(k, n))
        dn = _cdist(X_q, b_x)
        idx, knn_radius = _knn_select(dn, k)
        w = np.zeros((T, n))
        np.put_along_axis(w, idx, 1.0, axis=1)
        attr = np.full(T, float(k))
        # k-NN radius as h_j(x), clipped to (0,1] (Definition 3 assumes a
        # normalized localization parameter)
        h_loc = np.clip(knn_radius, 1e-12, 1.0)
    wsum = w.sum(axis=1)
    fit = np.divide(w @ b_y, wsum, out=np.zeros(T), where=wsum > 0)
    return fit, attr, np.clip(h_loc, 1e-12, 1.0)


def hybrid_lar_all(X_q, blocks, assigns, params, m, log_mech):
    """FIT (T,m), ATTR (T,m), HLOC (T,m) for the hybrid LAR parties."""
    T = len(X_q)
    FIT = np.zeros((T, m))
    ATTR = np.ones((T, m))
    HLOC = np.ones((T, m))
    for j, (b_x, b_y) in enumerate(blocks):
        a = assigns[j]
        FIT[:, j], ATTR[:, j], HLOC[:, j] = lar_block_output(
            X_q, b_x, b_y, a, params[a][j], m, log_mech)
    return FIT, ATTR, HLOC


# ---- decision tree / random forest attribution sets & localization ---------
def _tree_leaf_bounds(tree):
    """Axis-aligned bounding box of every leaf (walk the tree once).
    Returns arrays leaf_ids, lo (n_leaf, d), hi (n_leaf, d)."""
    t = tree.tree_
    lo = np.zeros((t.node_count, t.n_features))
    hi = np.ones((t.node_count, t.n_features))
    stack = [0]
    order = []
    while stack:                                 # preorder, parents first
        v = stack.pop()
        order.append(v)
        l, r = t.children_left[v], t.children_right[v]
        if l == r:
            continue
        f, thr = t.feature[v], t.threshold[v]
        lo[l], hi[l] = lo[v].copy(), hi[v].copy()
        hi[l, f] = min(hi[l, f], thr)
        lo[r], hi[r] = lo[v].copy(), hi[v].copy()
        lo[r, f] = max(lo[r, f], thr)
        stack += [l, r]
    leaves = np.array([v for v in order if t.children_left[v]
                       == t.children_right[v]])
    return leaves, lo[leaves], hi[leaves], t.n_node_samples[leaves]


def _tree_attr_hloc(mdl, X_q):
    """For one fitted tree: |A_j(x)| = leaf size; h_j(x) = maximal side
    length of the leaf box (inputs lie in [0,1]^d, so sides are already
    normalized)."""
    leaves, lo, hi, ns = _tree_leaf_bounds(mdl)
    pos = {leaf: i for i, leaf in enumerate(leaves)}
    leaf_of = mdl.apply(X_q)
    rows = np.array([pos[l] for l in leaf_of])
    attr = ns[rows].astype(float)
    h_loc = (hi[rows] - lo[rows]).max(axis=1)
    return np.maximum(attr, 1.0), np.clip(h_loc, 1e-12, 1.0)


def _rf_attr_hloc(mdl, X_q):
    attrs, hlocs = [], []
    for est in mdl.estimators_:
        a, h = _tree_attr_hloc(est, X_q)
        attrs.append(a); hlocs.append(h)
    return np.mean(attrs, axis=0), np.clip(np.mean(hlocs, axis=0),
                                           1e-12, 1.0)


# ---- QD local algorithms ----------------------------------------------------
def qd_all(X_q, blocks, method, params, m, rows=None):
    """FIT (T,m), ATTR (T,m), HLOC (T,m) for one homogeneous QD algorithm
    (WITH logarithm mechanism where a localization parameter exists).
    ATTR/HLOC are only evaluated at the row indices `rows` (the SAD/ALG
    query subset); the remaining rows are placeholders and never used."""
    N = TRAIN_N
    T = len(X_q)
    FIT = np.zeros((T, m))
    ATTR = np.ones((T, m))
    HLOC = np.ones((T, m))
    X_a = X_q if rows is None else X_q[rows]
    ra = np.arange(T) if rows is None else rows
    for j, (b_x, b_y) in enumerate(blocks):
        n = len(b_y)
        LOG = math.log(N, n)
        if method == METHOD_QDKRR:
            lam = params[j] ** LOG               # logarithmic mechanism
            alpha = _krr_fit_alpha(b_x, b_y, lam)
            FIT[:, j] = _krr_predict(b_x, alpha, X_q)
            if DIM == 1:      # min-kernel > 0 everywhere
                ATTR[ra, j] = float(n)
            else:             # h3 support: ||x - x_i|| < 1
                dn = _cdist(X_a, b_x)
                ATTR[ra, j] = np.maximum((dn < 1.0).sum(axis=1), 1.0)
            HLOC[ra, j] = 1.0  # global (dense) kernel: no localization
        elif method == METHOD_QDDT:
            dep = int(math.ceil(params[j] ** LOG))
            dep = max(1, min(dep, DEPTH_CAP))
            mdl = DecisionTreeRegressor(max_depth=dep, random_state=0)
            mdl.fit(b_x, b_y)
            FIT[:, j] = mdl.predict(X_q)
            ATTR[ra, j], HLOC[ra, j] = _tree_attr_hloc(mdl, X_a)
        elif method == METHOD_QDRF:
            t = int(math.ceil(params[j] ** LOG))
            t = max(1, min(t, TREES_CAP))
            mdl = RandomForestRegressor(n_estimators=t,
                                        max_depth=RF_MAX_DEPTH,
                                        random_state=0, n_jobs=RF_NJOBS)
            mdl.fit(b_x, b_y)
            FIT[:, j] = mdl.predict(X_q)
            ATTR[ra, j], HLOC[ra, j] = _rf_attr_hloc(mdl, X_a)
        elif method == METHOD_QDLR:
            Phi = np.hstack([b_x, np.ones((n, 1))])
            beta = np.linalg.lstsq(Phi, b_y, rcond=None)[0]
            FIT[:, j] = np.hstack([X_q, np.ones((T, 1))]) @ beta
            ATTR[ra, j] = float(n)              # every sample enters OLS
            HLOC[ra, j] = 1.0                   # global model
        elif method == METHOD_QD1NN:
            dn = _cdist(X_q, b_x)
            nn = np.argmin(dn, axis=1)
            FIT[:, j] = b_y[nn]
            ATTR[ra, j] = 1.0
            da = dn if rows is None else _cdist(X_a, b_x)
            HLOC[ra, j] = np.clip(da.min(axis=1), 1e-12, 1.0)
    return FIT, ATTR, HLOC


# ---- classic federated learning (gradient passing) --------------------------
def fl_federated_linear(blocks, X_q, rounds=300):
    """FedAvg/FedSGD with ONE shared model (linear regression + intercept):
    every round each party computes the FULL-BATCH gradient of the MSE on
    its own data and sends the GRADIENT (never a prediction); the server
    averages gradients weighted by |D_j| and updates the global model.
    Step size 1/L with L the Lipschitz constant of the global objective, so
    the iteration deterministically converges to the pooled OLS solution.
    Per-agent predictions are never observable -> PWAI visibility V = 0."""
    N = sum(len(by) for _, by in blocks)
    p = DIM + 1
    G = np.zeros((p, p))                        # global (1/N) Phi'Phi
    for b_x, _ in blocks:
        Phi = np.hstack([b_x, np.ones((len(b_x), 1))])
        G += (Phi.T @ Phi) / N
    L = 2.0 * float(np.linalg.eigvalsh(G).max())
    lr = 1.0 / max(L, 1e-12)
    w = np.zeros(p)
    for _ in range(rounds):
        grad = np.zeros(p)
        for b_x, b_y in blocks:
            Phi = np.hstack([b_x, np.ones((len(b_x), 1))])
            grad += (Phi.T @ (Phi @ w - b_y)) * (2.0 / N)
        w -= lr * grad
    return np.hstack([X_q, np.ones((len(X_q), 1))]) @ w


# ----------------------------------------------------------------------------
# Combination weights: OW (optimal weights) and BS (Blanc-Setzer shrinkage)
# ----------------------------------------------------------------------------
def _standardise_errors(E):
    """Cross-sectional standardisation (Blanc & Setzer 2020, Section 4.2):
    for every validation point, standardise the m parties' errors across
    parties.  Identical to the uploaded blanc_setzer.py."""
    E_std = np.zeros_like(E)
    for t in range(E.shape[0]):
        row = E[t, :]
        mu = row.mean()
        sigma = row.std(ddof=1)
        E_std[t, :] = (row - mu) / sigma if sigma > 1e-12 else row - mu
    return E_std


BS_STANDARDISE = os.environ.get('QDLAR_BS_STANDARDISE', 'columns')


def ow_bs_weights(E_val):
    """E_val: (n_val, m) SIGNED validation errors f_j(x_v) - y_v of the m
    parties.  Follows the uploaded blanc_setzer.py implementation of
    Blanc & Setzer (2020):
      Theorem 3    Sigma = E'E/n with ridge 1e-10*(tr/m)*I,
                   w_OW = S^{-1} iota / (iota' S^{-1} iota),
                   s1 = (iota' S iota)/k^2, s2 = 1/(iota' S^{-1} iota),
                   corr = n/(n-k+1),
                   B = max(0, s1 - corr*s2),  V = corr*(k-1)/(n-k)*s2,
                   lambda_opt = V/(B+V),
      Eq. (3)      w_BS = (lambda/k) iota + (1-lambda) w_OW.
    Degenerate case n_val <= m: pure equal weights (lambda = 1), exactly
    as in the uploaded code.

    Error standardisation (env QDLAR_BS_STANDARDISE):
      * 'columns' (DEFAULT): de-mean every party's error series (the
        paper's mean-bias adjustment).  Appropriate here because all
        parties predict the SAME single target in the same units.
      * 'rows': the verbatim Section-4.2 cross-sectional standardisation
        of the uploaded blanc_setzer.py.  NOTE: with a single shared
        target this forces Sigma @ iota = 0 exactly, so w_OW collapses to
        the equal weights (row means are zero by construction) -- the
        uploaded KGD implementation therefore behaves as EW; only use
        'rows' to reproduce that behaviour."""
    k = E_val.shape[1]
    if BS_STANDARDISE == 'rows':
        E = _standardise_errors(E_val)
    else:
        E = E_val - E_val.mean(axis=0, keepdims=True)
    n = E.shape[0]
    if n <= k:                                  # degenerate: equal weights
        w_ew = np.ones(k) / k
        return w_ew, w_ew.copy(), 1.0
    S = (E.T @ E) / n
    tr_S = np.trace(S)
    if tr_S > 0:
        S = S + 1e-10 * (tr_S / k) * np.eye(k)
    iota = np.ones(k)
    try:
        Si = np.linalg.inv(S)
    except np.linalg.LinAlgError:
        Si = np.linalg.pinv(S)
    den = float(iota @ Si @ iota)
    den = den if abs(den) > 1e-18 else 1e-18
    w_ow = (Si @ iota) / den
    s1 = float(iota @ S @ iota) / (k * k)
    s2 = 1.0 / den
    corr = n / max(n - k + 1, 1)
    B = max(0.0, s1 - corr * s2)
    V = corr * (k - 1) / max(n - k, 1) * s2
    lam = float(V / (B + V + 1e-15))
    w_bs = lam / k * iota + (1.0 - lam) * w_ow
    return w_ow, w_bs, lam


def positive_part(w):
    """Projection of a (possibly signed) weight vector onto the simplex of
    attribution shares: negative 'contributions' carry no attribution
    meaning, so they are clipped before the entropy of Definition 1."""
    wc = np.clip(np.asarray(w, dtype=float), 0.0, None)
    s = wc.sum()
    return wc / s if s > 0 else np.full_like(wc, 1.0 / len(wc))


# ----------------------------------------------------------------------------
# Aggregation rules (final predictions, for the MSE record)
# ----------------------------------------------------------------------------
def aggregate(fit_mat, method, sizes, active, w=None):
    """fit_mat (T,m); active (T,m) bool; sizes (m,); w (m,) for OW/BS."""
    T, m = fit_mat.shape
    if method == METHOD_EW:
        return fit_mat.mean(axis=1)
    if method in (METHOD_OW, METHOD_BS):
        return fit_mat @ w
    if method == METHOD_EWQD:                   # equal weights over qualified
        ww = active.astype(float)
        den = ww.sum(axis=1)
        out = np.divide((fit_mat * ww).sum(axis=1), den,
                        out=np.full(T, np.nan), where=den > 0)
        fb = fit_mat.mean(axis=1)
        return np.where(den > 0, out, fb)
    if method in (METHOD_OWQD, METHOD_BSQD):    # OW/BS weights over qualified
        ww = np.clip(w, 0.0, None)[None, :] * active
        den = ww.sum(axis=1)
        out = np.divide((fit_mat * ww).sum(axis=1), den,
                        out=np.full(T, np.nan), where=den > 0)
        fb = fit_mat.mean(axis=1)
        return np.where(den > 0, out, fb)
    # WA / WAQD: contribution weights |D_j| over (qualified) agents
    ww = sizes[None, :] * active
    den = ww.sum(axis=1)
    out = np.divide((fit_mat * ww).sum(axis=1), den,
                    out=np.full(T, np.nan), where=den > 0)
    fb = fit_mat.mean(axis=1)                   # fallback if none qualified
    return np.where(den > 0, out, fb)


# ----------------------------------------------------------------------------
# Metrics (Definitions 1-3)
# ----------------------------------------------------------------------------
def pwai_per_query(method, sizes, qual, w=None):
    """PWAI(x) = V * D(x) * P(x) per query (Definition 1 of the paper).
      V = 0 for FL (only gradients are exposed);
      qual (T,m): the QUALIFIED set Q(x) = {j: |f_j(x)| >= 1/N}; all
         methods submit the same local predictions, so Q(x) is shared;
      w: the method's base aggregation weights over ALL m parties
         (EW: uniform; OW/BS: validation-estimated, negative part clipped;
         WA: |D_j| shares when w is None).
      Effective weight vector w(x) over all m parties (non-contributors
      carry w_j = 0): non-QD methods aggregate all m parties (w(x) = w);
      QD variants aggregate only over Q(x) (w restricted to Q(x) and
      re-normalised; if Q(x) is empty the fall-back equal mean is used,
      exactly as in aggregate()).
        D(x) = 1 - H(w(x))/log m*(x),  H(w) = -sum_j w_j log w_j, with
          m*(x) = #{j : w_j(x) > 0} the ACTIVATED participants at x
          (all m for non-QD methods, |Q(x)| for the QD variants);
        P(x) = sum_{j in Q(x)} w_j(x)   (qualified-weight share);
        PWAI(x) = V * D(x) * P(x), averaged over test queries.
    Returns PWAI (T,), D (T,), P (T,)."""
    T, m = qual.shape
    if method == METHOD_FL:
        return np.zeros(T), np.full(T, np.nan), np.full(T, np.nan)
    if w is None:                               # contribution-weighted
        w_row = sizes / sizes.sum()
    else:
        w_row = positive_part(w)                # EW handled via uniform w
    is_qd = method in QD_SET
    w_unif = np.full(m, 1.0 / m)
    PWAI = np.zeros(T)
    DD = np.zeros(T)
    PP = np.zeros(T)
    for t in range(T):
        q = qual[t]                             # Q(x)
        if is_qd and q.any():                   # aggregate over Q(x) only
            wt = np.where(q, w_row, 0.0)
            s = wt.sum()
            wt = wt / s if s > 0 else w_unif
        elif is_qd:                             # fall-back: equal mean
            wt = w_unif
        else:                                   # non-QD: all m contribute
            wt = w_row
        wpos = wt[wt > 0]                # 0 * log(0) = 0 -- drop zeros
        m_star = len(wpos)               # activated participants at x
        if m_star == 1:
            D = 1.0
        else:
            H = float(-(wpos * np.log(wpos)).sum())
            D = min(max(1.0 - H / math.log(m_star), 0.0), 1.0)
        P = float(wt[q].sum())                  # qualified-weight share
        DD[t], PP[t], PWAI[t] = D, P, 1.0 * D * P
    return PWAI, DD, PP


def sad_per_query(attr, active):
    """SAD(x) = (1/m*) sum_{j active} 1/|A_j(x)| (Definition 2); falls back
    to all parties if no party is qualified for the query."""
    inv = 1.0 / attr
    T = attr.shape[0]
    out = np.zeros(T)
    for t in range(T):
        act = active[t]
        out[t] = inv[t][act].mean() if act.any() else inv[t].mean()
    return out


def alg_per_query(hloc):
    """ALG(x) = 1 - (1/m) sum_j h_j(x)^d (Definition 3, over ALL parties)."""
    return 1.0 - np.mean(hloc ** DIM, axis=1)


# ----------------------------------------------------------------------------
# Membership-inference attack (central adversary, Attack-III, MLP attacker)
# ----------------------------------------------------------------------------
# Protocol identical to the toy MIA experiments (MIA_toy_LAR_20trial.py):
#   * shadow model: GLOBAL Gaussian LAR (s = 2) trained on an independent
#     adversary pool (same DGP, seed 7777+trial), bandwidth by 3-fold CV;
#   * attack features (Attack-III): [|fit|, loss] with loss = (fit - y)^2;
#   * attacker: MLP(64, 32) trained on the shadow member/non-member
#     features, then scored on the VICTIM aggregate's features;
#   * victim members: MIA_CASE subsample of the training union (seed
#     9999+trial); non-members: MIA_N_NON2 fresh pool points.
# Here the victim predictor is generalised from QDLAR to EVERY combination
# strategy (and FL), so each method gets its own attack AUC; ONE shared
# shadow-trained attacker scores all methods, keeping the AUCs directly
# comparable.  Computed only at m = M_FIXED (the radar-chart party count).
MIA_ENABLE = os.environ.get('QDLAR_MIA', '1') == '1'
MIA_N_ADV = int(os.environ.get('QDLAR_MIA_N_ADV', '2000'))   # shadow train
MIA_N_NON1 = int(os.environ.get('QDLAR_MIA_N_NON1', '1000'))  # shadow non-mem
MIA_N_NON2 = int(os.environ.get('QDLAR_MIA_N_NON2', '2000'))  # victim non-mem
MIA_N_BAL = int(os.environ.get('QDLAR_MIA_N_BAL', '1000'))    # shadow members
MIA_CASE = int(os.environ.get('QDLAR_MIA_CASE', '2000'))      # victim members
MIA_CV_FOLD = 3                              # as the toy MIA experiments


def _generate_pool(n):
    """Same DGP as the training data with fresh noise (generate_pool of
    Function_toy_MIA.py)."""
    if DIM == 1:
        X = np.random.uniform(0.0, 1.0, n).reshape(-1, 1)
        y = create_y_g1(X.ravel()) + np.random.normal(0, 0.1, n)
    else:
        X = np.random.uniform(0.0, 1.0, (n, DIM))
        y = create_y_g2(X) + np.random.normal(0, 0.1, n)
    return X, y


def _nw_gauss_fit(X_tr, y_tr, X_q, h):
    """Global Gaussian-kernel LAR prediction (s = 2) -- the MIA shadow
    model (prediction_vector_LAR of Function_toy_MIA, signed fit)."""
    dn = _cdist(X_q, X_tr) / max(h, 1e-12)
    w = np.exp(-(dn ** 2))
    a0 = w @ y_tr
    b0 = w.sum(axis=1)
    return np.divide(a0, b0, out=np.zeros_like(a0), where=b0 != 0)


def mia_attack_iii(trial, blocks, assigns, params, sizes, w_ow, w_bs,
                   X_tr, y_tr):
    """Attack-III MIA AUC for every combination strategy (victim) -- see
    the protocol comment above.  Returns {method: AUC}."""
    from sklearn.neural_network import MLPClassifier
    from sklearn.metrics import roc_auc_score
    m = len(blocks)
    # ---- adversary pool (same DGP, independent seed) --------------------
    np.random.seed(7777 + trial)
    X_pool, y_pool = _generate_pool(MIA_N_ADV + MIA_N_NON1 + MIA_N_NON2)
    X_adv, y_adv = X_pool[:MIA_N_ADV], y_pool[:MIA_N_ADV]
    X_non1 = X_pool[MIA_N_ADV:MIA_N_ADV + MIA_N_NON1]
    y_non1 = y_pool[MIA_N_ADV:MIA_N_ADV + MIA_N_NON1]
    X_non2 = X_pool[MIA_N_ADV + MIA_N_NON1:]
    y_non2 = y_pool[MIA_N_ADV + MIA_N_NON1:]
    # ---- shadow model: global Gaussian LAR on the adversary data --------
    h_shadow = global_parameter_h(X_adv, y_adv, MIA_CV_FOLD, DIM)
    np.random.seed(5555 + trial)
    idx = np.random.choice(len(X_adv), MIA_N_BAL, replace=False)
    fit_ms = _nw_gauss_fit(X_adv, y_adv, X_adv[idx], h_shadow)
    fit_ns = _nw_gauss_fit(X_adv, y_adv, X_non1, h_shadow)
    F_sha = np.vstack([
        np.column_stack([np.abs(fit_ms), (fit_ms - y_adv[idx]) ** 2]),
        np.column_stack([np.abs(fit_ns), (fit_ns - y_non1) ** 2])])
    y_sha = np.hstack([np.ones(len(idx)), np.zeros(len(X_non1))])
    clf = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=500,
                        random_state=trial)
    clf.fit(F_sha, y_sha)
    # ---- victim: each strategy's aggregate on members vs non-members ----
    np.random.seed(9999 + trial)
    midx = np.random.choice(len(X_tr), MIA_CASE, replace=False)
    X_q = np.vstack([X_tr[midx], X_non2])
    y_q = np.concatenate([y_tr[midx], y_non2])
    lab = np.hstack([np.ones(len(midx)), np.zeros(len(X_non2))])
    FIT = hybrid_lar_all(X_q, blocks, assigns, params, m, log_mech=True)[0]
    active = np.abs(FIT) >= 1.0 / TRAIN_N          # qualification masks
    all_on = np.ones_like(active)
    ones = np.ones(m)
    preds = {
        METHOD_EW: aggregate(FIT, METHOD_EW, sizes, all_on, ones),
        METHOD_EWQD: aggregate(FIT, METHOD_EWQD, sizes, active, ones),
        METHOD_OW: aggregate(FIT, METHOD_OW, sizes, all_on, w_ow),
        METHOD_OWQD: aggregate(FIT, METHOD_OWQD, sizes, active, w_ow),
        METHOD_BS: aggregate(FIT, METHOD_BS, sizes, all_on, w_bs),
        METHOD_BSQD: aggregate(FIT, METHOD_BSQD, sizes, active, w_bs),
        METHOD_WA: aggregate(FIT, METHOD_WA, sizes, all_on, None),
        METHOD_WAQD: aggregate(FIT, METHOD_WAQD, sizes, active, None),
        METHOD_FL: fl_federated_linear(blocks, X_q),
    }
    auc = {}
    for mtd, fit in preds.items():
        F_vic = np.column_stack([np.abs(fit), (fit - y_q) ** 2])
        auc[mtd] = float(roc_auc_score(lab,
                                       clf.predict_proba(F_vic)[:, 1]))
    return auc


# ----------------------------------------------------------------------------
# Evaluation engine: all methods x all metrics for one (trial, m, setting)
# ----------------------------------------------------------------------------
METRICS = ['PWAI', 'D', 'P', 'SAD', 'ALG', 'MSE', 'AUC']


def _query_subset(trial, T):
    """Same query-subset convention as the toy SAD/ALG scripts."""
    return np.random.RandomState(trial).choice(
        T, min(N_QUERY, T), replace=False)


def _record(out, method, FIT, ATTR, HLOC, active, qual, w, sizes, y_te,
            qidx):
    pwai, dd, pp = pwai_per_query(method, sizes, qual, w=w)
    sad = sad_per_query(ATTR[qidx], active[qidx])     # only the SAD/ALG
    alg = alg_per_query(HLOC[qidx])                   # query subset is used
    out[method] = {
        'PWAI': float(np.nanmean(pwai)),
        'D': float(np.nanmean(dd)),
        'P': float(np.nanmean(pp)),
        'SAD': float(np.nanmean(sad)),
        'ALG': float(np.nanmean(alg)),
        'MSE': float(np.mean((aggregate(FIT, method, sizes, active, w=w)
                              - y_te) ** 2)),
        'AUC': np.nan,                     # filled only at m = M_FIXED
    }


def evaluate_trial_m(trial, m, setting, cache):
    """One (trial, m, setting): every method, every metric."""
    X_tr, y_tr, X_te, y_te = load_toy_data(trial)
    X_val, y_val = make_val_data(trial)
    blocks = get_blocks(X_tr, y_tr, m, setting)
    sizes = block_sizes(blocks)
    assigns = get_assignments(m)
    qidx = _query_subset(trial, len(X_te))
    all_active = np.ones((len(X_te), m), dtype=bool)
    out = {}

    # ---------------- LAR-hybrid family (shared local estimates) -----------
    # Every strategy: SAME hybrid LAR parties, SAME 5-fold-CV parameters,
    # SAME logarithm mechanism; they differ ONLY in the aggregation rule
    # (weights) and in whether the qualification mechanism is applied.
    params = get_hybrid_params(trial, m, setting, blocks, assigns, cache)
    FIT_log, ATTR_log, HLOC_log = hybrid_lar_all(
        X_te, blocks, assigns, params, m, log_mech=True)
    FITv_log = hybrid_lar_all(X_val, blocks, assigns, params, m,
                              log_mech=True)[0]
    active_log = np.abs(FIT_log) >= 1.0 / TRAIN_N      # qualification

    w_ow, w_bs, _ = ow_bs_weights(FITv_log - y_val[:, None])

    ones = np.ones(m)
    _record(out, METHOD_EW, FIT_log, ATTR_log, HLOC_log, all_active,
            active_log, ones, sizes, y_te, qidx)
    _record(out, METHOD_EWQD, FIT_log, ATTR_log, HLOC_log, active_log,
            active_log, ones, sizes, y_te, qidx)
    _record(out, METHOD_OW, FIT_log, ATTR_log, HLOC_log, all_active,
            active_log, w_ow, sizes, y_te, qidx)
    _record(out, METHOD_OWQD, FIT_log, ATTR_log, HLOC_log, active_log,
            active_log, w_ow, sizes, y_te, qidx)
    _record(out, METHOD_BS, FIT_log, ATTR_log, HLOC_log, all_active,
            active_log, w_bs, sizes, y_te, qidx)
    _record(out, METHOD_BSQD, FIT_log, ATTR_log, HLOC_log, active_log,
            active_log, w_bs, sizes, y_te, qidx)
    _record(out, METHOD_WA, FIT_log, ATTR_log, HLOC_log, all_active,
            active_log, None, sizes, y_te, qidx)
    _record(out, METHOD_WAQD, FIT_log, ATTR_log, HLOC_log, active_log,
            active_log, None, sizes, y_te, qidx)

    # ---------------- classic federated learning (V = 0) -------------------
    fit_fl = fl_federated_linear(blocks, X_te)
    out[METHOD_FL] = {'PWAI': 0.0, 'D': np.nan, 'P': np.nan,
                      'SAD': np.nan, 'ALG': np.nan,
                      'MSE': float(np.mean((fit_fl - y_te) ** 2)),
                      'AUC': np.nan}

    # ---------------- MIA (Attack-III, central adversary) ------------------
    # Only at m = M_FIXED (the radar-chart party count); the AUC arrays
    # stay NaN at every other m.
    if MIA_ENABLE and m == M_FIXED:
        auc = mia_attack_iii(trial, blocks, assigns, params, sizes,
                             w_ow, w_bs, X_tr, y_tr)
        for mtd, a in auc.items():
            out[mtd]['AUC'] = a
    return out


# ----------------------------------------------------------------------------
# Result cache: compute the full grid once, re-plot without re-running
# ----------------------------------------------------------------------------
def _fingerprint():
    return {'DIM': DIM, 'TRAIN_N': TRAIN_N, 'TEST_N': TEST_N,
            'VAL_N': VAL_N, 'N_TRIALS': N_TRIALS, 'N_QUERY': N_QUERY,
            'M_LIST': list(M_LIST), 'METHODS': list(METHODS),
            'PWAI_DEF': 3,     # 3 = paper's Definition 1 (P = qualified-
                               # weight share; D normalised by log m*(x))
            'MIA': 1 if MIA_ENABLE else 0,
            'MIA_M': M_FIXED if MIA_ENABLE else None}


def load_results():
    if FORCE_RERUN or not os.path.exists(RESULT_CACHE):
        return None
    pack = np.load(RESULT_CACHE, allow_pickle=True).tolist()
    if pack.get('fingerprint') != _fingerprint():
        print('Cached results match a different configuration -- re-running.')
        return None
    print('Loaded saved results from %s (no re-run needed).' % RESULT_CACHE)
    return pack['results']


def save_results(results):
    np.save(RESULT_CACHE, {'fingerprint': _fingerprint(),
                           'results': results})
    print('Saved results to %s' % RESULT_CACHE)


def empty_results():
    return {setting: {mtd: {met: np.full((len(M_LIST), N_TRIALS), np.nan)
                            for met in METRICS}
                      for mtd in METHODS}
            for setting in ('same', 'diff')}


def get_results():
    """Compute (or load) the full result grid: both block settings,
    all methods, all m in M_LIST, all trials."""
    results = load_results()
    if results is not None:
        return results
    results = empty_results()
    cache = load_param_cache()
    t_start = time.time()
    n_stage = 2 * len(M_LIST)
    total = n_stage * N_TRIALS
    stage, done = 0, 0
    for setting in ('same', 'diff'):
        for im, m in enumerate(M_LIST):
            stage += 1
            print('[stage %d/%d] %s blocks, m=%d: tuning + evaluating '
                  '%d trials ...' % (stage, n_stage, setting, m, N_TRIALS))
            for trial in range(N_TRIALS):
                t0 = time.time()
                rec = evaluate_trial_m(trial, m, setting, cache)
                for mtd in METHODS:
                    for met in METRICS:
                        results[setting][mtd][met][im, trial] = \
                            rec[mtd][met]
                done += 1
                el = time.time() - t_start
                eta = el / done * (total - done)
                print('[prog %d/%d (%d%%)] %s m=%d trial %d/%d done in %s '
                      '| elapsed %s | ETA %s'
                      % (done, total, round(100 * done / total), setting,
                         m, trial + 1, N_TRIALS, _fmt_dur(time.time() - t0),
                         _fmt_dur(el), _fmt_dur(eta)))
            save_results(results)          # checkpoint after every m
    print('Total computation time: %s' % _fmt_dur(time.time() - t_start))
    save_results(results)
    return results


def metric_mean_std(results, setting, method, metric):
    arr = results[setting][method][metric]     # (n_m, n_trials)
    return np.nanmean(arr, axis=1), np.nanstd(arr, axis=1)


def summary_table():
    """Console + CSV summary at m = M_FIXED for both settings."""
    results = get_results()
    im = M_LIST.index(M_FIXED) if M_FIXED in M_LIST else None
    if im is None:
        return
    rows = []
    for setting in ('same', 'diff'):
        for mtd in METHODS:
            row = [setting, METHOD_LABEL[mtd]]
            for met in METRICS:
                mu, sd = metric_mean_std(results, setting, mtd, met)
                row.append('%.4f+/-%.4f' % (mu[im], sd[im]))
            rows.append(row)
    header = ['setting', 'method'] + [TABLE_LABEL.get(m, m)
                                      for m in METRICS]
    colw = [max(len(str(r[c])) for r in [header] + rows)
            for c in range(len(header))]
    print('\nSummary at m = %d (mean +/- sd over %d trials):'
          % (M_FIXED, N_TRIALS))
    for r in [header] + rows:
        print('  ' + '  '.join(str(r[c]).ljust(colw[c])
                                for c in range(len(header))))
    csv_file = os.path.join(
        RESULT_DIR, 'combination_foresting_gpu_new_summary_d%d_m%d.csv'
        % (DIM, M_FIXED))
    with open(csv_file, 'w') as f:
        f.write(','.join(header) + '\n')
        for r in rows:
            f.write(','.join(str(c) for c in r) + '\n')
    print('Saved: %s' % csv_file)


# ----------------------------------------------------------------------------
# Plotting (paper palette; evenly spaced x-axis)
# ----------------------------------------------------------------------------
def setup_rcparams():
    import matplotlib.pyplot as plt
    from matplotlib import rcParams
    rcParams.update({'font.family': 'Times New Roman',
                     'font.size': 17,
                     'mathtext.fontset': 'stix'})
    return plt


METRIC_LABEL = {'PWAI': 'PWAI', 'D': 'Distinguishability $D$',
                'P': 'Qualified-weight share $P$', 'SAD': 'SAD',
                'ALG': 'ALG', 'MSE': 'MSE'}
METRIC_TITLE = {
    'PWAI': 'Party-level aggregation interpretability '
            '(PWAI, Definition 1)',
    'SAD': 'Sample attribution depth (SAD, Definition 2)',
    'ALG': 'Attribution localization granularity (ALG, Definition 3)',
    'MSE': 'Prediction accuracy'}
# display names for the summary table / CSV header
TABLE_LABEL = {'PWAI': 'PWAI (party-level aggregation)',
               'AUC': 'AUC (MIA, Attack-III)'}
SETTING_TITLE = {'same': 'equal-size setting',
                 'diff': 'heterogeneous-size setting'}


def plot_metric_two_panels(results, metric, setting, logy=False,
                           fname=None, suptitle_extra=''):
    """One figure, two panels over the SAME hybrid LAR parties (all with the
    logarithm mechanism): (a) the four aggregation rules WITHOUT
    qualification; (b) the same rules WITH qualification (WAQD = full
    QDLAR).  Evenly spaced x positions for the m grid."""
    if metric == 'MSE':
        logy = True          # final: MSE panels always use a log y-axis
    plt = setup_rcparams()
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.2))
    xpos = np.arange(len(M_LIST))
    for ax, fam, tag in ((axes[0], FAM_PLAIN, '(a)'),
                         (axes[1], FAM_QUAL, '(b)')):
        for mtd in fam:
            if metric == 'MSE' and mtd == METHOD_FL:
                continue             # final: no FL in the MSE panels
            mu, sd = metric_mean_std(results, setting, mtd, metric)
            if np.all(np.isnan(mu)):
                continue
            st = METHOD_STYLE[mtd]
            mfc, mec = _mk(st)
            ax.plot(xpos, mu, color=st['color'], marker=st['marker'],
                    linewidth=st['lw'], markersize=st['ms'],
                    linestyle=st.get('ls', '-'),
                    markerfacecolor=mfc, markeredgecolor=mec,
                    markeredgewidth=1.4,
                    label=METHOD_LABEL[mtd], zorder=st['zorder'])
            band_lo = mu - sd
            if logy:           # log axis cannot show <= 0
                band_lo = np.maximum(band_lo, np.maximum(mu, 1e-300) * 0.5)
            ax.fill_between(xpos, band_lo, mu + sd, color=st['color'],
                            alpha=0.12, zorder=1)
        ax.set_xticks(xpos)
        ax.set_xticklabels([str(m) for m in M_LIST], fontsize=17,
                           rotation=45)
        ax.set_xlabel('Number of local agents $m$', fontsize=20)
        ax.set_ylabel(METRIC_LABEL[metric], fontsize=20)
        ax.tick_params(axis='y', labelsize=17)
        if logy:
            ax.set_yscale('log')
        sub = ('Aggregation methods (no qualification, $d$=%s)' % DIM if tag == '(a)'
               else 'Aggregation methods (qualification, $d$=%s)' % DIM)

        ax.set_title('%s' % (sub), fontsize=20, weight='bold',
                     pad=20)
        ax.legend(loc='upper left', fontsize=16, framealpha=0.9, ncol=2,
                      labelspacing=0.8)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.grid(axis='y', linestyle='--', alpha=0.3)
    # fig.suptitle('%s (%s, $d$ = %d)%s'
    #              % (METRIC_TITLE[metric], SETTING_TITLE[setting], DIM,
    #                 suptitle_extra),
    #              fontsize=20, weight='bold', y=0.96)
    # fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.subplots_adjust(top=0.84, bottom=0.2, left=0.098, right=0.98, wspace=0.3)
    if fname is None:
        fname = os.path.join(FIG_DIR,
                             'Fig_combination_%s_%s_d%d.pdf'
                             % (metric, setting, DIM))
    fig.savefig(fname, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    plt.close(fig)
    print('Saved: %s' % fname)





def plot_pwai_bars(results, fname=None):
    """Grouped bar chart at the fixed m = M_FIXED: one group per method,
    two bars (equal-size / heterogeneous parties)."""
    plt = setup_rcparams()
    if M_FIXED not in M_LIST:
        print('M_FIXED=%d not in M_LIST -- bar chart skipped.' % M_FIXED)
        return
    im = M_LIST.index(M_FIXED)
    show = [m for m in METHODS]
    xpos = np.arange(len(show))
    width = 0.38
    fig, ax = plt.subplots(figsize=(13.5, 6.2))
    for k, (setting, color, lab) in enumerate(
            (('same', '#F2C894', 'equal-size setting'),
             ('diff', '#D97A4A', 'heterogeneous-size setting'))):
        vals = [results[setting][mtd]['PWAI'][im, :].mean()
                for mtd in show]
        bars = ax.bar(xpos + (k - 0.5) * width, vals, width, color=color,
                      edgecolor='#6E3A14', linewidth=0.7, label=lab,
                      zorder=3)
        for rect, mtd in zip(bars, show):
            if mtd in QD_SET:                # qualified variants: hatched
                rect.set_hatch('///')
    ax.set_xticks(xpos)
    ax.set_xticklabels([METHOD_LABEL[m] for m in show], fontsize=17,
                       rotation=30, ha='right')
    ax.set_ylabel('PWAI', fontsize=22)
    ax.tick_params(axis='y', labelsize=20)
    ax.set_title('PWAI of forecast combination methods at $m$ = %d '
                 '($d$ = %d)' % (M_FIXED, DIM),
                 fontsize=22, weight='bold', pad=12)
    ax.legend(loc='upper right', fontsize=20, framealpha=0.9,
          labelspacing=0.8)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(axis='y', linestyle='--', alpha=0.3)
    fig.tight_layout()
    if fname is None:
        fname = os.path.join(FIG_DIR,
                             'Fig_combination_PWAI_bar_m%d_d%d.pdf'
                             % (M_FIXED, DIM))
    fig.savefig(fname, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.close(fig)
    print('Saved: %s' % fname)


def plot_pwai_decomposition(results, setting, fname=None):
    """D and P components of PWAI vs. m (explains the PWAI differences)."""
    plt = setup_rcparams()
    fig, axes = plt.subplots(1, 2, figsize=(15.5, 6.4))
    xpos = np.arange(len(M_LIST))
    show = [m for m in METHODS if m != METHOD_FL]
    for ax, metric in ((axes[0], 'D'), (axes[1], 'P')):
        for mtd in show:
            mu, sd = metric_mean_std(results, setting, mtd, metric)
            if np.all(np.isnan(mu)):
                continue
            st = METHOD_STYLE[mtd]
            mfc, mec = _mk(st)
            ax.plot(xpos, mu, color=st['color'], marker=st['marker'],
                    linewidth=st['lw'], markersize=st['ms'] - 1,
                    linestyle=st.get('ls', '-'),
                    markerfacecolor=mfc, markeredgecolor=mec,
                    markeredgewidth=1.2,
                    label=METHOD_LABEL[mtd], zorder=st['zorder'])
        ax.set_xticks(xpos)
        ax.set_xticklabels([str(m) for m in M_LIST], fontsize=13,
                           rotation=45)
        ax.set_xlabel('Number of parties $m$', fontsize=20)
        ax.set_ylabel(METRIC_LABEL[metric], fontsize=20)
        ax.tick_params(axis='y', labelsize=17)
        ax.set_title('(a) Distinguishability' if metric == 'D'
                     else '(b) Qualified-weight share',
                     fontsize=17, weight='bold', pad=10)
        ax.legend(loc='best', fontsize=11, framealpha=0.9, ncol=2,
                      labelspacing=0.8)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.grid(axis='y', linestyle='--', alpha=0.3)
    fig.suptitle('PWAI decomposition -- %s, toy simulation ($d$ = %d)'
                 % (SETTING_TITLE[setting], DIM),
                 fontsize=20, weight='bold', y=1.00)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    if fname is None:
        fname = os.path.join(FIG_DIR,
                             'Fig_combination_PWAI_decomp_%s_d%d.pdf'
                             % (setting, DIM))
    fig.savefig(fname, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    plt.close(fig)
    print('Saved: %s' % fname)


def plot_tradeoff(results, setting, fname=None):
    """Accuracy-interpretability trade-off at m = M_FIXED: test MSE (x)
    vs. PWAI (y); every point is one strategy (mean over trials)."""
    plt = setup_rcparams()
    if M_FIXED not in M_LIST:
        return
    im = M_LIST.index(M_FIXED)
    fig, ax = plt.subplots(figsize=(9.5, 7.2))
    xs, ys = [], []
    for mtd in METHODS:
        x = results[setting][mtd]['MSE'][im, :].mean()
        y = results[setting][mtd]['PWAI'][im, :].mean()
        st = METHOD_STYLE[mtd]
        xs.append(x); ys.append(y)
        if st.get('filled', True):
            ax.scatter(x, y, s=250, color=st['color'], marker=st['marker'],
                       edgecolor=st['color'], linewidth=1.2,
                       zorder=st['zorder'] + 5)
        else:
            ax.scatter(x, y, s=430, facecolors='none',
                       edgecolors=st['color'], marker=st['marker'],
                       linewidth=1.9, zorder=st['zorder'] + 5)
        ax.annotate(METHOD_LABEL[mtd], (x, y), textcoords='offset points',
                    xytext=(9, 7), fontsize=13.5, color=st['color'])
    ax.set_xscale('log')           # spread out the small-MSE cluster
    ax.set_xlim(min(xs) / 1.8, max(xs) * 2.2)
    dy = max(max(ys) - min(ys), 0.02)
    ax.set_ylim(min(ys) - 0.12 * dy, max(ys) + 0.20 * dy)
    ax.set_xlabel('MSE (lower is better, log scale)', fontsize=20)
    ax.set_ylabel('PWAI (higher is better)', fontsize=20)
    ax.tick_params(labelsize=16)
    ax.set_title('Accuracy-interpretability trade-off at $m$ = %d\n'
                 '(%s, toy simulation, $d$ = %d)'
                 % (M_FIXED, SETTING_TITLE[setting], DIM),
                 fontsize=18, weight='bold', pad=12)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(linestyle='--', alpha=0.3)
    fig.tight_layout()
    if fname is None:
        fname = os.path.join(FIG_DIR,
                             'Fig_combination_tradeoff_%s_m%d_d%d.pdf'
                             % (setting, M_FIXED, DIM))
    fig.savefig(fname, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.close(fig)
    print('Saved: %s' % fname)


# ----------------------------------------------------------------------------
# Pareto plots: test MSE (x, lower is better) vs. interpretability (y,
# higher is better); one point per strategy at the FIXED party count
# m = PARETO_M (default M_FIXED; override with the QDLAR_PARETO_M env var)
# ----------------------------------------------------------------------------
PARETO_M = int(os.environ.get('QDLAR_PARETO_M', str(M_FIXED)))
PARETO_DIR = FIG_DIR
os.makedirs(PARETO_DIR, exist_ok=True)

def plot_pareto(results, metric, setting, fname=None, logy=False):
    """Pareto plot at the single fixed party count m = PARETO_M.
    log-scaled MSE axis (spreads out the small-MSE cluster); marker =
    strategy (open = no qualification, filled = with qualification).
    Saved under the 'pareto figure' subfolder."""
    plt = setup_rcparams()
    if PARETO_M not in M_LIST:
        print('PARETO_M=%d is not in M_LIST -- Pareto plot skipped.'
              % PARETO_M)
        return
    im = M_LIST.index(PARETO_M)
    fig, ax = plt.subplots(figsize=(10.8, 8.0))
    plotted, xs, ys = [], [], []
    for mtd in METHODS:
        st = METHOD_STYLE[mtd]
        x = np.nanmean(results[setting][mtd]['MSE'][im])
        y = np.nanmean(results[setting][mtd][metric][im])
        if np.isnan(x) or np.isnan(y):
            continue                     # FL has no SAD/ALG (V = 0)
        plotted.append(mtd)
        xs.append(x); ys.append(y)
        if st.get('filled', True):
            kw = dict(color=st['color'], edgecolor=st['color'], linewidth=1.0)
        else:
            kw = dict(facecolors='none', edgecolors=st['color'],
                      linewidth=1.9)
        # open markers larger than filled ones, so that two coincident
        # points (a strategy pair) still read as a ring with a solid core
        s = 800 if st.get('filled', True) else 800
        ax.scatter(x, y, s=s, marker=st['marker'],
                   zorder=st['zorder'] + 3, alpha=0.95, **kw)
    ax.set_xscale('log')           # spread out the small-MSE cluster
    # padded axis limits so the large markers never sit on the spines
    ax.set_xlim(min(xs) / 1.8, max(xs) * 2.0)
    if logy:
        ax.set_ylim(min(ys) / 1.5, max(ys) * 1.6)
    else:
        dy = max(max(ys) - min(ys), 0.02)
        ax.set_ylim(min(ys) - 0.12 * dy, max(ys) + 0.15 * dy)
    # legend: strategies only (the party count m is fixed); markersize
    # matches the marker diameter used in the plot (s = area in pts^2)
    from matplotlib.lines import Line2D
    h_method = []
    for mtd in METHODS:
        if mtd not in plotted:
            continue
        st = METHOD_STYLE[mtd]
        mfc, mec = _mk(st)
        h_method.append(Line2D(
            [0], [0], marker=st['marker'], color='none',
            markerfacecolor=mfc, markeredgecolor=mec,
            markeredgewidth=1.6, markersize=25,
            label=METHOD_LABEL[mtd]))
    ax.legend(handles=h_method, loc='best', fontsize=18,
              framealpha=0.9, ncol=2, title='strategy',
              title_fontsize=20, labelspacing=1.1)
    ax.set_xlabel('Test MSE (lower is better, log scale)', fontsize=25)
    ax.set_ylabel('%s (higher is better)' % METRIC_LABEL[metric],
                  fontsize=25)
    if logy:
        ax.set_yscale('log')
    ax.tick_params(labelsize=20)
    # ax.set_title('Accuracy-interpretability Pareto plot\n'
    #              '(measured by %s, %s, $d$ = %d, $m$ = %d)'
    #              % (metric, SETTING_TITLE[setting], DIM, PARETO_M),
    #              fontsize=28, weight='bold', pad=12)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.grid(linestyle='--', alpha=0.3)
    fig.tight_layout()
    if fname is None:
        fname = os.path.join(PARETO_DIR,
                             'Fig_combination_Pareto_%s_%s_m%d_d%d_new.pdf'
                             % (metric, setting, PARETO_M, DIM))
    fig.savefig(fname, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    print('Saved: %s' % fname)

# ----------------------------------------------------------------------------
# Radar charts: five "bigger-is-better" spokes at m = PARETO_M -- one figure
# for the strategies WITHOUT qualification (+ FL) and one for the qualified
# (QD) strategies (+ FL).  Every spoke is min-max normalised across the
# plotted methods, so the best method on a spoke touches the outer ring
# (closer to the boundary = better; larger polygon area = stronger overall).
# ----------------------------------------------------------------------------
RADAR_DIR = FIG_DIR
os.makedirs(RADAR_DIR, exist_ok=True)

# (metric key, "bigger-is-better" transform, scaling, spoke label).
# The cross-method differences differ wildly per spoke, so one scaling
# rule does not fit all:
#   'minmax'        worst method -> 0, best -> 1 (all-equal -> 0.5);
#   ('window',a,b)  fixed meaningful window, clipped to [0,1] -- used for
#                   MIA resistance, where 0.5 is the random-guess baseline
#                   (mid-ring) and only departures from it are meaningful;
#   MSE is compared as -log10(MSE) so that the good methods (MSE ~ 1e-3)
#   are not squashed against the ring by one much worse method (FL).
RADAR_AXES = [('MSE', 'neglog', 'minmax',
               'Accuracy\n($-\\log_{10}$ MSE)'),
              ('PWAI', None, 'minmax', 'Party-level aggregation\n(PWAI)'),
              ('ALG', None, 'minmax', 'Localization granularity\n(ALG)'),
              ('SAD', None, 'minmax', 'Sample-level attribution\n(SAD)'),
              ('AUC', 'one_minus', ('window', 0.4, 0.6),
               'MIA resistance\n(1 $-$ AUC)')]


def _radar_transform(v, tf):
    """Raw metric vector -> 'bigger is better' quantity."""
    if tf == 'one_minus':
        return 1.0 - v
    if tf == 'neglog':
        return -np.log10(np.maximum(v, 1e-12))
    return v


def _radar_scale(v, spec):
    """'Bigger-is-better' spoke vector -> [0, 1] radii."""
    if np.all(np.isnan(v)):
        return v
    if isinstance(spec, tuple) and spec[0] == 'window':
        _, lo, hi = spec
        return np.clip((v - lo) / (hi - lo), 0.0, 1.0)
    lo, hi = np.nanmin(v), np.nanmax(v)
    return np.full_like(v, 0.5) if hi - lo < 1e-12 else (v - lo) / (hi - lo)
RADAR_GROUPS = [('noQD', 'without qualification',
                 [METHOD_EW, METHOD_OW, METHOD_BS, METHOD_WA]),
                ('QD', 'with qualification',
                 [METHOD_EWQD, METHOD_OWQD, METHOD_BSQD, METHOD_WAQD])]


def plot_radar(results, setting, fname=None):
    """Radar (spider) charts at m = PARETO_M; two figures per setting --
    the noQD group and the QD group (FL excluded).  Spokes: Accuracy
    (-log10 MSE), party-level aggregation (PWAI), localization
    granularity (ALG), sample-level attribution (SAD), MIA resistance
    (1 - AUC).  Per-spoke scaling to [0, 1] radii: MSE is compared as
    -log10(MSE) and min-max scaled; PWAI/ALG/SAD are min-max scaled;
    MIA resistance uses a fixed window anchored at the random-guess
    baseline 0.5 (mid-ring).  FL has no SAD/ALG (V = 0), so its polygon
    is drawn as line segments only on the spokes where it is defined.
    Saved under the 'radar figure' subfolder."""
    plt = setup_rcparams()
    if PARETO_M not in M_LIST:
        print('PARETO_M=%d is not in M_LIST -- radar plot skipped.'
              % PARETO_M)
        return
    im = M_LIST.index(PARETO_M)
    angles = np.linspace(0.0, 2.0 * np.pi, len(RADAR_AXES), endpoint=False)
    ang_c = np.concatenate([angles, angles[:1]])
    for tag, gtitle, group in RADAR_GROUPS:
        V = np.full((len(group), len(RADAR_AXES)), np.nan)
        for k, (key, tf, spec, _) in enumerate(RADAR_AXES):
            v = np.array([np.nanmean(results[setting][mtd][key][im])
                          for mtd in group], dtype=float)
            V[:, k] = _radar_transform(v, tf)
        # per-spoke scaling to [0, 1] radii (see the RADAR_AXES comment)
        R = np.full_like(V, np.nan)
        for k, (key, tf, spec, _) in enumerate(RADAR_AXES):
            v = V[:, k]
            if np.all(np.isnan(v)):
                print('radar (%s, %s): metric %s is missing for every '
                      'method -- re-run the results with QDLAR_MIA=1.'
                      % (setting, tag, key))
                continue
            R[:, k] = _radar_scale(v, spec)
        fig = plt.figure(figsize=(9.6, 8.8))
        ax = fig.add_subplot(111, polar=True)
        ax.set_theta_offset(np.pi / 2.0)
        ax.set_theta_direction(-1)
        for i, mtd in enumerate(group):
            st = METHOD_STYLE[mtd]
            r = np.concatenate([R[i], R[i, :1]])
            mfc = st['color'] if st.get('filled', True) else 'none'
            ax.plot(ang_c, r, color=st['color'], lw=2.6,
                    marker=st['marker'], ms=11, markerfacecolor=mfc,
                    markeredgecolor=st['color'], markeredgewidth=1.6,
                    label=METHOD_LABEL[mtd], zorder=st['zorder'] + 3)
            if not np.isnan(R[i]).any():        # FL has NaN spokes
                ax.fill(ang_c, r, color=st['color'], alpha=0.10, zorder=1)
        ax.set_xticks(angles)
        ax.set_xticklabels([lab for _, _, _, lab in RADAR_AXES],
                           fontsize=15)
        ax.set_ylim(0.0, 1.0)
        ax.set_yticks([0.25, 0.5, 0.75, 1.0])
        ax.set_yticklabels(['0.25', '0.50', '0.75', '1.00'], fontsize=11,
                           color='#7F7F7F')
        ax.grid(linestyle='--', alpha=0.45)
        ax.spines['polar'].set_alpha(0.35)
        ax.set_title('Combination-strategy radar (%s, $m$ = %d)\n'
                     '(%s, toy simulation, $d$ = %d)'
                     % (gtitle, PARETO_M, SETTING_TITLE[setting], DIM),
                     fontsize=17, weight='bold', pad=30)
        ax.legend(loc='upper center', bbox_to_anchor=(0.5, -0.05),
                  ncol=len(group), fontsize=13, framealpha=0.9,
                  columnspacing=1.4, handletextpad=0.6)
        fig.tight_layout()
        if fname is None:
            fn = os.path.join(
                RADAR_DIR, 'Fig_combination_radar_%s_%s_m%d_d%d.pdf'
                % (tag, setting, PARETO_M, DIM))
        else:
            base, ext = os.path.splitext(fname)
            fn = '%s_%s%s' % (base, tag, ext)
        fig.savefig(fn, dpi=600, format='pdf', bbox_inches='tight',
                    pad_inches=0.2)
        plt.close(fig)
        print('Saved: %s' % fn)
