"""
================================================================================
Function_toy_MIA.py  --  Toy-simulation version of Function_same_block_warfarin_MIA.py
================================================================================
Membership-inference-attack (MIA) function module for the TOY simulation
(generated data, NOT real data).

What changed with respect to the real-data (maternity/warfarin) version:
  1. Data are GENERATED from the toy DGP: X ~ Uniform[0,1]^d,
     d = 1: y = g1(x) + N(0, 0.1)   (g1 = piecewise Wendland, 0 for x > 0.5)
     d = 5: y = g2(x) + N(0, 0.1)   (g2 = radial Wendland + 0.2||x||^2)
     -- identical to Function_same_block_same_and_fixed_local_size.py so that
        np.random.seed(trial) + generate_data(.) reproduces the training data
        of trails_d1_hybrid.npy / trails_d5_hybrid.npy BIT BY BIT.
  2. Local parameters come from trails_d{1,5}_hybrid.npy
     (local_h_gau / local_h_epan / local_h_naive / local_k,
      each {trial: {fen: array}}), m = 5, 10, ..., 350  (gap = 5).
     fen = m // 5 - 1.
  3. The three *_forMIA functions are copied verbatim from the real-data
     version (same vectorization, same random.seed(0) algorithm assignment,
     same log mechanism, same qualification rule):
       - hybrid_algorithm_test_central_forMIA    : aggregate QDLAR prediction
                                                   (log mechanism + qualification
                                                    rule) on arbitrary samples;
       - hybrid_algorithm_test_local_forMIA      : party 1's OWN local model on
                                                   its OWN block (members),
                                                   NO qualification rule;
       - hybrid_algorithm_test_local_forMIA_non_v: party 1's local model on
                                                   non-member samples.
  4. Shadow model = global Gaussian-kernel LAR, h tuned by CV (CV_FOLD = 3
     for the toy simulation, as in the original toy experiments).

NB: for d = 1 the X arrays are ONE-DIMENSIONAL (shape (n,)) everywhere --
    this is required for the noise broadcast to coincide with the original
    runs.  All functions below handle both 1-d (d=1) and 2-d (d=5) X.
================================================================================
"""

import math
import random
import numpy as np
import pandas as pd
from pandas import DataFrame
from sklearn.model_selection import KFold

print('toy simulation (generated data)')


'''1. Create data, X is uniform distribution on the (hyper-) cube [0,1]'''
# generate y from g1, dimension = 1
def create_y_g1(data):
    y = np.empty(shape=(len(data)))
    for i in range(len(data)):
        if (data[i] >= 0) and (data[i] <= 0.5):
            y[i] = max(((1.0 - 2 * data[i]) ** 3), 0) * (1.0 + 6 * data[i])
        else:
            y[i] = 0
    return y


# generate y from g2, dimension = 5
def create_y_g2(data):
    y = np.empty(shape=(len(data)))
    for i in range(len(data)):
        norm_row = np.linalg.norm(data[i])
        if (norm_row >= 0) and (norm_row <= 1):
            y[i] = (max((1 - norm_row), 0) ** 5) * (1 + 5 * norm_row) + 0.2 * norm_row ** 2
        else:
            y[i] = 0.2 * norm_row ** 2
    return y


# sampling y, d = 1, 5
def sample(train_size, test_size, d):
    X_train = np.random.uniform(0.0, 1.0, train_size)
    X_test = np.random.uniform(0.0, 1.0, test_size)

    if d == 1:
        noise = np.random.normal(0, 0.1, train_size)
        y_train = create_y_g1(X_train) + noise
        y_test = create_y_g1(X_test)
    else:
        noise = np.random.normal(0, 0.1, train_size[0])
        y_train = create_y_g2(X_train) + noise
        y_test = create_y_g2(X_test)
    return X_train.shape, y_train.shape, X_train, y_train, X_test.shape, y_test.shape, X_test, y_test


# generate data for simulation (victim = the toy TRAIN set; identical seeds
# to the original experiments => identical data to the parameter training)
def generate_data(train, test, d):
    g1sample = sample(train, test, d)
    X_train, y_train, X_test, y_test = g1sample[2], g1sample[3], g1sample[6], g1sample[7]
    print('------------------------------From d = %s ------------------------------------------' % d)
    print('Train set X:%s, y:%s  |  Test set X:%s, y:%s' % (g1sample[0], g1sample[1], g1sample[4], g1sample[5]))
    return X_train, y_train, X_test, y_test


# generate an ADVERSARY pool from the same DGP (independent of the victim
# data).  y is OBSERVED (noisy), like the generated_y of the real-data
# version -- both members and non-members carry the observation noise.
def generate_pool(n, d):
    if d == 1:
        X = np.random.uniform(0.0, 1.0, n)
        noise = np.random.normal(0, 0.1, n)
        y = create_y_g1(X) + noise
    else:
        X = np.random.uniform(0.0, 1.0, (n, d))
        noise = np.random.normal(0, 0.1, n)
        y = create_y_g2(X) + noise
    return X, y


'''
2. divide data
'''
# divide data for same size
def mblocks(x, y, m):
    blocks = DataFrame(columns=('block_x', 'block_y'))
    for i in range(m):
        a = len(x) / m
        begin, end = int(a * i), int(a * (i + 1))
        blocks.loc[i] = [x[begin: end], y[begin: end]]
    return blocks


'''2.1 global Gaussian bandwidth for the SHADOW model (CV_FOLD = 3 for toy)'''
def GE_gaussiank(x_tra, y_tra, x_tes, y_tes, h, d, s):
    t = x_tes.shape[0]
    n = x_tra.shape[0]

    # transform (n,d) to (t,d,n)
    x_tra = x_tra.T
    x_tra = np.reshape(x_tra, (1, d, n), order='A')
    x_tra = np.repeat(x_tra, t, axis=0)

    # transform (t,d) to (t,d,n)
    x_tes = np.reshape(x_tes, (t, d, 1))
    x_tes = np.repeat(x_tes, n, axis=2)

    dis = (x_tes - x_tra) / h                   # (t,d,n)
    dis_norm = (np.linalg.norm(dis, axis=1)) ** s
    weight = np.exp((-dis_norm))
    a0 = np.dot(weight, y_tra)
    b0 = np.sum(weight, axis=1)
    fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)  # 0/0 = 0

    average_error = np.sum((fit - y_tes) ** 2) / t
    return average_error


def cv_global_h(x, y, f, h, d):
    s = 2
    kf = KFold(n_splits=f)
    error = []
    for train_index, test_index in kf.split(x):
        x_train, x_test = x[train_index], x[test_index]
        y_train, y_test = y[train_index], y[test_index]
        error_validation = GE_gaussiank(x_train, y_train, x_test, y_test, h, d, s)
        error.append(error_validation)
    return sum(error) / f


def global_parameter_h(x_tra, y_tra, f, d):
    cv_compares, h_opt1s = [], []
    p1, p2 = 0.25, 0.75
    print('initial p1,p2:', p1, p2)
    for i in range(3, 13):
        cv_p1 = cv_global_h(x_tra, y_tra, f, p1, d)
        cv_p2 = cv_global_h(x_tra, y_tra, f, p2, d)

        if cv_p1 <= cv_p2:
            cv_compare, h_opt1 = cv_p1, p1
            p1, p2 = p1 - 2 ** (-i), p1 + 2 ** (-i)
        else:
            cv_compare, h_opt1 = cv_p2, p2
            p1, p2 = p2 - 2 ** (-i), p2 + 2 ** (-i)

        cv_compares.append(cv_compare)
        h_opt1s.append(h_opt1)

    index = cv_compares.index(min(cv_compares))
    h_opt = h_opt1s[index]
    return h_opt


'''2.2 prediction vector of the SHADOW model (global Gaussian LAR)'''
def prediction_vector_LAR(x_tra, y_tra, x_tes, y_tes, h, d, s):
    n = x_tra.shape[0]
    t = x_tes.shape[0]
    x_tra_T = x_tra.T
    x_tra_T = np.reshape(x_tra_T, (1, d, n), order='A')
    x_tra_T = np.repeat(x_tra_T, t, axis=0)
    x_tes_T = np.reshape(x_tes, (t, d, 1))
    x_tes_T = np.repeat(x_tes_T, n, axis=2)
    dis = (x_tes_T - x_tra_T) / h
    dis_norm = (np.linalg.norm(dis, axis=1)) ** s
    weight = np.exp(-dis_norm)
    a0 = np.dot(weight, y_tra)
    b0 = np.sum(weight)
    fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)
    loss = (fit - y_tes) ** 2
    return np.abs(fit), loss


'''
3. The three MIA prediction functions on the DISTRIBUTED (hybrid) system.
   adapt_gau / adapt_epan / adapt_nai / adapt_knn are the per-trial dicts
   {fen: array} from trails_d{1,5}_hybrid.npy  (keys normalized to int).
'''


def hybrid_algorithm_central_forMIA(x_tra, y_tra, x_tes1, y_tes, m, fen_now,
                                    adapt_gau, adapt_epan, adapt_nai, adapt_knn, d):
    """CENTRAL adversary: the full QDLAR aggregate (log mechanism +
    qualification rule) on arbitrary samples x_tes1."""
    b = mblocks(x_tra, y_tra, m)
    n1 = len(x_tes1)
    fit_blocks = np.zeros((n1, m))
    active_m = np.zeros(n1)
    random.seed(0)
    for i in range(m):
        assign = random.randint(1, 4)
        b_x = np.array(b.loc[i]['block_x'])
        b_y = np.array(b.loc[i]['block_y'])
        x_tes = np.array(x_tes1)              # ensure x_tes.shape: (t, d) each time
        n = b_x.shape[0]
        t = x_tes.shape[0]

        # transform: (t, d, n)
        x_tes = np.reshape(x_tes, (t, d, 1))
        x_tes = np.repeat(x_tes, n, axis=2)
        b_x = b_x.T
        b_x = np.reshape(b_x, (1, d, n), order='A')
        b_x = np.repeat(b_x, t, axis=0)
        LOG = math.log(len(x_tra), n)         # logarithmic operator

        # gaussian kernel, s=2
        if assign == 1:
            h = adapt_gau[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
            weight = np.exp((-dis_norm))
            a0 = np.dot(weight, b_y)
            b0 = np.sum(weight, axis=1)
            fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)

            # qualifing
            active = np.where(abs(fit) >= 1 / len(x_tra), 1, 0)
            active = np.squeeze(active)
            active_m += active
            fit = fit * active.reshape(n1, 1)
            fit_blocks[:, i] = np.squeeze(fit)

        # Epan kernel
        if assign == 2:
            h = adapt_epan[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
            weight = np.where((1 - dis_norm) > 0, 1 - dis_norm, 0)
            a1 = np.dot(weight, b_y)
            b1 = np.sum(weight, axis=1)
            fit = np.divide(a1, b1, out=np.zeros_like(a1, dtype=np.float64), where=b1 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)

            # qualifing
            active = np.where(abs(fit) >= 1 / len(x_tra), 1, 0)
            active = np.squeeze(active)
            active_m += active
            fit = fit * active.reshape(n1, 1)
            fit_blocks[:, i] = np.squeeze(fit)

        # naive kernel
        if assign == 3:
            h = adapt_nai[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = np.linalg.norm(dis, axis=1)
            weight = np.where(dis_norm <= 1, 1, 0)
            a2 = np.dot(weight, b_y)
            b2 = np.sum(weight, axis=1)
            fit = np.divide(a2, b2, out=np.zeros_like(a2, dtype=np.float64), where=b2 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)

            # qualifing
            active = np.where(abs(fit) >= 1 / len(x_tra), 1, 0)
            active = np.squeeze(active)
            active_m += active
            fit = fit * active.reshape(n1, 1)
            fit_blocks[:, i] = np.squeeze(fit)

        # knn
        if assign == 4:
            k = ((adapt_knn[fen_now][i]) ** LOG) / m
            k = math.ceil(k)

            dis = (x_tes - b_x)
            dis_norm = np.linalg.norm(dis, axis=1)
            index = np.argsort(dis_norm, axis=1)
            y_knn = b_y[index]
            y_knn = y_knn[:, :k]
            fit = (np.sum(y_knn, -1)) / k
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)

            # qualifing
            active = np.where(abs(fit) >= 1 / len(x_tra), 1, 0)
            active = np.squeeze(active)
            active_m += active
            fit = fit * (active.reshape(n1, 1))
            fit_blocks[:, i] = np.squeeze(fit)

    a3 = np.sum(fit_blocks, axis=1)
    b3 = active_m
    fit_global = np.divide(a3, b3, out=np.zeros_like(a3, dtype=np.float64), where=b3 != 0)
    loss = (fit_global - y_tes) ** 2
    return np.abs(fit_global), loss


def hybrid_algorithm_test_central_forMIA(x_tra, y_tra, x_tes, y_tes,
                                         adapt_gau, adapt_epan, adapt_nai, adapt_knn,
                                         d, gap, fen_num):
    for i in range(fen_num, fen_num + 1):
        m = (i + 1) * gap       # blocks number
        fen_now = i
        print('fen_now: %s, m:%s' % (fen_now, m))
        fit_abs_value, loss_value = hybrid_algorithm_central_forMIA(
            x_tra, y_tra, x_tes, y_tes, m, fen_now,
            adapt_gau, adapt_epan, adapt_nai, adapt_knn, d)
    return fit_abs_value, loss_value


def hybrid_algorithm_local_forMIA(x_tra, y_tra, m, fen_now,
                                  adapt_gau, adapt_epan, adapt_nai, adapt_knn, d):
    """LOCAL adversary: predictions of ALL m agents on party 1's OWN block
    (the member samples).  NO qualification rule -- the local adversary sees
    the raw output of its own local model."""
    b = mblocks(x_tra, y_tra, m)

    # attack the party with the most data; under the same-size setting this is
    # simply the first party -> build the prediction vector on block 0
    x_tes1 = np.array(b.loc[0]['block_x'])
    y_tes = np.array(b.loc[0]['block_y'])
    n1 = len(x_tes1)
    fit_blocks = np.zeros((n1, m))
    random.seed(0)
    for i in range(m):
        assign = random.randint(1, 4)
        b_x = np.array(b.loc[i]['block_x'])
        b_y = np.array(b.loc[i]['block_y'])
        x_tes = np.array(x_tes1)              # ensure x_tes.shape: (t, d) each time
        n = b_x.shape[0]
        t = x_tes.shape[0]

        # transform: (t, d, n)
        x_tes = np.reshape(x_tes, (t, d, 1))
        x_tes = np.repeat(x_tes, n, axis=2)
        b_x = b_x.T
        b_x = np.reshape(b_x, (1, d, n), order='A')
        b_x = np.repeat(b_x, t, axis=0)
        LOG = math.log(len(x_tra), n)         # logarithmic operator

        # gaussian kernel, s=2
        if assign == 1:
            h = adapt_gau[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
            weight = np.exp((-dis_norm))
            a0 = np.dot(weight, b_y)
            b0 = np.sum(weight, axis=1)
            fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

        # Epan kernel
        if assign == 2:
            h = adapt_epan[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
            weight = np.where((1 - dis_norm) > 0, 1 - dis_norm, 0)
            a1 = np.dot(weight, b_y)
            b1 = np.sum(weight, axis=1)
            fit = np.divide(a1, b1, out=np.zeros_like(a1, dtype=np.float64), where=b1 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

        # naive kernel
        if assign == 3:
            h = adapt_nai[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = np.linalg.norm(dis, axis=1)
            weight = np.where(dis_norm <= 1, 1, 0)
            a2 = np.dot(weight, b_y)
            b2 = np.sum(weight, axis=1)
            fit = np.divide(a2, b2, out=np.zeros_like(a2, dtype=np.float64), where=b2 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

        # knn
        if assign == 4:
            k = ((adapt_knn[fen_now][i]) ** LOG) / m
            k = math.ceil(k)

            dis = (x_tes - b_x)
            dis_norm = np.linalg.norm(dis, axis=1)
            index = np.argsort(dis_norm, axis=1)
            y_knn = b_y[index]
            y_knn = y_knn[:, :k]
            fit = (np.sum(y_knn, -1)) / k
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

    fit_blocks_abs = np.abs(fit_blocks)
    y_tes_block = np.repeat(y_tes[:, None], m, axis=1)
    loss = (fit_blocks - y_tes_block) ** 2
    return fit_blocks_abs, loss


def hybrid_algorithm_test_local_forMIA(x_tra, y_tra,
                                       adapt_gau, adapt_epan, adapt_nai, adapt_knn,
                                       d, gap, fen_num):
    for i in range(fen_num, fen_num + 1):
        m = (i + 1) * gap       # blocks number
        fen_now = i
        fit_abs_value, loss_value = hybrid_algorithm_local_forMIA(
            x_tra, y_tra, m, fen_now,
            adapt_gau, adapt_epan, adapt_nai, adapt_knn, d)
    # party 1's OWN model = column 0
    return fit_abs_value[:, 0], loss_value[:, 0]


def hybrid_algorithm_local_forMIA_non_v(x_tra, y_tra, x_tes1, y_tes, m, fen_now,
                                        adapt_gau, adapt_epan, adapt_nai, adapt_knn, d):
    """LOCAL adversary: predictions of ALL m agents on NON-MEMBER samples
    (same vectorization as the member version, no qualification rule)."""
    b = mblocks(x_tra, y_tra, m)
    n1 = len(x_tes1)
    fit_blocks = np.zeros((n1, m))
    random.seed(0)
    for i in range(m):
        assign = random.randint(1, 4)
        b_x = np.array(b.loc[i]['block_x'])
        b_y = np.array(b.loc[i]['block_y'])
        x_tes = np.array(x_tes1)              # ensure x_tes.shape: (t, d) each time
        n = b_x.shape[0]
        t = x_tes.shape[0]

        # transform: (t, d, n)
        x_tes = np.reshape(x_tes, (t, d, 1))
        x_tes = np.repeat(x_tes, n, axis=2)
        b_x = b_x.T
        b_x = np.reshape(b_x, (1, d, n), order='A')
        b_x = np.repeat(b_x, t, axis=0)
        LOG = math.log(len(x_tra), n)         # logarithmic operator

        # gaussian kernel, s=2
        if assign == 1:
            h = adapt_gau[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
            weight = np.exp((-dis_norm))
            a0 = np.dot(weight, b_y)
            b0 = np.sum(weight, axis=1)
            fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

        # Epan kernel
        if assign == 2:
            h = adapt_epan[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
            weight = np.where((1 - dis_norm) > 0, 1 - dis_norm, 0)
            a1 = np.dot(weight, b_y)
            b1 = np.sum(weight, axis=1)
            fit = np.divide(a1, b1, out=np.zeros_like(a1, dtype=np.float64), where=b1 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

        # naive kernel
        if assign == 3:
            h = adapt_nai[fen_now][i] ** LOG
            h = min(1, h)

            dis = (x_tes - b_x) / h
            dis_norm = np.linalg.norm(dis, axis=1)
            weight = np.where(dis_norm <= 1, 1, 0)
            a2 = np.dot(weight, b_y)
            b2 = np.sum(weight, axis=1)
            fit = np.divide(a2, b2, out=np.zeros_like(a2, dtype=np.float64), where=b2 != 0)
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

        # knn
        if assign == 4:
            k = ((adapt_knn[fen_now][i]) ** LOG) / m
            k = math.ceil(k)

            dis = (x_tes - b_x)
            dis_norm = np.linalg.norm(dis, axis=1)
            index = np.argsort(dis_norm, axis=1)
            y_knn = b_y[index]
            y_knn = y_knn[:, :k]
            fit = (np.sum(y_knn, -1)) / k
            fit = np.reshape(fit, (-1, 1))
            fit = np.nan_to_num(fit)
            fit_blocks[:, i] = np.squeeze(fit)

    fit_blocks_abs = np.abs(fit_blocks)
    y_tes_block = np.repeat(y_tes[:, None], m, axis=1)
    loss = (fit_blocks - y_tes_block) ** 2
    return fit_blocks_abs, loss


def hybrid_algorithm_test_local_forMIA_non_v(x_tra, y_tra, x_tes1, y_tes,
                                             adapt_gau, adapt_epan, adapt_nai, adapt_knn,
                                             d, gap, fen_num):
    for i in range(fen_num, fen_num + 1):
        m = (i + 1) * gap       # blocks number
        fen_now = i
        fit_abs_value, loss_value = hybrid_algorithm_local_forMIA_non_v(
            x_tra, y_tra, x_tes1, y_tes, m, fen_now,
            adapt_gau, adapt_epan, adapt_nai, adapt_knn, d)
    # party 1's OWN model = column 0
    return fit_abs_value[:, 0], loss_value[:, 0]
