# Paper: Appendix Figure 5b (Section C.5, practitioner freedom / algorithm autonomy).
# Formerly: Simulation/simulation_d5_mix.py -> hybrid_d5_AE_compare.pdf
# Reads root-level Result_data/trails_d5_hybrid.npy; run from this folder.
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import time, os
time_start = time.time()

from matplotlib import rcParams
fontsize_specific = 18
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
'''1. load data'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid.npy', allow_pickle=True)
trails_d5_hybrid = loadData.tolist()
AE_lc_epan_mean = np.mean(loadData.tolist()['AE_lc_epan'], axis=1)
AE_lc_gau_mean = np.mean(loadData.tolist()['AE_lc_gau'], axis=1)
AE_lc_naive_mean = np.mean(loadData.tolist()['AE_lc_naive'], axis=1)
AE_lc_knn_mean = np.mean(loadData.tolist()['AE_lc_k'], axis=1)
AE_lc_hybrid_mean = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)
GE_gau_mean = [np.mean(loadData.tolist()['GE_gau'])] * 70


'''figure 1: compare the AE_log_active on each algorithm'''
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# M_nwk = [i for i in range(5, 355, 5)]
#
# # marker = 'd', linestyle = '--', linewidth = 1.4, markersize = 4
# ax.plot(M_nwk, AE_lc_knn_mean, c='forestgreen', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, AE_lc_naive_mean, c='forestgreen', linestyle='--', linewidth=2.0)
# ax.plot(M_nwk, AE_lc_epan_mean, c='royalblue', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, AE_lc_gau_mean, c='royalblue', linestyle='--', linewidth=2.0)
# ax.plot(M_nwk, AE_lc_hybrid_mean, c='brown', linestyle='--', linewidth=2.0)
# ax.plot(M_nwk, GE_gau_mean, c='black', linestyle='--', linewidth=2.0)
# plt.legend(['$AE_{active, Knn}$', '$AE_{active, Naive}$', '$AE_{active, Epan}$', '$AE_{active, Gau}$', '$AE_{active, Hybrid}$', '$GE_{Gau}$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE', fontsize='18')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/hybrid_d5_AE_compare.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


# 💎 💎 💎 💎
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
M_nwk = [i for i in range(5, 355, 5)]


M_nwk_sampled = M_nwk[::2]
AE_lc_knn_mean_sampled = AE_lc_knn_mean[::2]
AE_lc_naive_mean_sampled = AE_lc_naive_mean[::2]
AE_lc_epan_mean_sampled = AE_lc_epan_mean[::2]
AE_lc_gau_mean_sampled = AE_lc_gau_mean[::2]
AE_lc_hybrid_mean_sampled = AE_lc_hybrid_mean[::2]
GE_gau_mean_sampled = GE_gau_mean[::2]

ax.plot(M_nwk_sampled, AE_lc_knn_mean_sampled, c='forestgreen', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk_sampled, AE_lc_naive_mean_sampled, c='darkcyan', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk_sampled, AE_lc_epan_mean_sampled, c='tomato', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk_sampled, AE_lc_gau_mean_sampled, c='darkslateblue', marker='o',  linestyle='-', linewidth=1.2, markersize=4)
ax.plot(M_nwk_sampled, AE_lc_hybrid_mean_sampled, c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
ax.plot(M_nwk_sampled, GE_gau_mean_sampled, c='black', marker='s',  linestyle='-', linewidth=1.2, markersize=4)


plt.legend(['$AE_\mathrm{active, Knn}$', '$AE_\mathrm{active, Naive}$', '$AE_\mathrm{active, Epan}$', '$AE_\mathrm{active, Gau}$', '$AE_\mathrm{active, hybrid}$', '$GE_\mathrm{Gau}$'],  ncol=1, loc='upper left', fontsize='15')
ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
ax.set_ylabel('MSE', fontsize='18')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C5/hybrid_d5_AE_compare.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()



'''figure 2: prove the effective of hybrid algorithm. Compare the LE on each algorithm, GE as our baseline.'''
# (1) save LE of each algorithm to trails_d1_hybrid.npy
# loadData_epan = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_epan.npy', allow_pickle=True)
# loadData_gau = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_gau2.npy', allow_pickle=True)
# loadData_naive = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_naive.npy', allow_pickle=True)
# loadData_knn = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_knn.npy', allow_pickle=True)
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid.npy', allow_pickle=True)
# trails_d5_hybrid = loadData.tolist()
# trails_d5_hybrid['LE_epan'] = loadData_epan.tolist()['LEs']
# trails_d5_hybrid['LE_gau'] = loadData_gau.tolist()['LEs']
# trails_d5_hybrid['LE_naive'] = loadData_naive.tolist()['LEs']
# trails_d5_hybrid['LE_knn'] = loadData_knn.tolist()['LEs_m20']    # (19,20)
# trails_d5_hybrid['GE_gau'] = loadData_gau.tolist()['GEs']
# np.save(os.path.dirname(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid.npy', trails_d5_hybrid)
# print('save trails_d5_hybrid.npy done')


# (2) load data and plot
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid.npy', allow_pickle=True)
# trails_d5_hybrid = loadData.tolist()
# LE_epan_mean = np.mean(loadData.tolist()['LE_epan'], axis=1)
# LE_gau_mean = np.mean(loadData.tolist()['LE_gau'], axis=1)
# LE_naive_mean = np.mean(loadData.tolist()['LE_naive'], axis=1)
# LE_knn_mean = np.mean(loadData.tolist()['LE_knn'], axis=1)       # m = 1,2,...,20, we select the result on m = 5,10, 15, 20 for comparison
# LE_knn_mean_select = [0.0018711608372959127, 0.003481820414497395, 0.0053805140493376384, 0.0070700836248287794]  #
# GE_gau_mean = [np.mean(loadData.tolist()['GE_gau'])] * 4
# AE_lc_hybrid_mean = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)
# print(LE_knn_mean)
#
# M_nwk = [i for i in range(5, 21, 5)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(M_nwk, LE_knn_mean[:4], c='forestgreen', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, LE_naive_mean[:4], c='forestgreen', linestyle='--', linewidth=2.0)
# ax.plot(M_nwk, LE_epan_mean[:4], c='royalblue', linestyle=':', linewidth=2.0)
# ax.plot(M_nwk, LE_gau_mean[:4], c='royalblue', linestyle='--', linewidth=2.0)
# ax.plot(M_nwk, AE_lc_hybrid_mean[:4], c='brown', linestyle='--', linewidth=2.0)
# # ax.plot(M_nwk, GE_gau_mean, c='black', linestyle='--', linewidth=2.0)
# plt.legend(['$LE_{opt, Knn}$', '$LE_{opt, Naive}$', '$LE_{opt, Epan}$', '$LE_{opt, Gau}$', '$AE_{active, Hybrid}$'], loc='upper left', fontsize='medium')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='13')
# ax.set_ylabel('MSE', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/hybrid_d5_LE_compare.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


'''figure 3: MSE changes with generalization degree, when blocks number = 50 '''
# # the earliest version: here we use generalization degree as the privacy measure rather than the tree depth
# AE_lc_hybrid_mean_m50 = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)[9]     # select the result when m=50
# AE_lc_hybrid_pri1_mean = np.mean(loadData.tolist()['AE_lc_hybrid_pri1'], axis=1)  # perturb the first dimension
# AE_lc_hybrid_pri5_mean = np.mean(loadData.tolist()['AE_lc_hybrid_pri5'], axis=1)  # perturb all the five dimensions
# gen_num_forpri = loadData.tolist()['gen_num_forpri']
#
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(gen_num_forpri, AE_lc_hybrid_pri1_mean, c='royalblue', linestyle='--', linewidth=1.4)
# ax.plot(gen_num_forpri, AE_lc_hybrid_pri5_mean, c='royalblue', linestyle=':', linewidth=1.4)
# ax.plot(gen_num_forpri, [AE_lc_hybrid_mean_m50]*100, c='black', linestyle='-.', linewidth=1.4)
# plt.axvline(x=10,ls="-",c="green", linewidth=1.2)
# plt.legend(['hybrid_pri(1d)', 'hybrid_pri(5d)', 'hybrid_ori'], loc='upper left', fontsize='medium')
# ax.set_xlabel('Generalization degree \n(d=5, m = 50, same block size)', fontsize='13')
# ax.set_ylabel('MSE', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/MSE_gene_d5_TQMA.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


'''figure 4: MSE changes with tree depth, when blocks number = 50 '''
# hybrid_ori_mean_m50 = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)[9]   # hybrid_pri when m = 50
# MSE_TQMA_mean_m50 = np.mean(loadData.tolist()['MSE_TQMA'], axis=1)
# depth = [i for i in range(1, 11, 1)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
#
# ax.plot(depth, MSE_TQMA_mean_m50, c='royalblue', linestyle='--', linewidth=2.0)
# ax.plot(depth, [hybrid_ori_mean_m50]*10, c='black', linestyle='-.', linewidth=2.0)
# # plt.axvline(x=25,ls="-",c="green", linewidth=1.2)
# plt.legend(['$AE_{active, pri}$', '$AE_{active, ori}$'], loc='upper left', fontsize='medium')
# ax.set_ylabel('MSE', fontsize='13')
# ax.set_xlabel('Tree depth', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/MSE_depth_d5_TQMA.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


'''figure 5: MSE changes with RL, when blocks number = 50 '''
# hybrid_ori_mean_m50 = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)[9]   # hybrid_pri when m = 50
# MSE_TQMA_mean_m50 = np.mean(loadData.tolist()['MSE_TQMA'], axis=1)
# RL_TQMA_mean_m50 = np.mean(loadData.tolist()['RL_TQMA'], axis = 0)
#
# depth = [i for i in range(1, 11, 1)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
#
# ax.plot(RL_TQMA_mean_m50, MSE_TQMA_mean_m50, c='royalblue', linestyle='--', linewidth=2.0)
# ax.plot(RL_TQMA_mean_m50, [hybrid_ori_mean_m50]*10, c='black', linestyle='-.', linewidth=2.0)
# # plt.axvline(x=25,ls="-",c="green", linewidth=1.2)
# plt.legend(['$AE_{active, pri}$', '$AE_{active, ori}$'], loc='upper left', fontsize='medium')
# ax.set_ylabel('MSE', fontsize='13')
# ax.set_xlabel('RL', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/MSE_RL_d5_TQMA.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


'''figure 6: conpare the MSE of same block size and different block size'''
# loadData_gau = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_gau2.npy', allow_pickle=True)
# trails_d5_gau2 = loadData_gau.tolist()
# LE_diff_gau = np.mean(trails_d5_gau2['LE_adapts'], axis=1)
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid.npy', allow_pickle=True)
# trails_d5_hybrid = loadData.tolist()
# LE_hybrid_diff = np.mean(loadData.tolist()['LE_hybrid_diff'], axis=1)   # LE_adapt of hybird algorithm
# AE_lc_hybrid = np.mean(loadData.tolist()['AE_lc_hybrid'], axis=1)
# # AE_lc_hybrid_diff = np.mean(loadData.tolist()['AE_lc_hybrid_diff'], axis=1)
# AE_lc_hybrid_diff = np.mean(loadData.tolist()['AE_lc_hybrid_diff'], axis=1)
#
# GE_gau = [np.mean(trails_d5_gau2['GEs'])] * 70
#
# print(trails_d5_hybrid.keys())
# M_nwk = [i for i in range(5, 351, 5)]
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
# ax.plot(M_nwk, LE_diff_gau, c='forestgreen', linestyle=':', linewidth=1.4)
# ax.plot(M_nwk, LE_hybrid_diff, c='forestgreen', linestyle='-.', linewidth=1.4)
# ax.plot(M_nwk, AE_lc_hybrid_diff, c='brown', linestyle='-.', linewidth=1.4)
# ax.plot(M_nwk, AE_lc_hybrid, c='royalblue', linestyle='-.', linewidth=1.4)
# ax.plot(M_nwk, GE_gau, c='black', linestyle='-.', linewidth=1.4)
# # plt.axvline(x=25,ls="-",c="green", linewidth=1.2)
# plt.legend(['LE_adapt_gau', 'LE_adapt', 'Hybrid_diff', 'Hybrid_same', 'GE_gau'], loc='upper left', fontsize='medium')
# ax.set_ylabel('MSE', fontsize='13')
# ax.set_xlabel('Blocks number \n(d=5)', fontsize='13')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/compare_same_diff_size_d5.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()

