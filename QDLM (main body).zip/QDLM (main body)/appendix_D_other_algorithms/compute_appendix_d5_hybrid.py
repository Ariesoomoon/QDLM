import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.Function_same_block_ML import generate_data, hybrid_algorithm_test
#from common.Function_diff_block import generate_data, hybrid_algorithm_test, MSE_pri_TQMA, LE_hybrid_algorithm_test
import numpy as np
time_start = time.time()



'''1. on original data'''
# 1.1 load local_h or local_k parameter of each algorithm, and save all of them in appendix_d5_hybrid.npy
# loadData_gau = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_gau2.npy', allow_pickle=True)
# loadData_krr = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_krr.npy', allow_pickle=True)
# loadData_boost = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_boost.npy', allow_pickle=True)
# loadData_rf = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_rf.npy', allow_pickle=True)
# loadData_RT = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_Rtree.npy', allow_pickle=True)
#
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_hybrid.npy', allow_pickle=True)
# appendix_d5_hybrid = loadData.tolist()
#
# # appendix_d5_hybrid = {}
# # appendix_d5_hybrid['l_h_gau'] = loadData_gau.tolist()['local_h']
# # appendix_d5_hybrid['l_lambda_krr'] = loadData_krr.tolist()['l_lambda']
# # appendix_d5_hybrid['l_t_boost'] = loadData_boost.tolist()['l_t']
# # appendix_d5_hybrid['l_t_rf'] = loadData_rf.tolist()['l_t']
# appendix_d5_hybrid['l_t_RT'] = loadData_RT.tolist()['l_t']
#
# # appendix_d5_hybrid['AE_active_gau'] = loadData_gau.tolist()['AE_log_actives']
# # appendix_d5_hybrid['AE_active_krr'] = loadData_krr.tolist()['AE_log_actives']
# # appendix_d5_hybrid['AE_active_boost'] = loadData_boost.tolist()['AE_log_actives']
# # appendix_d5_hybrid['AE_active_rf'] = loadData_rf.tolist()['AE_log_actives']
# appendix_d5_hybrid['AE_active_RT'] = loadData_RT.tolist()['AE_log_actives']
# # appendix_d5_hybrid['GE_gau'] = loadData_gau.tolist()['GEs']
#
# # appendix_d5_hybrid['LE_opt_gau'] = loadData_gau.tolist()['LEs']
# # appendix_d5_hybrid['LE_opt_krr'] = loadData_krr.tolist()['LEs']
# # appendix_d5_hybrid['LE_opt_boost'] = loadData_boost.tolist()['LEs']
# # appendix_d5_hybrid['LE_opt_rf'] = loadData_rf.tolist()['LEs']
# appendix_d5_hybrid['LE_opt_RT'] = loadData_RT.tolist()['LEs']
#
#
# # loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_hybrid.npy', allow_pickle=True)
# # appendix_d5_hybrid = loadData.tolist()
# # appendix_d5_hybrid['GE_boost'] = loadData_boost.tolist()['GEs']
#
#
# print(appendix_d5_hybrid.keys())
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_hybrid.npy', appendix_d5_hybrid)
# print('save appendix_d5_hybrid.npy done')


# 所以我们选择最小的boost的GE作为baseline：
# GEs_mean of krr     # 0.0023785381482021124   3
# GEs_mean of boost   # 0.0015759364947267752   1
# GEs_mean of rf      # 0.0021728341236362534   2




# 1.2. Initialization
f = 5                  # cv-5
trails = 20
train, test, d = (2000,5), (1000,5), 5
fen_num, gap = 20, 2   # blocks num: 5, 10, ..., 350
s = 2


loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_hybrid.npy', allow_pickle=True)
appendix_d5_hybrid = loadData.tolist()
adapt_gau = loadData.tolist()['l_h_gau']
adapt_krr = loadData.tolist()['l_lambda_krr']
adapt_boost = loadData.tolist()['l_t_boost']
adapt_rf = loadData.tolist()['l_t_rf']
adapt_RT = loadData.tolist()['l_t_RT']

AE_active_hybrid = np.empty(shape=(20, 20))
print(appendix_d5_hybrid.keys())


# 1.3. Calculating the hybrid algorithm
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    # (1) create data and load parameter
    X_train, y_train, X_test, y_test = generate_data(train, test, d)

    adapt_gau_1 = adapt_gau[th]
    adapt_krr_1 = adapt_krr[th]
    adapt_boost_1 = adapt_boost[th]
    adapt_rf_1 = adapt_rf[th]

    adapt_RT_1 = adapt_RT[th]

    print('The first training data, X_train[0]: %s, y_train[0]: %s' % (X_train[0], y_train[0]))
    AE = hybrid_algorithm_test(X_train, y_train, X_test, y_test, adapt_krr_1, adapt_boost_1, adapt_rf_1, adapt_RT_1, d, gap, fen_num)
    AE = np.array(AE)
    AE_active_hybrid[:, th] = np.squeeze(AE)


# appendix_d5_hybrid['AE_active_hybrid'] = AE_active_hybrid
appendix_d5_hybrid['AE_active_hybrid_new'] = AE_active_hybrid

np.save(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_hybrid.npy', appendix_d5_hybrid)
print('save appendix_d5_hybrid.npy done')
time_total = time.time() - time_start
print('runing time:', time_total)



