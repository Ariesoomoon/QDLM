import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.Function_same_block_ML import generate_data, GE_gaussiank, LE_gaussiank_test, AE_gaussiank_test, AE_adapt_gaussiank_test, \
    AE_active_gaussiank_test, Predictedkrr, LE_krr_test, AE_krr_opt_test, AE_adapt_krr_test, AE_active_krr_test, LE_krr_adapt_test,\
    AE_active_krr_diff_test

# from common.Function_diff_block import generate_data, GE_gaussiank, LE_gaussiank_test, AE_gaussiank_test, \
#     AE_adapt_gaussiank_test, AE_active_gaussiank_test, LE_gaussiank_adapt_test
import numpy as np
time_start = time.time()

'''0. remember to choose the Function_same_block_gau.py or Function_diff_block_warfarin.py, 
and use the corresponding localization parameters: local_h or local_diff_h !!!!'''


'''1. Initialization'''
f = 5                  # cv-5
trails = 20
train, test, d = (2000,5), (1000,5), 5
fen_num, gap = 20, 2   # blocks num: 5, 10, ..., 350
s = 2                  # for gaussian kernel, s = 1,2,3, here just choose s = 2

loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_krr.npy', allow_pickle=True)
appendix_d5_krr = loadData.tolist()
print(appendix_d5_krr.keys())

# load the localization parameters
g_lambdas = appendix_d5_krr['g_lambda']
l_lambdas = appendix_d5_krr['l_lambda']
l_lambdas_diff = appendix_d5_krr['l_lambda_diff']


# 70 type of divisions, 20trails, average by axis=1(by trail axis)
GEs = []
AEs = np.empty(shape=(20, 20))
LEs = np.empty(shape=(20, 20))
AE_adapts = np.empty(shape=(20, 20))
AE_logs = np.empty(shape=(20, 20))
AE_log_actives = np.empty(shape=(20, 20))
LE_adapt_opts = np.empty(shape=(20, 20))
AE_log_actives_diff = np.empty(shape=(20, 20))


'''2. 20 trails: calculating the MSE of GE, LE, AE(with h given global), AE_adapt, AE_log, AE_log_active with gaussian kernel'''
for th in range(trails):
    np.random.seed(th)
    print('                                                                                  trail:', th + 1)
    # (1) create data and load parameter
    X_train, y_train, X_test, y_test = generate_data(train, test, d)
    g_lambda = g_lambdas[th]    # for th trail, select the corresponding global_h[th]
    l_lambda = l_lambdas[th]
    l_lambda_diff = l_lambdas_diff[th]

    # print('g_lambda:', g_lambda)
    # print('l_lambda[trail][0]:', l_lambda[0])
    # print('--------------------------------------------------------------------------------')

    # (2) calculating
    GE = Predictedkrr(X_train, y_train, X_test, y_test, d, g_lambda)[1]
    GEs.append(GE)
    print('GEs:', GEs)


    LE = LE_krr_test(X_train, y_train, X_test, y_test, fen_num, gap, g_lambda, d)
    LE = np.array(LE)
    LEs[:, th] = np.squeeze(LE)


    AE = AE_krr_opt_test(X_train, y_train, X_test, y_test, fen_num, gap, g_lambda, d)
    AE = np.array(AE)
    AEs[:, th] = np.squeeze(AE)


    AE_log = AE_adapt_krr_test(X_train, y_train, X_test, y_test, d, fen_num, gap, l_lambda)
    AE_log = np.array(AE_log)
    AE_logs[:, th] = np.squeeze(AE_log)


    a = AE_active_krr_test(X_train, y_train, X_test, y_test, d, fen_num, gap, l_lambda)
    AE_log_active = a[0]
    AE_log_active = np.array(AE_log_active)
    AE_log_actives[:, th] = np.squeeze(AE_log_active)

    # diff情况下 ---------
    LE_adapt_opt = LE_krr_adapt_test(X_train, y_train, X_test, y_test, fen_num, gap, l_lambda_diff, d)
    LE_adapt_opt = np.array(LE_adapt_opt)
    LE_adapt_opts[:, th] = np.squeeze(LE_adapt_opt)

    a1 = AE_active_krr_diff_test(X_train, y_train, X_test, y_test, d, fen_num, gap, l_lambda_diff)
    AE_log_active_diff = a1[0]
    AE_log_active_diff = np.array(AE_log_active_diff)
    AE_log_actives_diff[:, th] = np.squeeze(AE_log_active_diff)


'''3. save MSE'''
appendix_d5_krr['GEs'] = GEs
appendix_d5_krr['LEs'] = LEs     # LE_opt--用的是全局的参数
appendix_d5_krr['AEs'] = AEs     # AE_opt--用的是全局的参数
appendix_d5_krr['AE_logs'] = AE_logs # 用的是自己的参数
appendix_d5_krr['AE_log_actives'] = AE_log_actives

appendix_d5_krr['LE_adapt_opts'] = LE_adapt_opts  # ⚠️diff设置下,用自己的参数，再opt
appendix_d5_krr['AE_log_actives_diff'] = AE_log_actives_diff


np.save(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_krr.npy', appendix_d5_krr)
print('--------------------------------------------------------------save appendix_d5_krr.npy done')
print(appendix_d5_krr.keys())
time_total = time.time() - time_start
print('runing time:', time_total)





'''结果记录：


'''
