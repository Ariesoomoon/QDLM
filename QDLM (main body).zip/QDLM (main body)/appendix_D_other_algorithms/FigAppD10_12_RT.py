import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import os


from matplotlib import rcParams
fontsize_specific = 16
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)
'''1. load data'''
loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/appendix_d5_Rtree.npy', allow_pickle=True)
appendix_d5_Rtree = loadData.tolist()
print(appendix_d5_Rtree.keys())

GEs_mean = [np.mean(appendix_d5_Rtree['GEs'])] * 20
AEs_mean = np.mean(appendix_d5_Rtree['AEs'], axis=1)  # average AE, LE, GE of 20 trails, axis=1 means averaging on trail axis
LEs_mean = np.mean(appendix_d5_Rtree['LEs'], axis=1)
AE_logs_mean = np.mean(appendix_d5_Rtree['AE_logs'], axis=1)
AE_log_actives_mean = np.mean(appendix_d5_Rtree['AE_log_actives'], axis=1)
LE_adapt_opts_mean = np.mean(appendix_d5_Rtree['LE_adapt_opts'], axis=1)
AE_log_actives_diff_mean = np.mean(appendix_d5_Rtree['AE_log_actives_diff'], axis=1)
# GEs_mean = [np.mean(appendix_d5_Rtree['GEs_new'])] * 50
# AEs_mean = np.mean(appendix_d5_Rtree['AEs_new'], axis=1)  # average AE, LE, GE of 20 trails, axis=1 means averaging on trail axis
# LEs_mean = np.mean(appendix_d5_Rtree['LEs_new'], axis=1)
# AE_logs_mean = np.mean(appendix_d5_Rtree['AE_logs_new'], axis=1)
# AE_log_actives_mean = np.mean(appendix_d5_Rtree['AE_log_actives_new'], axis=1)
# LE_adapt_opts_mean = np.mean(appendix_d5_Rtree['LE_adapt_opts_new'], axis=1)
# AE_log_actives_diff_mean = np.mean(appendix_d5_Rtree['AE_log_actives_diff_new'], axis=1)


'''figure 1: h^log is effective'''
fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
num_agent = [i for i in range(2, 42, 2)]
# num_agent = [i for i in range(2, 102, 2)]
ax.plot(num_agent, GEs_mean, c='black', marker='s', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(num_agent, LEs_mean, c='forestgreen', marker='o', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(num_agent, AEs_mean, c='royalblue', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# ax.plot(num_agent, AE_adapts_mean, c='brown', linestyle=':', linewidth=2.0)
ax.plot(num_agent, AE_logs_mean, c='brown', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# ax.set_ylim(0.0015, 0.005)
# plt.axvline(x=150,ls="-",c="green", linewidth=2.0)
plt.legend(['$GE$', '$LE_\mathrm{opt}$', '$AE_\mathrm{opt}$', '$AE_\mathrm{log}$'], loc='upper left', fontsize='15')
ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
ax.set_ylabel('MSE (RT)', fontsize='18')
# plt.yscale('log')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/gau2_d5_log.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()

# # +logscale 小图
# left, bottom, width, height = 0.6, 0.55, 0.3, 0.25
# ax1 = fig.add_axes([left, bottom, width, height])
# # ax1.grid(linestyle='-.')
# num_agent = [i for i in range(2, 42, 2)]
# # num_agent = [i for i in range(2, 102, 2)]
# ax1.plot(num_agent, GEs_mean, c='black', linestyle='-.', linewidth=2.0)
# ax1.plot(num_agent, LEs_mean, c='royalblue', linestyle=':', linewidth=2.0)
# ax1.plot(num_agent, AEs_mean, c='royalblue', linestyle='--', linewidth=2.0)
# ax1.plot(num_agent, AE_logs_mean, c='brown', linestyle='--', linewidth=2.0)
# ax1.set_ylabel('log(MSE)')
# plt.yscale('log')
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_D/Rtree_d5_paraautonomy.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




'''figure 2: active rule is effective'''
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# num_agent = [i for i in range(2, 42, 2)]
# # num_agent = [i for i in range(2, 102, 2)]
# ax.set_ylim(0.0015, 0.01)
# ax.plot(num_agent, GEs_mean, c='black', marker='s', linestyle='-', linewidth=1.4, markersize=4)
# ax.plot(num_agent, AE_logs_mean, c='royalblue', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# ax.plot(num_agent, AE_log_actives_mean, c='brown', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# # ax.set_ylim(0.0001, 0.0003)
# plt.legend(['$GE$', '$AE_\mathrm{log}$', '$AE_\mathrm{active}$'], loc='upper left', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE (RT)', fontsize='18')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_D/Rtree_d5_activeeffective.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


'''figure 3: MSE of same block size and different block size'''
# fig = plt.figure(tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# num_agent = [i for i in range(2, 42, 2)]
# # num_agent = [i for i in range(2, 102, 2)]
# # ax.set_ylim(0.0015, 0.01)
# ax.plot(num_agent, LE_adapt_opts_mean, c='forestgreen', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# ax.plot(num_agent, AE_log_actives_mean, c='royalblue', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# ax.plot(num_agent, AE_log_actives_diff_mean, c='brown', marker='o', linestyle='-', linewidth=1.4, markersize=4)
# ax.plot(num_agent, GEs_mean, c='black', marker='s', linestyle='-', linewidth=1.4, markersize=4)
# # plt.ylim(0.00002, 0.00020)
# plt.legend(['$LE_\mathrm{adapt}$', '$AE_\mathrm{active,same}$', '$AE_\mathrm{active,diff}$', '$GE$'], loc='upper right', fontsize='15')
# ax.set_xlabel('Number of local agents ($d$=5)', fontsize='18')
# ax.set_ylabel('MSE (RT)', fontsize='18')
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_D/Rtree_d5_same_diff_compare.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()


