"""
================================================================================
Fig6_MIA_mean_attack_AUC.py  --  MIA Attack on LAR/NWK(Gaussian) (20 Trials)
Paper: Main Figure 6 (Section 6.2)

Run 20 independent trials, save all intermediate results to .npy file.
v2: also records each attack classifier's own predictive accuracy
    (3-fold CV on shadow data), and plots one figure per attack type with
    the attacker accuracy annotated under each bar.

The __main__ block loops over DIM = 1 and DIM = 5 (d1 + d5), reading
Result_data/MIA_d{DIM}_LAR_20trial.npy and writing one PDF per attack type
to Result_figure/sec6_2/.
================================================================================
"""

import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import warnings
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.Function_same_block import generate_data, global_parameter_h
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import cross_val_score
from sklearn.base import clone
from matplotlib import rcParams
config = {
    "font.family":'Times New Roman',
    "font.size": 17,
    "mathtext.fontset":'stix',
}
rcParams.update(config)

warnings.filterwarnings('ignore')

DIM = 1
N_TOTAL = 6000
N_VIC = 2000
N_ADV = 2000
N_NON1 = 1000
N_NON2 = 1000
N_BALANCED = 1000
CV_FOLD = 3
S = 2
M = 1
N_TRIALS = 20

SAVE_PATH = os.path.dirname(os.getcwd()) + '/Result_data'
os.makedirs(SAVE_PATH, exist_ok=True)
def save_file(dim):
    return SAVE_PATH + '/MIA_d%d_LAR_20trial.npy' % dim


def prediction_vector_LAR(x_tra, y_tra, x_tes, y_tes, h, d, s):
    n = x_tra.shape[0]
    t = x_tes.shape[0]
    x_tra_T = x_tra.T
    x_tra_T = np.reshape(x_tra_T, (1, d, n), order='A')
    x_tra_T = np.repeat(x_tra_T, t, axis=0)
    x_tes_T = np.reshape(x_tes, (t, d, 1))
    x_tes_T = np.repeat(x_tes_T, n, axis=2)
    dis = (x_tes_T - x_tra_T) / h
    dis_norm = (np.linalg.norm(dis, axis=1)) ** s
    weight = np.exp(-dis_norm)
    a0 = np.dot(weight, y_tra)
    b0 = np.sum(weight)
    fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)
    loss = (fit - y_tes) ** 2
    return np.abs(fit), loss


def run_single_trial(trial):
    np.random.seed(trial)
    X_all, y_all, _, _ = generate_data((N_TOTAL, DIM), (1000, DIM), DIM)
    X_vic = X_all[0:N_VIC]
    y_vic = y_all[0:N_VIC]
    X_adv = X_all[N_VIC:N_VIC + N_ADV]
    y_adv = y_all[N_VIC:N_VIC + N_ADV]
    X_non1 = X_all[N_VIC + N_ADV:N_VIC + N_ADV + N_NON1]
    y_non1 = y_all[N_VIC + N_ADV:N_VIC + N_ADV + N_NON1]
    X_non2 = X_all[N_VIC + N_ADV + N_NON1:]
    y_non2 = y_all[N_VIC + N_ADV + N_NON1:]

    h_vic = global_parameter_h(X_vic, y_vic, CV_FOLD, DIM)
    h_shadow = global_parameter_h(X_adv, y_adv, CV_FOLD, DIM)

    # Shadow features
    idx_adv = np.random.choice(len(X_adv), N_BALANCED, replace=False)
    X_adv_m = X_adv[idx_adv]
    y_adv_m = y_adv[idx_adv]
    fit_abs_mem_s, loss_mem_s = prediction_vector_LAR(X_adv, y_adv, X_adv_m, y_adv_m, h_shadow, DIM, S)
    fit_abs_non_s, loss_non_s = prediction_vector_LAR(X_adv, y_adv, X_non1, y_non1, h_shadow, DIM, S)

    # Victim features
    idx_vic = np.random.choice(len(X_vic), N_BALANCED, replace=False)
    X_vic_m = X_vic[idx_vic]
    y_vic_m = y_vic[idx_vic]
    fit_abs_mem_v, loss_mem_v = prediction_vector_LAR(X_vic, y_vic, X_vic_m, y_vic_m, h_vic, DIM, S)
    fit_abs_non_v, loss_non_v = prediction_vector_LAR(X_vic, y_vic, X_non2, y_non2, h_vic, DIM, S)

    # MIA attacks
    attack_names = ["Attack-I", "Attack-II", "Attack-III"]
    attack_features = ["mag", "loss", "combined"]
    clf_names = ["LR", "RF", "MLP"]
    auc_results = {}
    acc_results = {}   # attack classifier's own predictive accuracy

    for atk_name, atk_feat in zip(attack_names, attack_features):
        if atk_feat == "mag":
            X_tr = np.vstack([fit_abs_mem_s.reshape(-1,1), fit_abs_non_s.reshape(-1,1)])
            X_te = np.vstack([fit_abs_mem_v.reshape(-1,1), fit_abs_non_v.reshape(-1,1)])
        elif atk_feat == "loss":
            X_tr = np.vstack([loss_mem_s.reshape(-1,1), loss_non_s.reshape(-1,1)])
            X_te = np.vstack([loss_mem_v.reshape(-1,1), loss_non_v.reshape(-1,1)])
        else:
            X_tr = np.vstack([np.column_stack([fit_abs_mem_s, loss_mem_s]),
                              np.column_stack([fit_abs_non_s, loss_non_s])])
            X_te = np.vstack([np.column_stack([fit_abs_mem_v, loss_mem_v]),
                              np.column_stack([fit_abs_non_v, loss_non_v])])
        y_tr = np.hstack([np.ones(N_BALANCED), np.zeros(N_BALANCED)])
        y_te = np.hstack([np.ones(N_BALANCED), np.zeros(N_BALANCED)])

        for clf_name in clf_names:
            if clf_name == "LR":
                clf = LogisticRegression(max_iter=1000, random_state=trial)
            elif clf_name == "RF":
                clf = RandomForestClassifier(n_estimators=100, random_state=trial)
            else:
                clf = MLPClassifier(hidden_layer_sizes=(64,32), max_iter=500, random_state=trial)

            # --- attack classifier's own predictive performance:
            #     3-fold CV accuracy on the shadow (member vs non-member) task
            acc_cv = cross_val_score(clone(clf), X_tr, y_tr, cv=3,
                                     scoring='accuracy').mean()
            acc_results["%s_%s" % (clf_name, atk_name)] = float(acc_cv)

            # --- MIA evaluation on the victim model (unchanged)
            clf.fit(X_tr, y_tr)
            y_prob = clf.predict_proba(X_te)[:, 1]
            auc = roc_auc_score(y_te, y_prob)
            auc_results["%s_%s" % (clf_name, atk_name)] = auc

    return {
        'h_vic': h_vic, 'h_shadow': h_shadow,
        'victim_member_loss_mean': float(np.mean(loss_mem_v)),
        'victim_member_loss_std': float(np.std(loss_mem_v)),
        'victim_nonmember_loss_mean': float(np.mean(loss_non_v)),
        'victim_nonmember_loss_std': float(np.std(loss_non_v)),
        'AUC': auc_results,
        'ACC': acc_results
    }


def run_all_trials():
    time_start = time.time()
    print("=" * 75)
    print("  MIA Attack on LAR (d=%d) — 20 Trials" % DIM)
    print("=" * 75)

    MIA_d5 = {}
    MIA_d5['N_TRIALS'] = N_TRIALS
    MIA_d5['DIM'] = DIM

    for trial in range(N_TRIALS):
        print('\nTrial %d / %d' % (trial + 1, N_TRIALS))
        results = run_single_trial(trial)
        MIA_d5['trial_%d' % trial] = results
        print("  h_vic=%.4f h_shadow=%.4f" % (results['h_vic'], results['h_shadow']))
        auc = results['AUC']
        acc = results['ACC']
        print("  AUC: LR=[%.3f,%.3f,%.3f] RF=[%.3f,%.3f,%.3f] MLP=[%.3f,%.3f,%.3f]" % (
            auc['LR_Attack-I'], auc['LR_Attack-II'], auc['LR_Attack-III'],
            auc['RF_Attack-I'], auc['RF_Attack-II'], auc['RF_Attack-III'],
            auc['MLP_Attack-I'], auc['MLP_Attack-II'], auc['MLP_Attack-III']))
        print("  ACC: LR=[%.3f,%.3f,%.3f] RF=[%.3f,%.3f,%.3f] MLP=[%.3f,%.3f,%.3f]" % (
            acc['LR_Attack-I'], acc['LR_Attack-II'], acc['LR_Attack-III'],
            acc['RF_Attack-I'], acc['RF_Attack-II'], acc['RF_Attack-III'],
            acc['MLP_Attack-I'], acc['MLP_Attack-II'], acc['MLP_Attack-III']))

    np.save(save_file(DIM), MIA_d5)
    print('\nSaved: %s' % save_file(DIM))
    print('Time: %.1f seconds' % (time.time() - time_start))
    return MIA_d5


def load_and_plot():
    print('\nLoading and plotting...')
    loadData = np.load(save_file(DIM), allow_pickle=True)
    data = loadData.tolist()
    N = data['N_TRIALS']

    clf_names = ["LR", "RF", "MLP"]
    attack_names = ["Attack-I", "Attack-II", "Attack-III"]

    auc_mean, auc_std, acc_mean = {}, {}, {}
    for clf in clf_names:
        for atk in attack_names:
            key = "%s_%s" % (clf, atk)
            vals = [data['trial_%d' % t]['AUC'][key] for t in range(N)]
            auc_mean[key] = np.mean(vals)
            auc_std[key] = np.std(vals)
            # ACC only exists after re-running with this version
            acc_vals = [data['trial_%d' % t].get('ACC', {}).get(key, np.nan)
                        for t in range(N)]
            acc_mean[key] = np.nanmean(acc_vals)

    print("\n20-Trial Summary: Mean AUC ± Std  |  Attacker ACC")
    print("=" * 60)
    for atk in attack_names:
        for clf in clf_names:
            key = "%s_%s" % (clf, atk)
            print("  %s %s: AUC %.4f ± %.4f | ACC %.4f" % (
                clf, atk, auc_mean[key], auc_std[key], acc_mean[key]))
    print("=" * 60)

    # ========== Separate figure per attack type ==========
    colors_gogh = ['#E5A53A', '#D97A4A', '#6F4E37']

    for i, atk in enumerate(attack_names):
        fig, ax = plt.subplots(figsize=(6.5, 6.0))

        means = [auc_mean["%s_%s" % (c, atk)] for c in clf_names]
        stds = [auc_std["%s_%s" % (c, atk)] for c in clf_names]
        accs = [acc_mean["%s_%s" % (c, atk)] for c in clf_names]
        x = np.arange(len(clf_names))

        bars = ax.bar(x, means, yerr=stds, color=colors_gogh, edgecolor='white',
                      linewidth=0.8, capsize=5,
                      error_kw={'elinewidth': 1.2, 'capthick': 1.2})

        for j, (m, s) in enumerate(zip(means, stds)):
            y_offset = m + s + 0.011
            ax.text(j, y_offset, f"{m:.3f}", ha='center', va='bottom',
                    fontsize=23, color='darkred' if m > 0.55 else '#2C3E50')

        ax.axhline(y=0.5, color='#D35400', linestyle='--', linewidth=1.8,
                   alpha=0.8, label='Random guessing (AUC=0.5)')
        ax.set_xticks(x)
        # attacker name + its own predictive accuracy below the axis
        if np.all(np.isnan(accs)):
            xlabels = clf_names
        else:
            xlabels = ["%s\n(acc = %.3f)" % (c, a)
                       for c, a in zip(clf_names, accs)]
        ax.set_xticklabels(xlabels, fontsize=24)
        ax.tick_params(axis='y', labelsize=24)
        ax.set_ylabel('AUC', fontsize=24)
        # ax.set_title("%s" % atk, fontsize=25,
        #              weight='bold', pad=12)
        ax.set_ylim(0.35, 0.65)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.grid(axis='y', linestyle='--', alpha=0.3)
        ax.legend(loc='upper left', fontsize=20, framealpha=0.9)

        plt.tight_layout()
        out = os.path.dirname(os.getcwd()) + \
            f'/Result_figure/sec6_2/Fig_MIA_LAR_20trial_d{DIM}_%s.pdf' % atk
        plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight',
                    pad_inches=0.2)
        plt.show()
        plt.close(fig)
        print("Saved: %s" % out)


if __name__ == "__main__":
    for DIM in (1, 5):   # keep the d1 + d5 loop
        # MIA_d = run_all_trials()   # 需要记录攻击器精度时必须重跑
        load_and_plot()
