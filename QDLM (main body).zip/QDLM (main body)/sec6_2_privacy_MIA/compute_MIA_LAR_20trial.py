"""
================================================================================
compute_MIA_LAR_20trial.py  --  Toy-simulation MIA run (merged version)
================================================================================
Paper: Main Figure 6 / Section 6.2 (privacy, membership inference attack)

This single script replaces the 42 files
  Toy_simulation_new_algorithm_MIA{,-d1}/MIA_toy_LAR_20trial{,_m5.._m100}.py
(which differed ONLY in the values of DIM and M).

M and DIM are read from environment variables:
  QDLM_M   : number of parties (default 10); multiple of 5 in [5, 350]
  QDLM_DIM : toy dimension, 1 or 5 (default 5)
The paper used M = 5,10,...,100 (step 5) and DIM = 1,5.

Toy-simulation setting (generated data, NOT real data):
  * victim system  = the toy TRAIN set itself: np.random.seed(trial) +
                     generate_data(10000, 1000, d) reproduces BIT BY BIT the
                     data on which trails_d{1,5}_hybrid.npy were trained
                     (members = the 10,000 training samples);
  * adversary pool = fresh samples from the SAME DGP but an independent seed
                     (np.random.seed(7777 + trial)): 2,000 to train the
                     shadow model, 1,000 shadow non-members, 2,000 victim
                     non-members.  y is observed (noisy) everywhere;
  * parameters     = trails_d{1,5}_hybrid.npy (local_h_gau / local_h_epan /
                     local_h_naive / local_k), m = 5,10,...,350 (gap = 5),
                     fen = m // 5 - 1;
  * CV_FOLD = 3 (toy), N_TRIALS = 20 (the stored parameters have 20 trials).

Adversaries (same as the real-data version):
  * LOCAL   : party 1 attacks membership in ITS OWN block with its OWN local
              model (no qualification rule); members = its 10000/m block
              samples, non-members = an equal number of victim non-members;
  * CENTRAL : the server observes the aggregated QDLAR prediction (log
              mechanism + qualification rule); members = 2,000 randomly
              subsampled victim training samples, non-members = 2,000.

Attacks: Attack-I |fit|, Attack-II loss, Attack-III [|fit|, loss];
classifiers LR / RF / MLP.  Results saved to
Result_data_for_MIIA/MIA_toy_d{DIM}_LAR_20trial_m{M}.npy  -- same fields as
the real-data files, so the Exp1-Exp4 plotting scripts work unchanged.

Usage: set QDLM_M / QDLM_DIM (or edit M_LIST and loop).  M must be a
multiple of 5 in [5, 350] so that trained parameters exist.
Run from this folder (one level below the repo root).
================================================================================
"""

import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
import warnings
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import roc_auc_score
from matplotlib import rcParams

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from common.Function_toy_MIA import (
    generate_data, generate_pool, global_parameter_h, prediction_vector_LAR,
    hybrid_algorithm_test_central_forMIA,
    hybrid_algorithm_test_local_forMIA,
    hybrid_algorithm_test_local_forMIA_non_v)

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)
warnings.filterwarnings('ignore')

# ----------------------------------------------------------------------------
# Configuration  --  the ONLY part to edit between runs
# ----------------------------------------------------------------------------
DIM = int(os.environ.get('QDLM_DIM', 5))   # 1 or 5  (toy dimension)
M = int(os.environ.get('QDLM_M', 10))        # number of parties; multiple of 5, in [5, 350]

TRAIN_N = 10000               # toy training size (victim pool size)
TEST_N = 1000                 # unused here; generate_data returns it anyway
GAP = 5                       # toy m-grid gap (m = 5,10,...,350)
N_TRIALS = 20                 # the stored parameters contain 20 trials
CV_FOLD = 3                   # toy simulation uses 3-fold CV for the shadow h
S = 2                         # Gaussian kernel exponent

# adversary pool sizes (generated per trial from the same DGP)
N_ADV = 2000                  # shadow-model training samples
N_NON1 = 1000                 # shadow non-members
N_NON2 = 2000                 # victim non-members (local AND central)
N_BALANCED = 1000             # shadow members subsample (balanced attack set)
CENTRAL_CASE = 2000           # central-attack members (subsample of victim)

PARAM_FILES = {1: 'trails_d1_hybrid.npy', 5: 'trails_d5_hybrid.npy'}
DATA_DIR = os.path.dirname(os.getcwd()) + '/Result_data'
SAVE_PATH = os.path.dirname(os.getcwd()) + '/Result_data_for_MIIA'
os.makedirs(SAVE_PATH, exist_ok=True)

assert M % GAP == 0 and 1 <= M // GAP <= 70, \
    'M must be a multiple of %d with trained parameters (m <= 350)' % GAP
FEN_NUM_FIX = M // GAP - 1    # fen index of this m in the parameter dicts

SAVE_FILE = SAVE_PATH + '/MIA_toy_d%d_LAR_20trial_m%d.npy' % (DIM, M)
FIG_PATH = os.path.dirname(os.getcwd()) + '/Result_figure/sec6_2'
os.makedirs(FIG_PATH, exist_ok=True)

DISTRIBUTED_CASE = TRAIN_N // M   # party 1's block size (local-attack members)


def get_fen(entry, fen):
    """The npy dict keys may be int or str depending on the save version."""
    if fen in entry:
        return entry[fen]
    return entry[str(fen)]


def load_params_trial(d, trial):
    """Per-trial parameter dicts {fen: array}, keys normalized to int."""
    para = np.load(os.path.join(DATA_DIR, PARAM_FILES[d]),
                   allow_pickle=True).tolist()
    out = {}
    for name, key in [('gau', 'local_h_gau'), ('epan', 'local_h_epan'),
                      ('nai', 'local_h_naive'), ('knn', 'local_k')]:
        per_trial = para[key][trial]
        out[name] = {int(f): np.asarray(v, dtype=float)
                     for f, v in per_trial.items()}
    return out['gau'], out['epan'], out['nai'], out['knn']


def run_single_trial(trial):
    # ---------------- 1. victim system = the toy training set ---------------
    np.random.seed(trial)     # identical data to the parameter training
    train_shape = TRAIN_N if DIM == 1 else (TRAIN_N, DIM)
    test_shape = TEST_N if DIM == 1 else (TEST_N, DIM)
    X_vic, y_vic, _, _ = generate_data(train_shape, test_shape, DIM)

    # ---------------- 2. adversary pool (same DGP, independent seed) --------
    np.random.seed(7777 + trial)
    X_pool, y_pool = generate_pool(N_ADV + N_NON1 + N_NON2, DIM)
    X_adv = X_pool[:N_ADV]
    y_adv = y_pool[:N_ADV]                                     # 2000
    X_non1 = X_pool[N_ADV:N_ADV + N_NON1]
    y_non1 = y_pool[N_ADV:N_ADV + N_NON1]                      # 1000
    X_non2 = X_pool[N_ADV + N_NON1:N_ADV + N_NON1 + DISTRIBUTED_CASE]
    y_non2 = y_pool[N_ADV + N_NON1:N_ADV + N_NON1 + DISTRIBUTED_CASE]
    X_non2_central = X_pool[N_ADV + N_NON1:N_ADV + N_NON1 + CENTRAL_CASE]
    y_non2_central = y_pool[N_ADV + N_NON1:N_ADV + N_NON1 + CENTRAL_CASE]

    # ---------------- 3. shadow model (global Gaussian LAR) -----------------
    h_shadow = global_parameter_h(X_adv, y_adv, CV_FOLD, DIM)
    np.random.seed(5555 + trial)
    idx_adv = np.random.choice(len(X_adv), N_BALANCED, replace=False)
    X_adv_m = X_adv[idx_adv]
    y_adv_m = y_adv[idx_adv]
    fit_abs_mem_s, loss_mem_s = prediction_vector_LAR(
        X_adv, y_adv, X_adv_m, y_adv_m, h_shadow, DIM, S)
    fit_abs_non_s, loss_non_s = prediction_vector_LAR(
        X_adv, y_adv, X_non1, y_non1, h_shadow, DIM, S)

    # ---------------- 4. victim parameters (trial-specific) -----------------
    adapt_gau_1, adapt_epan_1, adapt_nai_1, adapt_knn_1 = \
        load_params_trial(DIM, trial)

    # ---------------- 5. victim prediction vectors --------------------------
    # (1) LOCAL: party 1's own model on its own block (members) and on
    #     non-members -- NO qualification rule
    fit_abs_mem_v_local, loss_mem_v_local = hybrid_algorithm_test_local_forMIA(
        X_vic, y_vic, adapt_gau_1, adapt_epan_1, adapt_nai_1, adapt_knn_1,
        DIM, GAP, FEN_NUM_FIX)
    fit_abs_non_v_local, loss_non_v_local = \
        hybrid_algorithm_test_local_forMIA_non_v(
            X_vic, y_vic, X_non2, y_non2,
            adapt_gau_1, adapt_epan_1, adapt_nai_1, adapt_knn_1,
            DIM, GAP, FEN_NUM_FIX)

    # (2) CENTRAL: aggregated QDLAR prediction on a balanced member subsample
    #     and on non-members -- WITH log mechanism + qualification rule
    np.random.seed(9999 + trial)
    idx_vic = np.random.choice(len(X_vic), CENTRAL_CASE, replace=False)
    X_vic_m = X_vic[idx_vic]
    y_vic_m = y_vic[idx_vic]
    fit_abs_mem_v_central, loss_mem_v_central = \
        hybrid_algorithm_test_central_forMIA(
            X_vic, y_vic, X_vic_m, y_vic_m,
            adapt_gau_1, adapt_epan_1, adapt_nai_1, adapt_knn_1,
            DIM, GAP, FEN_NUM_FIX)
    fit_abs_non_v_central, loss_non_v_central = \
        hybrid_algorithm_test_central_forMIA(
            X_vic, y_vic, X_non2_central, y_non2_central,
            adapt_gau_1, adapt_epan_1, adapt_nai_1, adapt_knn_1,
            DIM, GAP, FEN_NUM_FIX)

    # ---------------- 6. MIA attacks ----------------------------------------
    attack_names = ["Attack-I", "Attack-II", "Attack-III"]
    attack_features = ["mag", "loss", "combined"]
    clf_names = ["LR", "RF", "MLP"]
    auc_results_central = {}
    auc_results_local = {}

    for atk_name, atk_feat in zip(attack_names, attack_features):
        if atk_feat == "mag":
            X_tr = np.vstack([fit_abs_mem_s.reshape(-1, 1),
                              fit_abs_non_s.reshape(-1, 1)])
            X_te_local = np.vstack([fit_abs_mem_v_local.reshape(-1, 1),
                                    fit_abs_non_v_local.reshape(-1, 1)])
            X_te_central = np.vstack([fit_abs_mem_v_central.reshape(-1, 1),
                                      fit_abs_non_v_central.reshape(-1, 1)])
        elif atk_feat == "loss":
            X_tr = np.vstack([loss_mem_s.reshape(-1, 1),
                              loss_non_s.reshape(-1, 1)])
            X_te_local = np.vstack([loss_mem_v_local.reshape(-1, 1),
                                    loss_non_v_local.reshape(-1, 1)])
            X_te_central = np.vstack([loss_mem_v_central.reshape(-1, 1),
                                      loss_non_v_central.reshape(-1, 1)])
        else:
            X_tr = np.vstack([np.column_stack([fit_abs_mem_s, loss_mem_s]),
                              np.column_stack([fit_abs_non_s, loss_non_s])])
            X_te_local = np.vstack(
                [np.column_stack([fit_abs_mem_v_local, loss_mem_v_local]),
                 np.column_stack([fit_abs_non_v_local, loss_non_v_local])])
            X_te_central = np.vstack(
                [np.column_stack([fit_abs_mem_v_central, loss_mem_v_central]),
                 np.column_stack([fit_abs_non_v_central, loss_non_v_central])])

        # NB: the shadow training set is balanced by construction
        # (N_BALANCED members from X_adv vs. N_NON1 = N_BALANCED non-members);
        # build the labels from the actual lengths for robustness
        y_tr = np.hstack([np.ones(len(fit_abs_mem_s)),
                          np.zeros(len(fit_abs_non_s))])

        for clf_name in clf_names:
            if clf_name == "LR":
                clf = LogisticRegression(max_iter=1000, random_state=trial)
            elif clf_name == "RF":
                clf = RandomForestClassifier(n_estimators=100,
                                             random_state=trial)
            else:
                clf = MLPClassifier(hidden_layer_sizes=(64, 32), max_iter=500,
                                    random_state=trial)
            clf.fit(X_tr, y_tr)

            # (1) LOCAL attack
            y_prob_local = clf.predict_proba(X_te_local)[:, 1]
            y_te = np.hstack([np.ones(DISTRIBUTED_CASE),
                              np.zeros(DISTRIBUTED_CASE)])
            auc_local = roc_auc_score(y_te, y_prob_local)
            auc_results_local["%s_%s" % (clf_name, atk_name)] = auc_local

            # (2) CENTRAL attack
            y_te = np.hstack([np.ones(CENTRAL_CASE), np.zeros(CENTRAL_CASE)])
            y_prob_central = clf.predict_proba(X_te_central)[:, 1]
            auc_central = roc_auc_score(y_te, y_prob_central)
            auc_results_central["%s_%s" % (clf_name, atk_name)] = auc_central

    return {
        'h_shadow': h_shadow,
        'AUC_local': auc_results_local,
        'victim_member_loss_mean_local': float(np.mean(loss_mem_v_local)),
        'victim_member_loss_std_local': float(np.std(loss_mem_v_local)),
        'victim_nonmember_loss_mean_local': float(np.mean(loss_non_v_local)),
        'victim_nonmember_loss_std_local': float(np.std(loss_non_v_local)),
        'AUC_central': auc_results_central,
        'victim_member_loss_mean_central': float(np.mean(loss_mem_v_central)),
        'victim_member_loss_std_central': float(np.std(loss_mem_v_central)),
        'victim_nonmember_loss_mean_central':
            float(np.mean(loss_non_v_central)),
        'victim_nonmember_loss_std_central': float(np.std(loss_non_v_central))
    }


def run_all_trials():
    time_start = time.time()
    print("=" * 75)
    print("  MIA Attack on LAR (toy simulation, d=%d, m=%d) -- %d Trials"
          % (DIM, M, N_TRIALS))
    print("=" * 75)

    MIA_d = {}
    MIA_d['N_TRIALS'] = N_TRIALS
    MIA_d['DIM'] = DIM
    MIA_d['M'] = M

    for trial in range(N_TRIALS):
        print('\nTrial %d / %d' % (trial + 1, N_TRIALS))
        results = run_single_trial(trial)
        MIA_d['trial_%d' % trial] = results

        auc_local = results['AUC_local']
        print("  AUC_local: LR=[%.3f,%.3f,%.3f] RF=[%.3f,%.3f,%.3f] "
              "MLP=[%.3f,%.3f,%.3f]" % (
                  auc_local['LR_Attack-I'], auc_local['LR_Attack-II'],
                  auc_local['LR_Attack-III'],
                  auc_local['RF_Attack-I'], auc_local['RF_Attack-II'],
                  auc_local['RF_Attack-III'],
                  auc_local['MLP_Attack-I'], auc_local['MLP_Attack-II'],
                  auc_local['MLP_Attack-III']))

        auc_central = results['AUC_central']
        print("  AUC_central: LR=[%.3f,%.3f,%.3f] RF=[%.3f,%.3f,%.3f] "
              "MLP=[%.3f,%.3f,%.3f]" % (
                  auc_central['LR_Attack-I'], auc_central['LR_Attack-II'],
                  auc_central['LR_Attack-III'],
                  auc_central['RF_Attack-I'], auc_central['RF_Attack-II'],
                  auc_central['RF_Attack-III'],
                  auc_central['MLP_Attack-I'], auc_central['MLP_Attack-II'],
                  auc_central['MLP_Attack-III']))

    np.save(SAVE_FILE, MIA_d)
    print('\nSaved: %s' % SAVE_FILE)
    print('Time: %.1f seconds' % (time.time() - time_start))
    return MIA_d


def _load_and_plot(setting):
    """Bar chart of mean +/- std AUC over trials (sunflower palette),
    setting = 'local' or 'central'."""
    print('\nLoading and plotting (%s)...' % setting)
    data = np.load(SAVE_FILE, allow_pickle=True).tolist()
    N = data['N_TRIALS']

    clf_names = ["LR", "RF", "MLP"]
    attack_names = ["Attack-I", "Attack-II", "Attack-III"]
    field = 'AUC_%s' % setting

    auc_mean, auc_std = {}, {}
    for clf in clf_names:
        for atk in attack_names:
            key = "%s_%s" % (clf, atk)
            vals = [data['trial_%d' % t][field][key] for t in range(N)]
            auc_mean[key] = np.mean(vals)
            auc_std[key] = np.std(vals)

    print("\n%d-Trial Summary: Mean %s +/- Std" % (N, field))
    print("=" * 60)
    for atk in attack_names:
        for clf in clf_names:
            key = "%s_%s" % (clf, atk)
            print("  %s %s: %.4f +/- %.4f" % (clf, atk, auc_mean[key],
                                              auc_std[key]))
    print("=" * 60)

    fig, axes = plt.subplots(1, 3, figsize=(18, 6.5))
    colors_gogh = ['#E5A53A', '#D97A4A', '#6F4E37']   # sunflower palette

    for i, atk in enumerate(attack_names):
        ax = axes[i]
        means = [auc_mean["%s_%s" % (c, atk)] for c in clf_names]
        stds = [auc_std["%s_%s" % (c, atk)] for c in clf_names]
        x = np.arange(len(clf_names))

        ax.bar(x, means, yerr=stds, color=colors_gogh, edgecolor='white',
               linewidth=0.8, capsize=5,
               error_kw={'elinewidth': 1.2, 'capthick': 1.2})

        for j, (m_, s_) in enumerate(zip(means, stds)):
            ax.text(j, m_ + s_ + 0.011, "%.3f" % m_, ha='center', va='bottom',
                    fontsize=20, color='darkred' if m_ > 0.7 else '#2C3E50')

        ax.axhline(y=0.5, color='#D35400', linestyle='--', linewidth=1.8,
                   alpha=0.8)
        ax.set_xticks(x)
        ax.set_xticklabels(clf_names, fontsize=20, rotation=0)
        ax.set_ylabel('AUC Score', fontsize=20)
        ax.tick_params(axis='y', labelsize=20)
        ax.set_title("(%s) %s" % (chr(97 + i), atk), fontsize=22,
                     weight='bold', pad=12)
        ax.set_ylim(0.2, 0.85)
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.grid(axis='y', linestyle='--', alpha=0.3)

        if i == 0:
            ax.legend(['Random guessing (AUC=0.5)'], loc='upper left',
                      fontsize=18, framealpha=0.9)

    plt.suptitle('MIA result of LAR using different attack classifiers '
                 '(%s, $d$=%d, $m$=%d)' % (setting, DIM, M),
                 fontsize=24, weight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out = FIG_PATH + '/Fig_MIA_toy_d%d_LAR_20trial_%s_m%d.pdf' % (
        DIM, setting, M)
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    print("\nSaved: %s" % out)


def load_and_plot_local():
    _load_and_plot('local')


def load_and_plot_central():
    _load_and_plot('central')


if __name__ == "__main__":
    MIA_res = run_all_trials()
    load_and_plot_local()
    load_and_plot_central()