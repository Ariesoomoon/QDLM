"""
================================================================================
Fig5b_MIA_attack_advantage.py  --  MIA Attack Advantage (Adv = 2*AUC - 1)
Across 5 Regression Models
================================================================================
Paper: Main Figure 5b (Section 6.2)

Models: NWK(Gaussian) / KRR / Linear / MLP / 1-NN
(NWK(Gaussian) = the QDLM local algorithm, formerly labelled "LAR";
 DT and RF of the draft version were removed for the paper.)

Model order and colors match the original screenshot (截屏2026-06-04):
  Top→Bottom: NWK(Gaussian) → KRR → Linear → MLP → 1-NN
  Colors:     #E5A53A, #D97A4A, #6F4E37, #2C5F7A, #B5651E

Output: Fig_MIA_attack_advantage_d1.pdf / Fig_MIA_attack_advantage_d5.pdf
        (separate figures, legend below each panel)
================================================================================
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib import rcParams

# Font config
config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)

# ==============================================================================
# Model colors — matching the screenshot
# ==============================================================================
COLOR_MAP = {
    'NWK(Gaussian)': '#E5A53A',  # golden yellow (color of the former 'LAR')
    'KRR':    '#D97A4A',  # orange-brown
    'Linear': '#6F4E37',  # dark brown
    'MLP':    '#2C5F7A',  # blue-gray (cold tone)
    '1-NN':   '#B5651E',  # brown-tan
}

MODELS = ['NWK(Gaussian)', 'KRR', 'Linear', 'MLP', '1-NN']

# ==============================================================================
# Data (mean AUC over 20 trials)
# ==============================================================================
AUC_D1 = np.array([0.496, 0.497, 0.501, 0.497, 0.865])
AUC_D5 = np.array([0.520, 0.544, 0.498, 0.504, 0.861])
ADV_D1 = 2 * AUC_D1 - 1
ADV_D5 = 2 * AUC_D5 - 1

# ==============================================================================
# Plotting: one figure per dimension
# ==============================================================================

def plot_single(adv_vals, auc_vals, models_ord, colors_ord, dim, save_path):
    y_pos = np.arange(len(models_ord))
    bar_height = 0.65

    fig, ax = plt.subplots(figsize=(7.2, 6.4))

    bars = ax.barh(y_pos, adv_vals, bar_height, color=colors_ord,
                   edgecolor='white', linewidth=0.8, alpha=0.92)

    # Value labels
    for bar, adv, auc in zip(bars, adv_vals, auc_vals):
        if abs(adv) < 0.02:
            x_pos, ha, color = 0.10, 'left', 'black'
            label = f'≈ 0.000' if abs(adv) < 0.005 else f'{adv:+.3f}'
            ax.text(x_pos, bar.get_y() + bar.get_height()/2 - 0.22,
                    f'(AUC={auc:.3f})', ha='left', va='center',
                    fontsize=13, color='black')
        elif adv >= 0:
            x_pos, ha, color = adv + 0.025, 'left', '#2D3748'
            label = f'{adv:+.3f}'
            ax.text(x_pos, bar.get_y() + bar.get_height()/2 - 0.22,
                    f'(AUC={auc:.3f})', ha='left', va='center',
                    fontsize=13, color='black')
        else:
            x_pos, ha, color = adv - 0.025, 'right', '#2D3748'
            label = f'{adv:+.3f}'
            ax.text(x_pos, bar.get_y() + bar.get_height()/2 - 0.22,
                    f'(AUC={auc:.3f})', ha='right', va='center',
                    fontsize=13, color='black')
        ax.text(x_pos, bar.get_y() + bar.get_height()/2 + 0.08, label,
                ha=ha, va='center', fontsize=13, fontweight='bold',
                color=color)

    # Styling
    ax.set_yticks(y_pos)
    ax.set_yticklabels(models_ord, fontsize=15, fontweight='bold')
    ax.set_xlabel('Attack advantage  (Adv = 2 × AUC − 1)',
                  fontsize=16, fontweight='bold', labelpad=10)
    # ax.set_title(f'{dim}', fontsize=18, fontweight='bold', pad=12,
    #              color='#2D3748')
    ax.set_xlim(-0.10, 1.15)
    ax.set_ylim(-0.7, len(models_ord) - 0.3)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_color('#64748B')
    ax.spines['bottom'].set_color('#64748B')
    ax.tick_params(axis='x', labelsize=15, colors='black')
    ax.text(0.20, -0.5, '← MIA-resistant', fontsize=16, color='forestgreen',
            ha='center', va='top', fontstyle='italic', fontweight='bold')
    ax.text(0.78, -0.5, 'MIA-vulnerable →', fontsize=16, color='red',
            ha='center', va='top', fontstyle='italic', fontweight='bold')

    # Legend: two rows below the figure (4 + 3)
    legend_elements = [
        mpatches.Patch(facecolor=COLOR_MAP[m], edgecolor='white', label=m)
        for m in MODELS
    ]
    fig.legend(handles=legend_elements, loc='lower center', ncol=4,
               fontsize=15, frameon=True, fancybox=True,
               bbox_to_anchor=(0.5, -0.01))

    plt.tight_layout(rect=[0, 0.09, 1, 1.0])
    plt.savefig(save_path, dpi=600, format='pdf', bbox_inches='tight',
                pad_inches=0.2)
    plt.show()
    plt.close(fig)
    print('Saved: %s' % save_path)




def plot_attack_advantage(output_dir=os.path.dirname(os.getcwd()) + '/Result_figure/sec6_2/'):
    # matplotlib barh: y=0 is at BOTTOM; LAR at TOP → reverse order
    order = [4, 3, 2, 1, 0]
    models_ord = [MODELS[i] for i in order]
    colors_ord = [COLOR_MAP[m] for m in models_ord]

    os.makedirs(output_dir, exist_ok=True)
    for adv, auc, dim, tag in (
        (ADV_D1, AUC_D1, 'd=1', 'd1'),
        (ADV_D5, AUC_D5, 'd=5', 'd5'),
    ):
        plot_single([adv[i] for i in order], [auc[i] for i in order],
                    models_ord, colors_ord, dim,
                    os.path.join(output_dir,
                                 f'Fig_MIA_attack_advantage_{tag}.pdf'))



if __name__ == "__main__":
    plot_attack_advantage()
