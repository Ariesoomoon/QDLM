"""
================================================================================
Fig5a_MIA_attack_classifiers.py  --  Experiment 3 (toy simulation): Comparison of attack classifiers (LR/RF/MLP)
Paper: Main Figure 5a (Section 6.2)
================================================================================
Toy-simulation version of MIA_Exp3_classifier_comparison_new.py.
Aggregates the saved results over ALL M values and answers three questions:
  (a) mean AUC of each classifier x attack combination — local setting (heatmap)
  (b) mean AUC of each classifier x attack combination — central setting (heatmap)
  (c) win rate: in what fraction of ALL configurations (M x attack x setting x
      trial) does each classifier achieve the highest AUC?

All three classifiers are rendered NEUTRALLY (no pre-assumed winner);
only the empirically highest AUC cell in each heatmap is bolded.

No re-running of attacks is needed -- this script only loads and plots.
================================================================================
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import warnings
from matplotlib import rcParams

config = {
    "font.family": 'Times New Roman',
    "font.size": 17,
    "mathtext.fontset": 'stix',
}
rcParams.update(config)
warnings.filterwarnings('ignore')

# ----------------------------------------------------------------------------
# Configuration
# ----------------------------------------------------------------------------
RESULT_DIR = os.environ.get('MIA_RESULT_DIR',
                            os.path.dirname(os.getcwd()) + '/Result_data_for_MIIA')
FIG_DIR = os.environ.get('MIA_FIG_DIR',
                         os.path.dirname(os.getcwd()) + '/Result_figure/sec6_2')
os.makedirs(FIG_DIR, exist_ok=True)

DIM = int(os.environ.get('QDLM_DIM', 5))     # 1 or 5 (toy dimension; paper used 1 and 5)
FILE_TEMPLATE = 'MIA_toy_d%d_LAR_20trial_m{}.npy' % DIM
M_LIST = [5, 10, 15, 20, 25, 30, 35, 40, 45,50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100]       # toy m-grid (gap = 5)
M_LIST = [10, 20, 30, 40,50, 60, 70, 80, 90, 100]       # toy m-grid (gap = 5)
CLF_NAMES = ["LR", "RF", "MLP"]
ATTACK_NAMES = ["Attack-I", "Attack-II", "Attack-III"]

# neutral colors: no classifier is singled out in advance
CLF_COLORS = {"LR": '#7FA3C0', "RF": '#7FA3C0', "MLP": '#7FA3C0'}


# ----------------------------------------------------------------------------
# Loading
# ----------------------------------------------------------------------------
def load_auc_series(result_dir, m_list):
    series = {}
    for M in m_list:
        f = os.path.join(result_dir, FILE_TEMPLATE.format(M))
        if not os.path.exists(f):
            print('  [skip] %s not found' % f)
            continue
        data = np.load(f, allow_pickle=True).tolist()
        n = data['N_TRIALS']
        entry = {'local': {}, 'central': {}}
        for setting, field in [('local', 'AUC_local'), ('central', 'AUC_central')]:
            for clf in CLF_NAMES:
                for atk in ATTACK_NAMES:
                    key = '%s_%s' % (clf, atk)
                    entry[setting][key] = np.array(
                        [data['trial_%d' % t][field][key] for t in range(n)])
        series[M] = entry
        print('  loaded M=%d (%d trials)' % (M, n))
    return series


# ----------------------------------------------------------------------------
# Aggregation
# ----------------------------------------------------------------------------
def mean_auc_matrix(series, setting):
    """3(clf) x 3(attack) matrix of AUC averaged over all M and trials."""
    mat = np.zeros((len(CLF_NAMES), len(ATTACK_NAMES)))
    for i, clf in enumerate(CLF_NAMES):
        for j, atk in enumerate(ATTACK_NAMES):
            key = '%s_%s' % (clf, atk)
            vals = np.concatenate([series[M][setting][key] for M in series])
            mat[i, j] = vals.mean()
    return mat


def win_rates(series):
    """Fraction of all (M, setting, attack, trial) configs won by each classifier."""
    wins = {c: 0 for c in CLF_NAMES}
    total = 0
    for M in series:
        n = len(series[M]['local']['%s_%s' % (CLF_NAMES[0], ATTACK_NAMES[0])])
        for setting in ['local', 'central']:
            for atk in ATTACK_NAMES:
                arrs = {c: series[M][setting]['%s_%s' % (c, atk)] for c in CLF_NAMES}
                for t in range(n):
                    scores = {c: arrs[c][t] for c in CLF_NAMES}
                    best = max(scores, key=scores.get)
                    wins[best] += 1
                    total += 1
    return {c: wins[c] / total for c in CLF_NAMES}, total


# ----------------------------------------------------------------------------
# Figure: (a) heatmap local, (b) heatmap central, (c) win-rate bars
# ----------------------------------------------------------------------------
def plot_classifier_comparison(series):
    mat_local = mean_auc_matrix(series, 'local')
    mat_central = mean_auc_matrix(series, 'central')

    fig = plt.figure(figsize=(14, 6.8))
    gs = fig.add_gridspec(1, 2, wspace=0.4)

    vmin = min(mat_local.min(), mat_central.min()) - 0.01
    vmax = max(mat_local.max(), mat_central.max()) + 0.01
    # paper palette -- identical to the per-agent attribution heatmaps:
    # white -> light orange -> attribution orange #D97A4A -> deep brown
    from matplotlib.colors import LinearSegmentedColormap
    cmap = LinearSegmentedColormap.from_list(
        'attr_orange',
        ['#FFFFFF', '#FBEAD3', '#F2C894', '#D97A4A', '#A85A2A', '#6E3A14'])

    for idx, (mat, setting, tag) in enumerate([(mat_local, 'local', 'a'),
                                               (mat_central, 'central', 'b')]):
        ax = fig.add_subplot(gs[0, idx])
        im = ax.imshow(mat, cmap=cmap, vmin=vmin, vmax=vmax, aspect='auto')
        ax.set_xticks(range(3))
        ax.set_xticklabels(ATTACK_NAMES, fontsize=23)
        ax.set_yticks(range(3))
        ax.set_yticklabels(CLF_NAMES, fontsize=23)
        # ax.set_title('(%s) %s setting' % (tag, setting.capitalize()),
        #              fontsize=22, weight='bold', pad=12)

        # ax.set_title('%s setting' % (setting.capitalize()),
        #              fontsize=22, weight='bold', pad=12)

        titles = {
            'local': 'MIA against an individual practitioner',
            'central': 'MIA against the aggregated prediction',
        }
        ax.set_title(titles[setting], fontsize=22, weight='bold', pad=12)

        # bold only the empirically best cell
        best_i, best_j = np.unravel_index(np.argmax(mat), mat.shape)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, '%.3f' % mat[i, j], ha='center', va='center',
                        fontsize=22, color='black',
                        weight='bold' if (i, j) == (best_i, best_j) else 'normal')
        # fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        cbar.ax.tick_params(labelsize=20)  # 调刻度数字大小

    # plt.suptitle('Comparison of MIA result for QDLM (aggregated over all $m$, $d$=%d)' % DIM, fontsize=24, weight='bold', y=0.96)

    plt.suptitle('MIA performance of QDLM', fontsize=28,
                 weight='bold', y=0.96)

    plt.subplots_adjust(top=0.78)
    out = os.path.join(FIG_DIR, 'Fig_Exp3_toy_d%d_classifier_comparison.pdf' % DIM)
    plt.savefig(out, dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
    plt.show()
    print('\nSaved: %s' % out)


def print_summary(series):
    print('\n' + '=' * 70)
    print('Exp-3 summary (toy, d=%d): mean AUC over all M and trials' % DIM)
    print('=' * 70)
    for setting in ['local', 'central']:
        mat = mean_auc_matrix(series, setting)
        print('\n[%s setting]' % setting)
        print('%-6s %s' % ('', '  '.join('%-10s' % a for a in ATTACK_NAMES)))
        for i, clf in enumerate(CLF_NAMES):
            print('%-6s %s' % (clf, '  '.join('%-10.4f' % mat[i, j]
                                               for j in range(3))))
    rates, total = win_rates(series)
    print('\nWin rates over %d configurations (M x attack x setting x trial):' % total)
    for c in sorted(CLF_NAMES, key=lambda c: -rates[c]):
        print('  %-4s: %.1f%%' % (c, 100 * rates[c]))
    print('=' * 70)


if __name__ == '__main__':
    print('Loading results from: %s' % RESULT_DIR)
    series = load_auc_series(RESULT_DIR, M_LIST)
    if len(series) < 1:
        raise RuntimeError('No result files found.')
    print_summary(series)
    plot_classifier_comparison(series)
