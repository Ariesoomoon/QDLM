# Paper: Appendix Figures 3 and 4 (Section C.2/C.3, expanding collaboration) - d5 panels.
# Formerly: Simulation/parameter_d5_hybrid_same_and_fixed_local_size500_m600_total(use).py
# Reads root-level Result_data/trails_d5_hybrid_fixed_local_size_*_m600.npy; run from this folder.
import os, time
import sys
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
from common.Function_fixed_local_size import generate_data, global_parameter_h, local_parameter_h_test, opt_local_h_NWK,opt_local_k_d5_KNN, mblocks
# from common.Function_diff_block import generate_data, global_parameter_h, local_parameter_h_test
import numpy as np
import random
import math
import random
from random import shuffle
time_start = time.time()
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.ticker import FuncFormatter
import pdb, time, os
import sys

from matplotlib import rcParams
fontsize_specific = 16
config = {
    "font.family":'Times New Roman',
    "font.size": fontsize_specific,
    "mathtext.fontset":'stix',
}
rcParams.update(config)




'''0. replace to Gaussian kernel of all cv-5 function in Function_same_block_gau.py !!!!'''


'''1. Initialization'''
f = 5                  # cv-5
trails = 20
m = 600
train, test, d = (300000,5), (1000,5), 5
p1, p2 = 0.25, 0.75    # for NWK
KNN_p1, KNN_p2 = 20, 60  # for KNN
s = 2
local_parameter_lists = {}
assign_list = []



'''1. --------------------------------------------------------   训练参数    --------------------------------------------------------'''
# for trail in range(trails):
#     np.random.seed(trail)
#     print('------------------------------------------------ trail:', trail + 1)
#     X_train, y_train, X_test, y_test = generate_data(train, test, d)
#     print('\nThe first training data:\nX_train:%s,y_train:%s' % (X_train[0:1], y_train[0:1]))
#     b = mblocks(X_train, y_train, m)
#     random.seed(0)
#     local_parameter_list = []
#     assign_list = []
#     for i in range(m):  # m=50
#         # step1: 划分数据
#         b_x_ori = np.array(b.loc[i]['block_x'])
#         b_y_ori = np.array(b.loc[i]['block_y'])
#         assign = random.randint(1, 4)
#         # print('assign:', assign)
#         assign_list.append(assign)
#         # print('assign_list:', assign_list)
#
#         # step2: 准备按照前面的随机机制选择医生
#         # gaussian kernel, s=2
#         if assign == 1:
#             local_parameter_list.append(opt_local_h_NWK(b_x_ori, b_y_ori, f, d, func='gaussian'))
#
#         # Epan kernel
#         if assign == 2:
#             local_parameter_list.append(opt_local_h_NWK(b_x_ori, b_y_ori, f, d, func='epan'))
#
#         # naive kernel
#         if assign == 3:
#             local_parameter_list.append(opt_local_h_NWK(b_x_ori, b_y_ori, f, d, func='naive'))
#
#         # KNN
#         if assign == 4:
#             local_parameter_list.append(opt_local_k_d5_KNN(b_x_ori, b_y_ori, KNN_p1, KNN_p2, d))
#
#     local_parameter_lists[trail] = local_parameter_list
#     # print('local_parameter_lists:', local_parameter_lists)
#
# trails_d5_hybrid_fixed_local_size_500_m600 = {}
# trails_d5_hybrid_fixed_local_size_500_m600['local_parameter_lists'] = local_parameter_lists
# trails_d5_hybrid_fixed_local_size_500_m600['assign_list'] = assign_list
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_500_m600.npy', trails_d5_hybrid_fixed_local_size_500_m600)
# print('--------------------------------------------------------------save trails_d5_hybrid_fixed_local_size_500_m600.npy done')




'''2. --------------------------------------------------------   计算    --------------------------------------------------------'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_500_m600.npy', allow_pickle=True)
# trails_d5_hybrid_fixed_local_size_500_m600 = loadData.tolist()
# print(trails_d5_hybrid_fixed_local_size_500_m600.keys())
# local_agent_num_list = list(range(1, 61))
# average_error_lists = {}
# local_parameter_lists = trails_d5_hybrid_fixed_local_size_500_m600['local_parameter_lists']
# assign_list = trails_d5_hybrid_fixed_local_size_500_m600['assign_list']


'''1. training parameter for global and local: 20 random seed for 20 trails'''
# for trail in range(trails):
#     np.random.seed(trail)
#     print('------------------------------------------------ trail:', trail + 1)
#     X_train, y_train, X_test, y_test = generate_data(train, test, d)
#     print('\nThe first training data:\nX_train:%s,y_train:%s' % (X_train[0:1], y_train[0:1]))
#     b = mblocks(X_train, y_train, m)
#     n_test = len(X_test)
#
#     random.seed(0)
#     average_error_list = []
#     for local_agent_num in local_agent_num_list: #对于每一种联合预测的情况
#         active_m = np.zeros(n_test)
#         fit_blocks = np.zeros((n_test, local_agent_num*10))
#         # print('local_agent_num', local_agent_num*10)
#
#         for i in range(local_agent_num*10): # 中的每一位医生
#             # step1: 划分数据
#             b_x_ori = np.array(b.loc[i]['block_x'])
#             b_y_ori = np.array(b.loc[i]['block_y'])
#
#             # 转换数据，预测的时候，计算加速用
#             x_tes = np.array(X_test)  # ensure x_tes.shape: (t, d) each time
#             n_local = b_x_ori.shape[0]
#             t = x_tes.shape[0]
#
#             # transform: (t, d, n)
#             x_tes = np.reshape(x_tes, (t, d, 1))
#             x_tes = np.repeat(x_tes, n_local, axis=2)
#             b_x = b_x_ori.T
#             b_x = np.reshape(b_x, (1, d, n_local), order='A')
#             b_x = np.repeat(b_x, t, axis=0)
#
#             # assign = random.randint(1, 4)
#             # print('assign:', assign)
#             assign = assign_list[i]
#
#             # 0个医生也算一下，每一次for 数据量会发生变化
#             total_data_size = local_agent_num * n_local
#             # print('total_data_size:', total_data_size)
#             LOG = math.log(total_data_size, n_local)         # logarithmic operator
#
#             # step2: 准备按照前面的随机机制选择医生
#             # gaussian kernel, s=2
#             if assign == 1:
#                 h = local_parameter_lists[trail][i] ** LOG  # adapt local h of block[i] at a certain fen_num[fen_num]
#                 h = min(1, h)
#                 dis = (x_tes - b_x) / h
#                 dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
#                 weight = np.exp((-dis_norm))
#                 a0 = np.dot(weight, b_y_ori)
#                 b0 = np.sum(weight, axis=1)
#                 fit = np.divide(a0, b0, out=np.zeros_like(a0, dtype=np.float64), where=b0 != 0)
#
#             # Epan kernel
#             if assign == 2:
#                 h = local_parameter_lists[trail][i] ** LOG
#                 h = min(1, h)
#                 dis = (x_tes - b_x) / h
#                 dis_norm = (np.linalg.norm(dis, axis=1)) ** 2
#                 weight = np.where((1 - dis_norm) > 0, 1 - dis_norm, 0)
#                 a1 = np.dot(weight, b_y_ori)
#                 b1 = np.sum(weight, axis=1)
#                 fit = np.divide(a1, b1, out=np.zeros_like(a1, dtype=np.float64), where=b1 != 0)
#
#             # naive kernel
#             if assign == 3:
#                 h = local_parameter_lists[trail][i] ** LOG
#                 h = min(1, h)
#                 dis = (x_tes - b_x) / h
#                 dis_norm = np.linalg.norm(dis, axis=1)
#                 weight = np.where(dis_norm <= 1, 1, 0)
#                 a2 = np.dot(weight, b_y_ori)
#                 b2 = np.sum(weight, axis=1)
#                 fit = np.divide(a2, b2, out=np.zeros_like(a2, dtype=np.float64), where=b2 != 0)
#
#             # knn
#             if assign == 4:
#                 # print('knn')
#                 # print(local_parameter_lists[trail][i])
#                 k = ((local_parameter_lists[trail][i]) ** LOG) / local_agent_num
#                 k = math.ceil(k)
#                 dis = (x_tes - b_x)
#                 dis_norm = np.linalg.norm(dis, axis=1)
#                 index = np.argsort(dis_norm, axis=1)
#                 y_knn = b_y_ori[index]
#                 y_knn = y_knn[:, :k]
#                 fit = (np.sum(y_knn, -1)) / k
#
#             fit = np.reshape(fit, (-1, 1))
#             fit = np.nan_to_num(fit)
#             # qualifing
#             active = np.where(abs(fit) >= 1 / total_data_size, 1, 0)
#             active = np.squeeze(active)
#             active_m += active
#             fit = fit * (active.reshape(n_test, 1))
#             fit_blocks[:, i] = np.squeeze(fit)
#             # fit_blocks = np.nan_to_num(fit_blocks)
#
#         # print('active m after knn', active_m[:5])
#         a3 = np.sum(fit_blocks, axis=1)
#         b3 = active_m
#         fit_global = np.divide(a3, b3, out=np.zeros_like(a3, dtype=np.float64), where=b3 != 0)
#         average_error = np.sum((fit_global - y_test) ** 2) / n_test
#         average_error_list.append(average_error)
#         # print(average_error_list)
#
#     average_error_lists[trail] = average_error_list
#     print('average_error_lists:', average_error_lists)
#
#
# trails_d5_hybrid_fixed_local_size_500_m600['average_error_lists'] = average_error_lists
# np.save(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_500_m600.npy', trails_d5_hybrid_fixed_local_size_500_m600)
# print('--------------------------------------------------------------save trails_d5_hybrid_fixed_local_size_500_m600.npy done')
#


'''3. --------------------------------------------------------   画图    --------------------------------------------------------'''
# loadData = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_500_m600.npy', allow_pickle=True)
# trails_d5_hybrid_fixed_local_size_500_m600 = loadData.tolist()
# print(trails_d5_hybrid_fixed_local_size_500_m600.keys())
# average_error_lists = trails_d5_hybrid_fixed_local_size_500_m600['average_error_lists']
# average_error_array = np.array(list(average_error_lists.values()))
# average_error_mean = np.mean(average_error_array, axis=0)
# local_agent_num_list = [i for i in range(10, 601, 10)]
#
# local_agent_num_list = local_agent_num_list[::2]
# average_error_mean = average_error_mean[::2]
# fig = plt.figure(tight_layout=True)
# # fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# ax.plot(local_agent_num_list, average_error_mean, c='black', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
# # ax.plot(M_nwk, LEs_mean, c='royalblue', linestyle=':', linewidth=1.4)
# # ax.plot(M_nwk, AEs_mean, c='royalblue', linestyle='--', linewidth=1.4)
# # ax.plot(M_nwk, AE_adapts_mean, c='brown', linestyle=':', linewidth=1.4)
# # ax.plot(M_nwk, AE_logs_mean, c='brown', linestyle='--', linewidth=1.4)
# # plt.axvline(x=30,ls="-",c="green", linewidth=1.2)
# # plt.legend(['GE', 'LE', 'AE_opt_h', 'AE_adapt', 'AE_log'], loc='upper left', fontsize='medium')
# ax.set_xlabel('Number of local agents ($d=5$)', fontsize='18')
# ax.set_ylabel('MSE', fontsize='18')
# plt.legend(['$AE_\mathrm{active, hybrid}$'], ncol=1, loc='upper left', fontsize='18')
# # plt.yscale('log')
# # plt.ylim(0.0, 0.0001)
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C2_C3/fixed_size500_d5_m600.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()



'''4. --------------------------------------------------------  
# 图片改的好看一点：罗马字体，diamond
# 
# 大家的增加都小于10%时
# 只能计算optimal和shrinkage
# 
# 综合 画图: size=100, 200, 500    --------------------------------------------------------'''
trails_d5_hybrid_fixed_local_size_500_m600 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_500_m600.npy', allow_pickle=True).tolist()
trails_d5_hybrid_fixed_local_size_200_m600 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_200_m600.npy', allow_pickle=True).tolist()
trails_d5_hybrid_fixed_local_size_100_m600 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_100_m600.npy', allow_pickle=True).tolist()
average_error_mean_500 = np.mean(np.array(list(trails_d5_hybrid_fixed_local_size_500_m600['average_error_lists'].values())), axis=0)
average_error_mean_200 = np.mean(np.array(list(trails_d5_hybrid_fixed_local_size_200_m600['average_error_lists'].values())), axis=0)
average_error_mean_100 = np.mean(np.array(list(trails_d5_hybrid_fixed_local_size_100_m600['average_error_lists'].values())), axis=0)
local_agent_num_list = [i for i in range(10, 601, 10)]


fig = plt.figure(tight_layout=True)
gs = gridspec.GridSpec(1, 1)
ax = fig.add_subplot(gs[0, 0])
# ax.grid(linestyle='-.')
local_agent_num_list = local_agent_num_list[::2]
average_error_mean_100 = average_error_mean_100[::2]
average_error_mean_200 = average_error_mean_200[::2]
average_error_mean_500 = average_error_mean_500[::2]

ax.plot(local_agent_num_list, average_error_mean_100, c='black', marker='s', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(local_agent_num_list, average_error_mean_200, c='royalblue', marker='o', linestyle='-', linewidth=1.4, markersize=4)
ax.plot(local_agent_num_list, average_error_mean_500, c='brown', marker='o', linestyle='-', linewidth=1.4, markersize=4)
ax.set_xlabel('Number of local agents ($d=5$)', fontsize='18')
ax.set_ylabel('MSE', fontsize='18')
plt.legend(['$AE_\mathrm{active, hybrid}$ with $|D_j|=100$', '$AE_\mathrm{active, hybrid}$ with $|D_j|=200$', '$AE_\mathrm{active, hybrid}$ with $|D_j|=500$'], loc='upper right', fontsize='16')

# plt.yscale('log')
# plt.ylim(0.0, 0.0001)
plt.axhline(y=0.0015,ls="-",c="mediumseagreen", linewidth=1.5)
plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C2_C3/fixed_size100_200_500_d5_m600.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
plt.show()




'''5. --------------------------------------------------------  综合 变化的百分比 画图: size=100, 200, 500    --------------------------------------------------------'''
# trails_d5_hybrid_fixed_local_size_500_m600 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_500_m600.npy', allow_pickle=True).tolist()
# trails_d5_hybrid_fixed_local_size_200_m600 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_200_m600.npy', allow_pickle=True).tolist()
# trails_d5_hybrid_fixed_local_size_100_m600 = np.load(os.path.dirname(os.getcwd()) + '/Result_data/trails_d5_hybrid_fixed_local_size_100_m600.npy', allow_pickle=True).tolist()
# average_error_mean_500 = np.mean(np.array(list(trails_d5_hybrid_fixed_local_size_500_m600['average_error_lists'].values())), axis=0)
# average_error_mean_200 = np.mean(np.array(list(trails_d5_hybrid_fixed_local_size_200_m600['average_error_lists'].values())), axis=0)
# average_error_mean_100 = np.mean(np.array(list(trails_d5_hybrid_fixed_local_size_100_m600['average_error_lists'].values())), axis=0)
# local_agent_num_list = [i for i in range(10, 601, 10)]
#
# # 💎💎💎💎
# # 计算每个元素相对于前一个元素变动的百分比
# # 由于计算百分比变动时需要避免除以0的情况，对于列表的第一个元素，由于没有前一个元素，所以不进行计算
#
# def percentage_changes(list_1):
#     per_change = [abs((list_1[i] - list_1[i-1])) / list_1[i-1] * 100 for i in range(1, len(list_1))]
#     return per_change
#
#
# fig = plt.figure(tight_layout=True)
# fig = plt.figure(figsize=(6, 5), tight_layout=True)
# gs = gridspec.GridSpec(1, 1)
# ax = fig.add_subplot(gs[0, 0])
# # ax.grid(linestyle='-.')
# # ax.plot(local_agent_num_list[1:], percentage_changes(average_error_mean_100), c='black', linestyle='-.', linewidth=1.4)
# # ax.plot(local_agent_num_list[1:], percentage_changes(average_error_mean_200), c='royalblue', linestyle='--', linewidth=1.4)
# ax.plot(local_agent_num_list[1:][::2], percentage_changes(average_error_mean_500)[::2], c='brown', marker='^',  linestyle='-', linewidth=1.2, markersize=5)
# ax.set_xlabel('Number of local agents ($d=5$)', fontsize='18')
# ax.set_ylabel('$\Delta$ MSE (%) ', fontsize='18')
# # plt.legend(['$|D_j|=100$', '$|D_j|=200$', '$|D_j|=500$'], loc='upper right', fontsize='medium')
# # plt.yscale('log')
# # plt.ylim(0.0, 0.0001)
# # plt.axvline(x=150,ls="-",c="green", linewidth=2.0)
# plt.savefig(os.path.dirname(os.getcwd()) + '/Result_figure/appendix_C2_C3/fixed_size500_d5_m600_deltaMSE.pdf', dpi=600, format='pdf', bbox_inches='tight', pad_inches=0.2)
# plt.show()
#

